// 농산물 분석 관련 타입 정의

export interface ProductAnalysis {
  id?: string;
  created_at?: string;
  updated_at?: string;
  
  // 이미지 정보
  image_url?: string;
  image_filename?: string;
  image_size?: number;
  
  // AI 분석 결과
  product_name?: string;
  product_category?: string;
  confidence_score?: number;
  
  // 상세페이지 콘텐츠
  title?: string;
  description?: string;
  features?: string[];
  specifications?: Record<string, string>;
  pricing_suggestion?: PricingSuggestion;
  
  // 메타데이터
  processing_time?: number;
  status?: 'processing' | 'completed' | 'failed';
  error_message?: string;

  // API 응답 구조
  success?: boolean;
  analysis?: AgricultureAnalysisResult;
  analysisId?: string;
  timestamp?: string;
}

export interface PricingSuggestion {
  market_price_range: string;
  value_proposition: string;
}

export interface ProductCharacteristics {
  color: string;
  size: 'large' | 'medium' | 'small';
  freshness: string;
  quality: string;
}

export interface AIAnalysisResult {
  product_name: string;
  category: string;
  confidence: number;
  characteristics: ProductCharacteristics;
  seasonality: string;
  origin_region: string;
  nutritional_highlights: string[];
  error?: string;
}

export interface CoupangStyleContent {
  title: string;
  short_description: string;
  detailed_description: string;
  key_features: string[];
  specifications: Record<string, string>;
  nutrition_info: Record<string, string>;
  usage_tips: string[];
  pricing_suggestion: PricingSuggestion;
}

export interface UploadProgress {
  progress: number;
  status: 'idle' | 'uploading' | 'analyzing' | 'generating' | 'completed' | 'error';
  message?: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  description?: string;
  typical_features?: Record<string, unknown>;
  created_at: string;
}

export interface AgricultureAnalysisResult {
  crop_type?: string;
  growth_stage?: string;
  health_status?: 'healthy' | 'warning' | 'critical';
  diseases?: string[];
  pests?: string[];
  nutritional_deficiency?: string[];
  recommendations?: string[];
  confidence_score?: number;
  analysis_summary?: string;
  marketing_content?: MarketingContent;
}

export interface MarketingContent {
  hero_message?: string;
  conclusion_first?: {
    freshness?: string;
    satisfaction?: string;
    effectiveness?: string;
    benefits?: string;
  };
  story_structure?: {
    beginning?: string;
    development?: string;
    climax?: string;
    conclusion?: string;
  };
  product_features?: Array<{
    icon?: string;
    title?: string;
    description?: string;
  }>;
  mz_appeal?: {
    sns_point?: string;
    homecafe_use?: string;
    gift_message?: string;
    trendy_keywords?: string[];
  };
  faq?: Array<{
    q?: string;
    a?: string;
  }>;
  reviews?: Array<{
    rating?: number;
    comment?: string;
    user?: string;
  }>;
  certifications?: string[];
  shipping_info?: string;
  caution?: string;
  seo_content?: {
    meta_description?: string;
    main_keywords?: string[];
    image_alt_texts?: string[];
  };
  regional_story?: string;
  seasonal_timing?: string;
  seasonal_message?: string;
  nutrition_benefits?: string[];
  health_benefits?: string;
}

// 상세페이지 관련 타입 정의 (새로 추가)
export interface ProductDetailPage {
  id?: string;
  created_at?: string;
  updated_at?: string;
  
  // 연관 분석 정보
  analysis_id?: string;
  crop_type: string;
  crop_name?: string;
  
  // 사용자 입력 상세 정보
  detail_info: DetailInfo;
  
  // 생성된 HTML 콘텐츠
  html_content: string;
  html_file_size?: number;
  
  // AI 생성 마케팅 콘텐츠 (검색/참조용)
  marketing_summary?: string;
  key_features?: string[];
  target_keywords?: string[];
  
  // 메타데이터
  download_count?: number;
  view_count?: number;
  is_template?: boolean;
  
  // 품질 점수
  quality_score?: number;
  
  // 사용자 피드백
  user_rating?: number;
  user_feedback?: string;
}

export interface DetailInfo {
  shipmentDate: string;    // 출고일
  stockQuantity: string;   // 재고 수량
  salesUnit: string;       // 판매 단위 (1kg, 1박스, 1포 등)
  price: string;          // 가격
}

// 상세페이지와 분석 결과를 조인한 뷰 타입
export interface DetailPageWithAnalysis extends ProductDetailPage {
  image_url?: string;
  confidence_score?: number;
  ai_analysis_result?: AgricultureAnalysisResult;
  product_category?: string;
}

// API 요청/응답 타입
export interface CreateDetailPageRequest {
  analysis_id: string;
  crop_type: string;
  crop_name?: string;
  detail_info: DetailInfo;
  html_content: string;
  marketing_summary?: string;
  key_features?: string[];
  target_keywords?: string[];
}

export interface UpdateDetailPageRequest {
  crop_name?: string;
  detail_info?: DetailInfo;
  html_content?: string;
  marketing_summary?: string;
  key_features?: string[];
  target_keywords?: string[];
  quality_score?: number;
  user_rating?: number;
  user_feedback?: string;
  is_template?: boolean;
}

export interface DetailPageResponse {
  success: boolean;
  data?: ProductDetailPage;
  error?: string;
}

export interface DetailPagesListResponse {
  success: boolean;
  data?: DetailPageWithAnalysis[];
  total?: number;
  error?: string;
}
