import { create } from 'zustand'
import { ProductAnalysis, UploadProgress } from '@/types'

interface AnalysisState {
  // 현재 업로드/분석 상태
  uploadProgress: UploadProgress
  currentFile: File | null
  currentImageUrl: string | null
  currentAnalysis: ProductAnalysis | null
  
  // 분석 결과 히스토리
  analysisHistory: ProductAnalysis[]
  
  // 액션들
  setUploadProgress: (progress: UploadProgress) => void
  setCurrentFile: (file: File | null) => void
  setCurrentImageUrl: (url: string | null) => void
  setCurrentAnalysis: (analysis: ProductAnalysis | null) => void
  addToHistory: (analysis: ProductAnalysis) => void
  clearCurrentAnalysis: () => void
  resetUploadState: () => void
}

const initialUploadProgress: UploadProgress = {
  progress: 0,
  status: 'idle',
  message: undefined
}

export const useAnalysisStore = create<AnalysisState>((set, get) => ({
  // 초기 상태
  uploadProgress: initialUploadProgress,
  currentFile: null,
  currentImageUrl: null,
  currentAnalysis: null,
  analysisHistory: [],

  // 업로드 진행 상태 업데이트
  setUploadProgress: (progress) => set({ uploadProgress: progress }),

  // 현재 선택된 파일 설정
  setCurrentFile: (file) => set({ currentFile: file }),

  // 현재 이미지 URL 설정
  setCurrentImageUrl: (url) => set({ currentImageUrl: url }),

  // 현재 분석 결과 설정
  setCurrentAnalysis: (analysis) => {
    set({ currentAnalysis: analysis })
    
    // 분석이 완료되면 히스토리에 추가
    if (analysis && analysis.status === 'completed') {
      const { analysisHistory } = get()
      const existingIndex = analysisHistory.findIndex(item => item.id === analysis.id)
      
      if (existingIndex >= 0) {
        // 기존 항목 업데이트
        const newHistory = [...analysisHistory]
        newHistory[existingIndex] = analysis
        set({ analysisHistory: newHistory })
      } else {
        // 새 항목 추가 (최신 순으로 정렬)
        set({ analysisHistory: [analysis, ...analysisHistory] })
      }
    }
  },

  // 히스토리에 분석 결과 추가
  addToHistory: (analysis) => {
    const { analysisHistory } = get()
    const existingIndex = analysisHistory.findIndex(item => item.id === analysis.id)
    
    if (existingIndex >= 0) {
      // 기존 항목 업데이트
      const newHistory = [...analysisHistory]
      newHistory[existingIndex] = analysis
      set({ analysisHistory: newHistory })
    } else {
      // 새 항목 추가 (최대 50개까지 유지)
      const newHistory = [analysis, ...analysisHistory].slice(0, 50)
      set({ analysisHistory: newHistory })
    }
  },

  // 현재 분석 결과 초기화
  clearCurrentAnalysis: () => set({ 
    currentAnalysis: null,
    currentFile: null,
    currentImageUrl: null,
    uploadProgress: initialUploadProgress
  }),

  // 업로드 상태 초기화
  resetUploadState: () => set({
    uploadProgress: initialUploadProgress,
    currentFile: null,
    currentImageUrl: null
  })
}))

// 편의 함수들
export const useCurrentAnalysis = () => useAnalysisStore(state => state.currentAnalysis)
export const useUploadProgress = () => useAnalysisStore(state => state.uploadProgress)
export const useAnalysisHistory = () => useAnalysisStore(state => state.analysisHistory)
