import { createClient } from '@supabase/supabase-js'
import { getSupabaseConfig, logEnvStatus } from './env-validation'

// 개발 환경에서 환경변수 상태 로그 출력
logEnvStatus()

const { url: supabaseUrl, anonKey: supabaseAnonKey } = getSupabaseConfig()

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  db: {
    schema: 'public',
  },
  global: {
    headers: {
      'x-connection-timeout': '30000'
    }
  }
})

// 클라이언트 생성 함수 export
export function createSupabaseClient() {
  return supabase
}

// 서버 사이드에서 사용할 관리자 권한 클라이언트
export function createAdminClient() {
  const { serviceRoleKey } = getSupabaseConfig()
  
  if (!serviceRoleKey) {
    throw new Error('Supabase Service Role Key가 환경변수에 설정되지 않았습니다.')
  }
  
  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  })
}

// 이미지 업로드 함수
export async function uploadImage(file: File, fileName: string) {
  const { data, error } = await supabase.storage
    .from('product-images')
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false
    })

  if (error) {
    throw new Error(`이미지 업로드 실패: ${error.message}`)
  }

  // 공개 URL 생성
  const { data: { publicUrl } } = supabase.storage
    .from('product-images')
    .getPublicUrl(data.path)

  return {
    path: data.path,
    publicUrl
  }
}

// 분석 결과 저장 함수
export async function saveAnalysisResult(analysisData: Record<string, unknown>) {
  const { data, error } = await supabase
    .from('product_analyses')
    .insert([analysisData])
    .select()
    .single()

  if (error) {
    throw new Error(`분석 결과 저장 실패: ${error.message}`)
  }

  return data
}

// 분석 결과 조회 함수
export async function getAnalysisResult(id: string) {
  const { data, error } = await supabase
    .from('product_analyses')
    .select('*')
    .eq('id', id)
    .single()

  if (error) {
    throw new Error(`분석 결과 조회 실패: ${error.message}`)
  }

  return data
}

// 최근 분석 결과 목록 조회
export async function getRecentAnalyses(limit: number = 10) {
  const { data, error } = await supabase
    .from('product_analyses')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error) {
    throw new Error(`분석 결과 목록 조회 실패: ${error.message}`)
  }

  return data
}
