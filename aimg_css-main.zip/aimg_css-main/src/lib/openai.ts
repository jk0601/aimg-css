import OpenAI from 'openai'

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
})

if (!process.env.OPENAI_API_KEY) {
  throw new Error('OPENAI_API_KEY가 환경변수에 설정되지 않았습니다.')
}

// 농산물 인식 프롬프트
const PRODUCT_ANALYSIS_PROMPT = `
농산물 이미지를 분석하고 다음 JSON 형식으로 응답해주세요:

{
  "product_name": "구체적인 농산물명 (예: 설향딸기, 부사사과)",
  "category": "농산물 카테고리 (과일, 채소, 곡물, 견과류 등)",
  "confidence": 0.95,
  "characteristics": {
    "color": "주요 색상",
    "size": "크기 추정 (large/medium/small)",
    "freshness": "신선도 상태",
    "quality": "품질 상태"
  },
  "seasonality": "제철 시기",
  "origin_region": "주요 생산지역 (추정)",
  "nutritional_highlights": ["주요 영양소1", "주요 영양소2"]
}

이미지가 농산물이 아니거나 식별이 어려운 경우:
{
  "error": "농산물을 식별할 수 없습니다",
  "confidence": 0.0
}

응답은 반드시 유효한 JSON 형식이어야 합니다.
`

// 쿠팡 스타일 상세페이지 생성 프롬프트
const COUPANG_STYLE_PROMPT = `
다음 농산물 정보를 바탕으로 쿠팡 스타일의 상품 상세페이지를 생성해주세요:

농산물 정보: {product_info}

다음 JSON 형식으로 응답해주세요:
{
  "title": "쿠팡 스타일 상품명 (키워드 최적화)",
  "short_description": "한 줄 요약 설명",
  "detailed_description": "상세 설명 (3-4 문단)",
  "key_features": [
    "✓ 특징1: 구체적 설명",
    "✓ 특징2: 구체적 설명",
    "✓ 특징3: 구체적 설명"
  ],
  "specifications": {
    "원산지": "생산지역",
    "중량/용량": "예상 중량",
    "보관방법": "보관 가이드",
    "유통기한": "권장 소비기간"
  },
  "nutrition_info": {
    "칼로리": "100g당 칼로리",
    "주요영양소": "영양소 정보"
  },
  "usage_tips": [
    "보관 방법",
    "섭취 방법",
    "조리 팁"
  ],
  "pricing_suggestion": {
    "market_price_range": "시장 가격대",
    "value_proposition": "가격 경쟁력 포인트"
  }
}

쿠팡 스타일 특징:
- 명확하고 직관적인 제목
- 핵심 특징을 불릿 포인트로 정리
- 실용적인 정보 중심
- 구매 결정에 도움되는 상세 정보 제공

응답은 반드시 유효한 JSON 형식이어야 합니다.
`

// 이미지 분석 함수
export async function analyzeProductImage(imageUrl: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: PRODUCT_ANALYSIS_PROMPT },
            {
              type: "image_url",
              image_url: {
                url: imageUrl,
                detail: "high"
              }
            }
          ]
        }
      ],
      max_tokens: 1000,
      temperature: 0.1,
    })

    const content = response.choices[0]?.message?.content
    if (!content) {
      throw new Error('AI 분석 결과를 받을 수 없습니다.')
    }

    // JSON 파싱 시도
    try {
      return JSON.parse(content)
    } catch {
      console.error('JSON 파싱 오류:', content)
      throw new Error('AI 응답을 파싱할 수 없습니다.')
    }
  } catch (error) {
    console.error('이미지 분석 오류:', error)
    throw new Error(`이미지 분석 실패: ${error instanceof Error ? error.message : '알 수 없는 오류'}`)
  }
}

// 쿠팡 스타일 상세페이지 생성 함수
export async function generateCoupangStyleContent(productInfo: Record<string, unknown>) {
  try {
    const prompt = COUPANG_STYLE_PROMPT.replace('{product_info}', JSON.stringify(productInfo, null, 2))
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 2000,
      temperature: 0.3,
    })

    const content = response.choices[0]?.message?.content
    if (!content) {
      throw new Error('상세페이지 생성 결과를 받을 수 없습니다.')
    }

    // JSON 파싱 시도
    try {
      return JSON.parse(content)
    } catch {
      console.error('JSON 파싱 오류:', content)
      throw new Error('상세페이지 생성 결과를 파싱할 수 없습니다.')
    }
  } catch (error) {
    console.error('상세페이지 생성 오류:', error)
    throw new Error(`상세페이지 생성 실패: ${error instanceof Error ? error.message : '알 수 없는 오류'}`)
  }
}
