// 환경변수 검증 유틸리티

interface EnvConfig {
  // Supabase 설정
  NEXT_PUBLIC_SUPABASE_URL: string
  NEXT_PUBLIC_SUPABASE_ANON_KEY: string
  SUPABASE_SERVICE_ROLE_KEY?: string
  
  // OpenAI 설정
  OPENAI_API_KEY?: string
  
  // 기본 애플리케이션 설정
  NEXT_PUBLIC_APP_URL: string
  NEXT_PUBLIC_MAX_FILE_SIZE: string
  
  // 이미지 처리 설정
  NEXT_PUBLIC_SUPPORTED_IMAGE_TYPES?: string
  NEXT_PUBLIC_IMAGE_QUALITY?: string
  NEXT_PUBLIC_MAX_IMAGE_WIDTH?: string
  NEXT_PUBLIC_MAX_IMAGE_HEIGHT?: string
  
  // AI 분석 설정
  NEXT_PUBLIC_AI_CONFIDENCE_THRESHOLD?: string
  NEXT_PUBLIC_MAX_ANALYSIS_TIME?: string
  
  // 사용자 경험 설정
  NEXT_PUBLIC_ENABLE_ANALYTICS?: string
  NEXT_PUBLIC_ENABLE_ERROR_REPORTING?: string
  NEXT_PUBLIC_DEFAULT_LANGUAGE?: string
  NEXT_PUBLIC_DEBUG_MODE?: string
}

export function validateEnvVariables(): EnvConfig {
  const requiredEnvVars = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'NEXT_PUBLIC_APP_URL'
  ]

  const missingVars: string[] = []
  const config: Partial<EnvConfig> = {}

  // 필수 환경변수 확인
  for (const varName of requiredEnvVars) {
    const value = process.env[varName]
    if (!value) {
      missingVars.push(varName)
    } else {
      config[varName as keyof EnvConfig] = value
    }
  }

  // 선택적 환경변수 확인
  const optionalVars = [
    'SUPABASE_SERVICE_ROLE_KEY',
    'OPENAI_API_KEY',
    'NEXT_PUBLIC_MAX_FILE_SIZE',
    'NEXT_PUBLIC_SUPPORTED_IMAGE_TYPES',
    'NEXT_PUBLIC_IMAGE_QUALITY',
    'NEXT_PUBLIC_MAX_IMAGE_WIDTH',
    'NEXT_PUBLIC_MAX_IMAGE_HEIGHT',
    'NEXT_PUBLIC_AI_CONFIDENCE_THRESHOLD',
    'NEXT_PUBLIC_MAX_ANALYSIS_TIME',
    'NEXT_PUBLIC_ENABLE_ANALYTICS',
    'NEXT_PUBLIC_ENABLE_ERROR_REPORTING',
    'NEXT_PUBLIC_DEFAULT_LANGUAGE',
    'NEXT_PUBLIC_DEBUG_MODE'
  ]

  for (const varName of optionalVars) {
    const value = process.env[varName]
    if (value) {
      config[varName as keyof EnvConfig] = value
    }
  }

  // 기본값 설정
  if (!config.NEXT_PUBLIC_MAX_FILE_SIZE) {
    config.NEXT_PUBLIC_MAX_FILE_SIZE = '10485760' // 10MB
  }
  
  if (!config.NEXT_PUBLIC_SUPPORTED_IMAGE_TYPES) {
    config.NEXT_PUBLIC_SUPPORTED_IMAGE_TYPES = 'image/jpeg,image/jpg,image/png,image/webp'
  }
  
  if (!config.NEXT_PUBLIC_IMAGE_QUALITY) {
    config.NEXT_PUBLIC_IMAGE_QUALITY = '80'
  }
  
  if (!config.NEXT_PUBLIC_MAX_IMAGE_WIDTH) {
    config.NEXT_PUBLIC_MAX_IMAGE_WIDTH = '2048'
  }
  
  if (!config.NEXT_PUBLIC_MAX_IMAGE_HEIGHT) {
    config.NEXT_PUBLIC_MAX_IMAGE_HEIGHT = '2048'
  }
  
  if (!config.NEXT_PUBLIC_AI_CONFIDENCE_THRESHOLD) {
    config.NEXT_PUBLIC_AI_CONFIDENCE_THRESHOLD = '0.7'
  }
  
  if (!config.NEXT_PUBLIC_MAX_ANALYSIS_TIME) {
    config.NEXT_PUBLIC_MAX_ANALYSIS_TIME = '30000' // 30초
  }
  
  if (!config.NEXT_PUBLIC_ENABLE_ANALYTICS) {
    config.NEXT_PUBLIC_ENABLE_ANALYTICS = 'false'
  }
  
  if (!config.NEXT_PUBLIC_ENABLE_ERROR_REPORTING) {
    config.NEXT_PUBLIC_ENABLE_ERROR_REPORTING = 'false'
  }
  
  if (!config.NEXT_PUBLIC_DEFAULT_LANGUAGE) {
    config.NEXT_PUBLIC_DEFAULT_LANGUAGE = 'ko'
  }
  
  if (!config.NEXT_PUBLIC_DEBUG_MODE) {
    config.NEXT_PUBLIC_DEBUG_MODE = process.env.NODE_ENV === 'development' ? 'true' : 'false'
  }

  if (missingVars.length > 0) {
    throw new Error(
      `다음 환경변수가 설정되지 않았습니다: ${missingVars.join(', ')}\n` +
      'SUPABASE_SETUP.md 파일을 참고하여 .env.local 파일을 생성해주세요.'
    )
  }

  return config as EnvConfig
}

export function getSupabaseConfig() {
  const config = validateEnvVariables()
  
  return {
    url: config.NEXT_PUBLIC_SUPABASE_URL,
    anonKey: config.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    serviceRoleKey: config.SUPABASE_SERVICE_ROLE_KEY
  }
}

export function getOpenAIConfig() {
  const config = validateEnvVariables()
  
  if (!config.OPENAI_API_KEY) {
    console.warn('⚠️ OPENAI_API_KEY가 설정되지 않았습니다. AI 분석 기능이 작동하지 않습니다.')
    return null
  }
  
  return {
    apiKey: config.OPENAI_API_KEY
  }
}

export function getAppConfig() {
  const config = validateEnvVariables()
  
  return {
    url: config.NEXT_PUBLIC_APP_URL,
    maxFileSize: parseInt(config.NEXT_PUBLIC_MAX_FILE_SIZE, 10),
    supportedImageTypes: config.NEXT_PUBLIC_SUPPORTED_IMAGE_TYPES?.split(',') || [],
    imageQuality: parseInt(config.NEXT_PUBLIC_IMAGE_QUALITY || '80', 10),
    maxImageWidth: parseInt(config.NEXT_PUBLIC_MAX_IMAGE_WIDTH || '2048', 10),
    maxImageHeight: parseInt(config.NEXT_PUBLIC_MAX_IMAGE_HEIGHT || '2048', 10),
    aiConfidenceThreshold: parseFloat(config.NEXT_PUBLIC_AI_CONFIDENCE_THRESHOLD || '0.7'),
    maxAnalysisTime: parseInt(config.NEXT_PUBLIC_MAX_ANALYSIS_TIME || '30000', 10),
    enableAnalytics: config.NEXT_PUBLIC_ENABLE_ANALYTICS === 'true',
    enableErrorReporting: config.NEXT_PUBLIC_ENABLE_ERROR_REPORTING === 'true',
    defaultLanguage: config.NEXT_PUBLIC_DEFAULT_LANGUAGE || 'ko',
    debugMode: config.NEXT_PUBLIC_DEBUG_MODE === 'true'
  }
}

// 개발 환경에서 환경변수 상태 출력
export function logEnvStatus() {
  if (process.env.NODE_ENV !== 'development') return
  
  try {
    const config = validateEnvVariables()
    const appConfig = getAppConfig()
    
    console.log('🌱 농업 AI Agent - 환경변수 설정 상태')
    console.log('='.repeat(50))
    
    // 필수 설정
    console.log('📋 필수 설정:')
    console.log(`   - Supabase URL: ${config.NEXT_PUBLIC_SUPABASE_URL}`)
    console.log(`   - App URL: ${config.NEXT_PUBLIC_APP_URL}`)
    console.log(`   - OpenAI API: ${config.OPENAI_API_KEY ? '✅ 설정됨' : '❌ 미설정'}`)
    console.log(`   - Service Role Key: ${config.SUPABASE_SERVICE_ROLE_KEY ? '✅ 설정됨' : '❌ 미설정'}`)
    
    // 이미지 처리 설정
    console.log('\n📸 이미지 처리 설정:')
    console.log(`   - 최대 파일 크기: ${(appConfig.maxFileSize / 1024 / 1024).toFixed(1)}MB`)
    console.log(`   - 지원 형식: ${appConfig.supportedImageTypes.join(', ')}`)
    console.log(`   - 이미지 품질: ${appConfig.imageQuality}%`)
    console.log(`   - 최대 해상도: ${appConfig.maxImageWidth}x${appConfig.maxImageHeight}`)
    
    // AI 분석 설정
    console.log('\n🤖 AI 분석 설정:')
    console.log(`   - 신뢰도 임계값: ${(appConfig.aiConfidenceThreshold * 100).toFixed(0)}%`)
    console.log(`   - 최대 분석 시간: ${appConfig.maxAnalysisTime / 1000}초`)
    
    // 기타 설정
    console.log('\n⚙️ 기타 설정:')
    console.log(`   - 기본 언어: ${appConfig.defaultLanguage}`)
    console.log(`   - 디버그 모드: ${appConfig.debugMode ? '✅ 활성화' : '❌ 비활성화'}`)
    console.log(`   - 분석 도구: ${appConfig.enableAnalytics ? '✅ 활성화' : '❌ 비활성화'}`)
    console.log(`   - 오류 리포팅: ${appConfig.enableErrorReporting ? '✅ 활성화' : '❌ 비활성화'}`)
    
    console.log('='.repeat(50))
    console.log('🚀 모든 설정이 완료되었습니다!')
    
  } catch (error) {
    console.log('🌱 농업 AI Agent - 환경변수 오류')
    console.log('=' .repeat(50))
    console.error('❌ 환경변수 오류:', error instanceof Error ? error.message : error)
    console.log('💡 해결 방법: SUPABASE_SETUP.md 파일을 참고하여 .env.local 파일을 생성해주세요.')
    console.log('=' .repeat(50))
  }
}
