import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// 파일 크기를 읽기 쉬운 형태로 변환
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes'
  
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

// 이미지 파일 형식 검증
export function isValidImageFile(file: File): boolean {
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
  return validTypes.includes(file.type)
}

// 이미지 파일 크기 검증 (최대 10MB)
export function isValidImageSize(file: File): boolean {
  const maxSize = 10 * 1024 * 1024 // 10MB
  return file.size <= maxSize
}

// 파일명 정리 (특수문자 제거, 공백을 언더스코어로 변경)
export function sanitizeFileName(fileName: string): string {
  return fileName
    .replace(/[^a-zA-Z0-9가-힣.\-_]/g, '_')
    .replace(/\s+/g, '_')
    .toLowerCase()
}

// 신뢰도 점수를 백분율로 변환
export function formatConfidence(confidence: number): string {
  return `${Math.round(confidence * 100)}%`
}

// 처리 시간을 읽기 쉬운 형태로 변환
export function formatProcessingTime(milliseconds: number): string {
  if (milliseconds < 1000) {
    return `${milliseconds}ms`
  }
  
  const seconds = Math.round(milliseconds / 1000)
  if (seconds < 60) {
    return `${seconds}초`
  }
  
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = seconds % 60
  return `${minutes}분 ${remainingSeconds}초`
}

// 날짜를 한국어 형식으로 포맷
export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleDateString('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 농산물 카테고리별 이모지 매핑
export function getCategoryEmoji(category: string): string {
  const emojiMap: Record<string, string> = {
    '과일': '🍎',
    '채소': '🥬',
    '곡물': '🌾',
    '견과류': '🥜',
    '허브': '🌿',
    '버섯': '🍄',
    '기타': '🥕'
  }
  
  return emojiMap[category] || '🥕'
}

// 모바일 디바이스 감지
export function isMobileDevice(): boolean {
  if (typeof window === 'undefined') return false
  
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent
  ) || window.innerWidth <= 768
}

// 카메라 지원 여부 확인
export function isCameraSupported(): boolean {
  if (typeof navigator === 'undefined') return false
  
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)
}

// 파일을 Blob URL로 변환
export function createBlobUrl(file: File): string {
  return URL.createObjectURL(file)
}

// Blob URL 해제
export function revokeBlobUrl(url: string): void {
  URL.revokeObjectURL(url)
}