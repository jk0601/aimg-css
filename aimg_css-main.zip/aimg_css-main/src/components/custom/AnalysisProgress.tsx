'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { useAnalysisStore } from '@/store/analysisStore'
import { cn } from '@/lib/utils'

export function AnalysisProgress() {
  const { uploadProgress } = useAnalysisStore()

  const steps = [
    {
      key: 'uploading',
      title: '이미지 업로드',
      description: '이미지를 서버에 업로드하고 있습니다',
      icon: '📤',
      progress: 25,
      subSteps: [
        '파일 검증 중...',
        '이미지 최적화 중...',
        '서버 업로드 중...'
      ]
    },
    {
      key: 'analyzing',
      title: 'AI 분석',
      description: 'GPT AI가 농산물을 인식하고 분석합니다',
      icon: '🤖',
      progress: 70,
      subSteps: [
        '이미지 전처리 중...',
        'AI 모델 분석 중...',
        '작물 특성 파악 중...',
        '마케팅 콘텐츠 생성 중...'
      ]
    },
    {
      key: 'generating',
      title: '상세페이지 생성',
      description: '전문적인 상세페이지를 완성하고 있습니다',
      icon: '✨',
      progress: 95,
      subSteps: [
        '스토리텔링 구성 중...',
        'SEO 최적화 중...',
        '최종 검토 중...'
      ]
    }
  ]

  const currentStepIndex = steps.findIndex(step => step.key === uploadProgress.status)
  const currentStep = steps[currentStepIndex]
  
  // 현재 단계의 서브 스텝을 순환하여 보여주기 위한 상태
  const [currentSubStepIndex, setCurrentSubStepIndex] = React.useState(0)
  
  React.useEffect(() => {
    if (currentStep?.subSteps && uploadProgress.status !== 'idle' && uploadProgress.status !== 'completed') {
      const interval = setInterval(() => {
        setCurrentSubStepIndex(prev => (prev + 1) % currentStep.subSteps.length)
      }, 2000) // 2초마다 서브 스텝 변경
      
      return () => clearInterval(interval)
    }
  }, [currentStep, uploadProgress.status])

  // early return을 hooks 호출 후에 배치
  if (uploadProgress.status === 'idle' || uploadProgress.status === 'completed') {
    return null
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center space-x-2">
          <span className="text-2xl">⚡</span>
          <span>AI 분석 진행 중</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">

        {/* 단계별 진행 상황 */}
        <div className="space-y-4">
          {steps.map((step, index) => {
            const isActive = step.key === uploadProgress.status
            const isCompleted = index < currentStepIndex
            const isPending = index > currentStepIndex

            return (
              <div
                key={step.key}
                className={cn(
                  "flex items-center space-x-4 p-3 rounded-lg transition-all",
                  isActive && "bg-blue-50 border border-blue-200",
                  isCompleted && "bg-green-50",
                  isPending && "bg-gray-50 opacity-60"
                )}
              >
                <div className={cn(
                  "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-lg",
                  isActive && "bg-blue-100",
                  isCompleted && "bg-green-100",
                  isPending && "bg-gray-100"
                )}>
                  {isCompleted ? '✅' : step.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <h4 className={cn(
                      "font-medium",
                      isActive && "text-blue-900",
                      isCompleted && "text-green-900",
                      isPending && "text-gray-500"
                    )}>
                      {step.title}
                    </h4>
                    
                    <Badge 
                      variant={
                        isCompleted ? "default" : 
                        isActive ? "secondary" : 
                        "outline"
                      }
                      className={cn(
                        isActive && "bg-blue-100 text-blue-800",
                        isCompleted && "bg-green-100 text-green-800"
                      )}
                    >
                      {isCompleted ? '완료' : isActive ? '진행 중' : '대기'}
                    </Badge>
                  </div>
                  
                  <p className={cn(
                    "text-sm mt-1",
                    isActive && "text-blue-700",
                    isCompleted && "text-green-700",
                    isPending && "text-gray-400"
                  )}>
                    {isActive && uploadProgress.message ? uploadProgress.message : step.description}
                  </p>
                </div>

                {isActive && (
                  <div className="flex-shrink-0">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* 전체 진행률 */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">전체 진행률</span>
            <span className="text-lg font-bold text-blue-600">
              {uploadProgress.progress}%
            </span>
          </div>
          <Progress 
            value={uploadProgress.progress} 
            className="w-full h-3"
          />
          
          {/* 현재 진행 중인 세부 작업 */}
          {currentStep && (
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                <span className="text-sm font-medium text-blue-800">
                  {currentStep.subSteps[currentSubStepIndex]}
                </span>
              </div>
              <div className="mt-2 text-xs text-blue-600">
                {currentStep.title} ({currentSubStepIndex + 1}/{currentStep.subSteps.length})
              </div>
            </div>
          )}
        </div>

        {/* 예상 소요 시간 및 상태 */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center space-x-4 text-sm">
            <div className="flex items-center space-x-1 text-gray-600">
              <span>⏱️</span>
              <span>예상 소요: {uploadProgress.status === 'uploading' ? '10-30초' : uploadProgress.status === 'analyzing' ? '15-25초' : '3-5초'}</span>
            </div>
            <div className="flex items-center space-x-1 text-green-600">
              <span>🚀</span>
              <span>AI 기반</span>
            </div>
          </div>
          <p className="text-sm text-gray-500">
            {uploadProgress.status === 'analyzing' 
              ? '🧠 AI가 농산물을 꼼꼼히 분석하고 전문적인 마케팅 콘텐츠를 생성하고 있습니다...'
              : '잠시만 기다려주세요. 최고 품질의 결과를 위해 열심히 작업 중입니다!'
            }
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
