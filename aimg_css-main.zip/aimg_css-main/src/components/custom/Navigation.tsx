'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export function Navigation() {
  const pathname = usePathname()

  const navItems = [
    {
      href: '/',
      label: '홈',
      description: '메인 페이지'
    },
    {
      href: '/analyze',
      label: '이미지 분석',
      description: '농산물 이미지 업로드 및 분석'
    }
  ]

  return (
    <nav className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* 로고 및 브랜드 */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-green-600 text-white font-bold">
              🌱
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold text-gray-900">농업 AI Agent</span>
              <span className="text-xs text-gray-500">RunMoA</span>
            </div>
          </Link>

          {/* 네비게이션 메뉴 */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={pathname === item.href ? "default" : "ghost"}
                  className={cn(
                    "relative",
                    pathname === item.href && "bg-green-600 hover:bg-green-700"
                  )}
                >
                  {item.label}
                  {item.href === '/analyze' && (
                    <Badge variant="secondary" className="ml-2 text-xs">
                      Beta
                    </Badge>
                  )}
                </Button>
              </Link>
            ))}
          </div>

          {/* 모바일 메뉴 버튼 */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <svg
                className="h-6 w-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
