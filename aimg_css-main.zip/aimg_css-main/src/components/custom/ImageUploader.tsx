'use client'

import { useCallback, useState, useRef, useEffect } from 'react'
import { useDropzone } from 'react-dropzone'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

import { Badge } from '@/components/ui/badge'
import { cn, formatFileSize, isValidImageFile, isValidImageSize, isMobileDevice, isCameraSupported } from '@/lib/utils'
import { useAnalysisStore } from '@/store/analysisStore'
import Image from 'next/image'

interface ImageUploaderProps {
  onUpload: (file: File) => Promise<void>
  className?: string
}

export function ImageUploader({ onUpload, className }: ImageUploaderProps) {
  const { uploadProgress, currentFile, setCurrentFile, setUploadProgress } = useAnalysisStore()
  const [preview, setPreview] = useState<string | null>(null)
  const [dragActive, setDragActive] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [cameraSupported, setCameraSupported] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // 모바일 및 카메라 지원 여부 확인
  useEffect(() => {
    setIsMobile(isMobileDevice())
    setCameraSupported(isCameraSupported())
  }, [])

  // currentFile이 null로 변경될 때 preview 초기화
  useEffect(() => {
    if (!currentFile && preview) {
      URL.revokeObjectURL(preview)
      setPreview(null)
    }
  }, [currentFile, preview])

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0]
    if (!file) {
      console.warn('⚠️ 파일이 선택되지 않았습니다.')
      return
    }

    console.log('📁 [파일 드롭] 업로드 시작:', {
      name: file.name,
      size: `${(file.size / 1024 / 1024).toFixed(2)}MB`,
      type: file.type,
      lastModified: new Date(file.lastModified).toISOString()
    })

    // 파일 유효성 검사
    if (!isValidImageFile(file)) {
      console.error('❌ 지원되지 않는 파일 형식:', file.type)
      setUploadProgress({
        progress: 0,
        status: 'error',
        message: '지원되지 않는 파일 형식입니다. JPG, PNG, WebP 파일만 업로드 가능합니다.'
      })
      return
    }

    if (!isValidImageSize(file)) {
      console.error('❌ 파일 크기 초과:', `${(file.size / 1024 / 1024).toFixed(2)}MB > 10MB`)
      setUploadProgress({
        progress: 0,
        status: 'error',
        message: '파일 크기가 너무 큽니다. 10MB 이하의 파일만 업로드 가능합니다.'
      })
      return
    }

    // 미리보기 생성
    const previewUrl = URL.createObjectURL(file)
    setPreview(previewUrl)
    setCurrentFile(file)

    // 업로드 진행 상태 초기화
    setUploadProgress({
      progress: 0,
      status: 'uploading',
      message: '이미지를 업로드하는 중...'
    })

    console.log('🚀 [API 호출] onUpload 함수 시작...')
    
    try {
      await onUpload(file)
      console.log('✅ [API 호출] onUpload 함수 성공!')
    } catch (error) {
      console.error('🚨 [ImageUploader] 업로드 오류 상세:', {
        error,
        errorMessage: error instanceof Error ? error.message : 'Unknown error',
        errorStack: error instanceof Error ? error.stack : undefined,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type
      })
      
      setUploadProgress({
        progress: 0,
        status: 'error',
        message: error instanceof Error ? error.message : '업로드 중 오류가 발생했습니다.'
      })
    }
  }, [onUpload, setCurrentFile, setUploadProgress])

  // 카메라 시작
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // 후면 카메라 우선
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      })
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream
        setShowCamera(true)
      }
    } catch (error) {
      console.error('카메라 접근 오류:', error)
      setUploadProgress({
        progress: 0,
        status: 'error',
        message: '카메라에 접근할 수 없습니다. 권한을 확인해주세요.'
      })
    }
  }, [setUploadProgress])

  // 카메라 정지
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    setShowCamera(false)
  }, [])

  // 사진 촬영
  const capturePhoto = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext('2d')

    if (!context) return

    // 캔버스 크기를 비디오 크기에 맞춤
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // 비디오 프레임을 캔버스에 그리기
    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    // 캔버스를 Blob으로 변환
    canvas.toBlob(async (blob) => {
      if (!blob) return

      // Blob을 File 객체로 변환
      const file = new File([blob], `camera-capture-${Date.now()}.jpg`, {
        type: 'image/jpeg'
      })

      // 카메라 정지
      stopCamera()

      // 미리보기 생성
      const previewUrl = URL.createObjectURL(file)
      setPreview(previewUrl)
      setCurrentFile(file)

      // 파일 유효성 검사 후 업로드
      if (isValidImageFile(file) && isValidImageSize(file)) {
        try {
          await onUpload(file)
        } catch (error) {
          setUploadProgress({
            progress: 0,
            status: 'error',
            message: error instanceof Error ? error.message : '업로드 중 오류가 발생했습니다.'
          })
        }
      } else {
        setUploadProgress({
          progress: 0,
          status: 'error',
          message: '촬영된 이미지가 유효하지 않습니다.'
        })
      }
    }, 'image/jpeg', 0.9)
  }, [onUpload, setCurrentFile, setUploadProgress, stopCamera])

  // 컴포넌트 언마운트 시 카메라 정리
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [stopCamera])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.webp']
    },
    maxFiles: 1,
    onDragEnter: () => setDragActive(true),
    onDragLeave: () => setDragActive(false)
  })

  const clearFile = () => {
    setCurrentFile(null)
    setPreview(null)
    setUploadProgress({
      progress: 0,
      status: 'idle'
    })
    if (preview) {
      URL.revokeObjectURL(preview)
    }
  }

  const isUploading = uploadProgress.status === 'uploading' || 
                     uploadProgress.status === 'analyzing' || 
                     uploadProgress.status === 'generating'

  return (
    <div className={cn("w-full max-w-2xl mx-auto", className)}>
      {/* 카메라 모드 */}
      {showCamera && (
        <Card className="overflow-hidden mb-4">
          <CardContent className="p-0">
            <div className="relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-auto max-h-[400px] object-cover"
              />
              <canvas
                ref={canvasRef}
                className="hidden"
              />
              
              {/* 카메라 컨트롤 */}
              <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
                <Button
                  onClick={capturePhoto}
                  size="lg"
                  className="bg-white text-black hover:bg-gray-100 rounded-full w-16 h-16 p-0"
                >
                  📷
                </Button>
                <Button
                  onClick={stopCamera}
                  variant="outline"
                  size="lg"
                  className="bg-white text-black hover:bg-gray-100 rounded-full w-16 h-16 p-0"
                >
                  ✕
                </Button>
              </div>
              
              {/* 촬영 가이드 */}
              <div className="absolute top-4 left-4 right-4">
                <div className="bg-black bg-opacity-50 text-white px-3 py-2 rounded-lg text-sm text-center">
                  📱 농산물을 화면 중앙에 맞춰주세요
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {!currentFile && !showCamera ? (
        <Card className={cn(
          "border-2 border-dashed transition-all duration-200 cursor-pointer hover:border-green-400",
          dragActive || isDragActive ? "border-green-500 bg-green-50" : "border-gray-300",
          "min-h-[300px] flex items-center justify-center"
        )}>
          <CardContent className="p-8">
            <div {...getRootProps()} className="text-center space-y-4">
              <input {...getInputProps()} />
              
              <div className="text-6xl mb-4">
                {dragActive || isDragActive ? '📤' : '📸'}
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-semibold text-gray-900">
                  {dragActive || isDragActive 
                    ? '여기에 이미지를 놓으세요' 
                    : '농산물 이미지를 업로드하세요'
                  }
                </h3>
                <p className="text-gray-600">
                  드래그 앤 드롭하거나 클릭해서 파일을 선택하세요
                </p>
              </div>

              <div className="flex flex-wrap justify-center gap-2 mt-4">
                <Badge variant="secondary">JPG</Badge>
                <Badge variant="secondary">PNG</Badge>
                <Badge variant="secondary">WebP</Badge>
                <Badge variant="outline">최대 10MB</Badge>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 mt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="flex-1"
                  disabled={isUploading}
                >
                  📁 파일 선택
                </Button>
                
                {isMobile && cameraSupported && (
                  <Button 
                    type="button" 
                    variant="outline" 
                    className="flex-1"
                    onClick={startCamera}
                    disabled={isUploading}
                  >
                    📷 카메라로 촬영
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="space-y-4">
              {/* 이미지 미리보기 */}
              {preview && (
                <div className="relative">
                  <Image
                    src={preview}
                    alt="업로드된 이미지"
                    width={400}
                    height={256}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                  {!isUploading && (
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={clearFile}
                    >
                      ✕
                    </Button>
                  )}
                </div>
              )}

              {/* 파일 정보 */}
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  <div className="text-2xl flex-shrink-0">📄</div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-900 truncate" title={currentFile?.name}>
                      {currentFile?.name}
                    </p>
                    <p className="text-sm text-gray-500">
                      {currentFile?.size ? formatFileSize(currentFile.size) : ''}
                    </p>
                  </div>
                </div>
                
                {uploadProgress.status === 'completed' ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={clearFile}
                    className="ml-2 flex-shrink-0"
                  >
                    📸 새 파일
                  </Button>
                ) : (
                  <Badge 
                    variant={uploadProgress.status === 'error' ? 'destructive' : 'secondary'}
                    className="ml-2 flex-shrink-0"
                  >
                    {uploadProgress.status === 'idle' && '대기 중'}
                    {uploadProgress.status === 'uploading' && '업로드 중'}
                    {uploadProgress.status === 'analyzing' && 'AI 분석 중'}
                    {uploadProgress.status === 'generating' && '상세페이지 생성 중'}
                    {uploadProgress.status === 'error' && '오류'}
                  </Badge>
                )}
              </div>

              {/* 에러 메시지만 표시 (진행 상태는 AnalysisProgress에서 처리) */}
              {uploadProgress.status === 'error' && uploadProgress.message && (
                <div className="space-y-2">
                  <p className="text-sm text-center text-red-600">
                    {uploadProgress.message}
                  </p>
                </div>
              )}

              {/* 재시도 버튼 */}
              {uploadProgress.status === 'error' && (
                <div className="flex justify-center space-x-2">
                  <Button
                    variant="outline"
                    onClick={clearFile}
                  >
                    다시 선택
                  </Button>
                  <Button
                    onClick={() => currentFile && onUpload(currentFile)}
                  >
                    재시도
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
