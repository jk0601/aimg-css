import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';
import type { CreateDetailPageRequest, DetailPageResponse, DetailPagesListResponse } from '@/types';

// POST: 상세페이지 저장
export async function POST(request: NextRequest) {
  try {
    const body: CreateDetailPageRequest = await request.json();
    
    // 필수 필드 검증
    if (!body.analysis_id || !body.crop_type || !body.html_content || !body.detail_info) {
      return NextResponse.json({
        success: false,
        error: '필수 필드가 누락되었습니다. (analysis_id, crop_type, html_content, detail_info)'
      } as DetailPageResponse, { status: 400 });
    }

    const supabase = createAdminClient();
    
    // HTML 파일 크기 계산
    const htmlFileSize = new Blob([body.html_content]).size;
    
    // 마케팅 요약 자동 생성 (HTML에서 추출)
    const marketingSummary = body.marketing_summary || 
      body.html_content.replace(/<[^>]*>/g, '').substring(0, 200) + '...';
    // 확실히 존재하는 컬럼들만 사용 - 모든 데이터를 JSON으로 저장

    // 새로 추가된 컬럼들을 사용해서 저장
    const { data, error } = await supabase
      .from('product_analyses')
      .update({
        crop_type: body.crop_type,
        crop_name: body.crop_name,
        detail_info: body.detail_info,
        html_content: body.html_content,
        marketing_content: {
          marketing_summary: marketingSummary,
          key_features: body.key_features,
          target_keywords: body.target_keywords,
          saved_at: new Date().toISOString()
        },
        marketing_summary: marketingSummary,
        key_features: body.key_features,
        target_keywords: body.target_keywords,
        html_file_size: htmlFileSize,
        download_count: 0,
        updated_at: new Date().toISOString()
      })
      .eq('id', body.analysis_id)
      .select();

    const savedRecord = data?.[0] || null;

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json({
        success: false,
        error: `상세페이지 저장에 실패했습니다: ${error.message}`
      } as DetailPageResponse, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      data: savedRecord
    } as DetailPageResponse);

  } catch (error) {
    console.error('Detail page save error:', error);
    return NextResponse.json({
      success: false,
      error: '상세페이지 저장 중 오류가 발생했습니다.'
    } as DetailPageResponse, { status: 500 });
  }
}

// GET: 상세페이지 목록 조회
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const cropType = searchParams.get('crop_type');
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = parseInt(searchParams.get('offset') || '0');

    console.log('GET request params:', { cropType, limit, offset });

    const supabase = createAdminClient();
    
    // 전체 데이터 조회 (필터링 없이)
    const { data: allData, error: allError } = await supabase
      .from('product_analyses')
      .select('*')
      .order('created_at', { ascending: false });

    console.log('=== 디버깅 정보 ===');
    console.log('전체 데이터 개수:', allData?.length);
    console.log('HTML 콘텐츠가 있는 데이터:', allData?.filter(item => item.html_content)?.length);
    console.log('요청된 offset:', offset, 'limit:', limit);

    if (allError) {
      console.error('All data query error:', allError);
      return NextResponse.json({
        success: false,
        error: `전체 데이터 조회에 실패했습니다: ${allError.message}`
      } as DetailPagesListResponse, { status: 500 });
    }

    // HTML 콘텐츠가 있는 것만 필터링
    const filteredData = allData?.filter(item => item.html_content && item.html_content.trim() !== '') || [];
    const totalCount = filteredData.length;

    console.log('필터링된 데이터 개수:', totalCount);

    // 페이지네이션 적용
    const paginatedData = filteredData.slice(offset, offset + limit);

    console.log('페이지네이션 결과:', paginatedData.length, '개');
    console.log('반환할 데이터 ID들:', paginatedData.map(item => item.id));

    return NextResponse.json({
      success: true,
      data: paginatedData,
      total: totalCount
    } as DetailPagesListResponse);

  } catch (error) {
    console.error('Detail pages list error:', error);
    return NextResponse.json({
      success: false,
      error: '상세페이지 목록 조회 중 오류가 발생했습니다.'
    } as DetailPagesListResponse, { status: 500 });
  }
}
