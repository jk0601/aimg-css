import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseClient } from '@/lib/supabase';
import type { DetailPageResponse } from '@/types';

// POST: 다운로드 카운트 증가
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const supabase = createSupabaseClient();
    
    // 다운로드 카운트 증가 함수 호출
    const { error: rpcError } = await supabase.rpc('increment_page_downloads', { 
      analysis_id: id 
    });

    if (rpcError) {
      console.error('RPC error:', rpcError);
      return NextResponse.json({
        success: false,
        error: `다운로드 카운트 업데이트에 실패했습니다: ${rpcError.message}`
      } as DetailPageResponse, { status: 500 });
    }

    // 업데이트된 데이터 조회
    const { data, error } = await supabase
      .from('product_analyses')
      .select('id, download_count, html_content')
      .eq('id', id);

    const record = data?.[0] || null;

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json({
        success: false,
        error: `상세페이지 조회에 실패했습니다: ${error.message}`
      } as DetailPageResponse, { status: 500 });
    }

    if (!record || !record.html_content) {
      return NextResponse.json({
        success: false,
        error: '다운로드할 상세페이지를 찾을 수 없습니다.'
      } as DetailPageResponse, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: record
    } as DetailPageResponse);

  } catch (error) {
    console.error('Download count error:', error);
    return NextResponse.json({
      success: false,
      error: '다운로드 카운트 업데이트 중 오류가 발생했습니다.'
    } as DetailPageResponse, { status: 500 });
  }
}
