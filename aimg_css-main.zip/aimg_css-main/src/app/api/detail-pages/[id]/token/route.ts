import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';
import { randomBytes } from 'crypto';

// POST: 특정 상세페이지에 대한 접근 토큰 생성
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const supabase = createAdminClient();

    // 해당 상세페이지가 존재하는지 확인
    const { data: pageData, error: pageError } = await supabase
      .from('product_analyses')
      .select('id, crop_type, crop_name, html_content')
      .eq('id', id);

    const pageRecord = pageData?.[0] || null;

    if (pageError || !pageRecord || !pageRecord.html_content) {
      return NextResponse.json({ 
        success: false, 
        error: '상세페이지를 찾을 수 없거나 HTML 콘텐츠가 없습니다.' 
      }, { status: 404 });
    }

    // 고유 토큰 생성 (32바이트 랜덤)
    const token = randomBytes(32).toString('hex');
    
    // 토큰 만료 시간 (24시간 후)
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    // 토큰 정보를 데이터베이스에 저장 (새 테이블 필요)
    // 임시로 기존 테이블의 JSONB 컬럼 활용
    const tokenData = {
      token,
      page_id: id,
      expires_at: expiresAt.toISOString(),
      created_at: new Date().toISOString(),
      access_count: 0
    };

    // 기존 토큰 정보 가져오기
    const { data: existingData } = await supabase
      .from('product_analyses')
      .select('marketing_content')
      .eq('id', id);

    const existingRecord = existingData?.[0] || null;

    // 토큰 정보 저장
    const { error: updateError } = await supabase
      .from('product_analyses')
      .update({
        marketing_content: {
          ...existingRecord?.marketing_content,
          access_tokens: [
            ...(existingRecord?.marketing_content?.access_tokens || []),
            tokenData
          ]
        }
      })
      .eq('id', id);

    if (updateError) {
      console.error('토큰 저장 오류:', updateError);
      return NextResponse.json({ 
        success: false, 
        error: '토큰 생성에 실패했습니다.' 
      }, { status: 500 });
    }

    // 접근 URL 생성
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const accessUrl = `${baseUrl}/api/html-content/${token}`;

    return NextResponse.json({
      success: true,
      data: {
        token,
        access_url: accessUrl,
        expires_at: expiresAt.toISOString(),
        page_info: {
          id: pageRecord.id,
          crop_type: pageRecord.crop_type,
          crop_name: pageRecord.crop_name
        }
      }
    });

  } catch (error) {
    console.error('토큰 생성 API 오류:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '알 수 없는 오류 발생' 
    }, { status: 500 });
  }
}
