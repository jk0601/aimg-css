import { NextRequest, NextResponse } from 'next/server';
import { createSupabaseClient, createAdminClient } from '@/lib/supabase';
import type { DetailPageResponse } from '@/types';

// GET: 특정 상세페이지 조회
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const supabase = createSupabaseClient();
    
    const { data, error } = await supabase
      .from('product_analyses')
      .select('*')
      .eq('id', id);

    const record = data?.[0] || null;

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json({
        success: false,
        error: `상세페이지 조회에 실패했습니다: ${error.message}`
      } as DetailPageResponse, { status: 500 });
    }

    if (!record) {
      return NextResponse.json({
        success: false,
        error: '상세페이지를 찾을 수 없습니다.'
      } as DetailPageResponse, { status: 404 });
    }

    // 조회수 증가
    await supabase.rpc('increment_page_views', { analysis_id: id });

    return NextResponse.json({
      success: true,
      data: record
    } as DetailPageResponse);

  } catch (error) {
    console.error('Detail page get error:', error);
    return NextResponse.json({
      success: false,
      error: '상세페이지 조회 중 오류가 발생했습니다.'
    } as DetailPageResponse, { status: 500 });
  }
}

// PUT: 상세페이지 수정
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const supabase = createSupabaseClient();
    
    // 업데이트할 필드들만 추출
    const updateData: Record<string, unknown> = {
      updated_at: new Date().toISOString()
    };

    // 선택적으로 업데이트할 필드들
    if (body.crop_name !== undefined) updateData.crop_name = body.crop_name;
    if (body.detail_info !== undefined) updateData.detail_info = body.detail_info;
    if (body.html_content !== undefined) {
      updateData.html_content = body.html_content;
      updateData.html_file_size = new Blob([body.html_content]).size;
    }
    if (body.marketing_summary !== undefined) updateData.marketing_summary = body.marketing_summary;
    if (body.key_features !== undefined) updateData.key_features = body.key_features;
    if (body.target_keywords !== undefined) updateData.target_keywords = body.target_keywords;
    if (body.quality_score !== undefined) updateData.quality_score = body.quality_score;
    if (body.user_rating !== undefined) updateData.user_rating = body.user_rating;
    if (body.user_feedback !== undefined) updateData.user_feedback = body.user_feedback;
    if (body.is_template !== undefined) updateData.is_template = body.is_template;

    const { data, error } = await supabase
      .from('product_analyses')
      .update(updateData)
      .eq('id', id)
      .select();

    const updatedRecord = data?.[0] || null;

    if (error) {
      console.error('Supabase error:', error);
      return NextResponse.json({
        success: false,
        error: `상세페이지 수정에 실패했습니다: ${error.message}`
      } as DetailPageResponse, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      data: updatedRecord
    } as DetailPageResponse);

  } catch (error) {
    console.error('Detail page update error:', error);
    return NextResponse.json({
      success: false,
      error: '상세페이지 수정 중 오류가 발생했습니다.'
    } as DetailPageResponse, { status: 500 });
  }
}

// DELETE: 상세페이지 삭제
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const deleteType = searchParams.get('type') || 'soft'; // 'soft' 또는 'hard'

    console.log('DELETE request:', { id, deleteType });

    const supabase = createAdminClient(); // 관리자 권한으로 삭제
    
    if (deleteType === 'hard') {
      // 먼저 삭제할 레코드 정보 조회
      const { data: recordToDelete, error: fetchError } = await supabase
        .from('product_analyses')
        .select('*')
        .eq('id', id);

      const record = recordToDelete?.[0] || null;

      if (fetchError || !record) {
        console.error('Record fetch error:', fetchError);
        return NextResponse.json({
          success: false,
          error: '삭제할 상세페이지를 찾을 수 없습니다.'
        } as DetailPageResponse, { status: 404 });
      }

      // 완전 삭제 (레코드 자체를 삭제)
      const { error } = await supabase
        .from('product_analyses')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Delete error:', error);
        return NextResponse.json({
          success: false,
          error: `상세페이지 완전 삭제에 실패했습니다: ${error.message}`
        } as DetailPageResponse, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        data: record,
        message: '상세페이지가 완전히 삭제되었습니다.'
      } as DetailPageResponse);
    } else {
      // 소프트 삭제 (HTML 콘텐츠만 제거, 분석 결과는 보존)
      const { data, error } = await supabase
        .from('product_analyses')
        .update({
          html_content: null,
          html_file_size: null,
          detail_info: null,
          marketing_summary: null,
          key_features: [],
          target_keywords: [],
          download_count: 0,
          is_template: false,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select();

      const updatedRecord = data?.[0] || null;

      if (error) {
        console.error('Supabase error:', error);
        return NextResponse.json({
          success: false,
          error: `상세페이지 삭제에 실패했습니다: ${error.message}`
        } as DetailPageResponse, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        data: updatedRecord,
        message: '상세페이지가 삭제되었습니다. (분석 결과는 보존됨)'
      } as DetailPageResponse);
    }

  } catch (error) {
    console.error('Detail page delete error:', error);
    return NextResponse.json({
      success: false,
      error: '상세페이지 삭제 중 오류가 발생했습니다.'
    } as DetailPageResponse, { status: 500 });
  }
}
