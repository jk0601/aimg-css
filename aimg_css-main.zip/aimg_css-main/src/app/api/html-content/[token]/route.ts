import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';

// GET: 토큰으로 HTML 콘텐츠 조회
export async function GET(request: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params;
    const supabase = createAdminClient();

    // 모든 상세페이지에서 해당 토큰 찾기
    const { data: pages, error: searchError } = await supabase
      .from('product_analyses')
      .select('id, crop_type, crop_name, html_content, marketing_content')
      .not('marketing_content', 'is', null);

    if (searchError) {
      console.error('토큰 검색 오류:', searchError);
      return NextResponse.json({ 
        success: false, 
        error: '토큰 검색에 실패했습니다.' 
      }, { status: 500 });
    }

    // 토큰 매칭 및 유효성 검사
    let matchedPage = null;
    let tokenInfo = null;

    for (const page of pages || []) {
      const tokens = page.marketing_content?.access_tokens || [];
      const foundToken = tokens.find((t: { token: string; expires_at: string }) => t.token === token);
      
      if (foundToken) {
        // 토큰 만료 확인
        const expiresAt = new Date(foundToken.expires_at);
        const now = new Date();
        
        if (now > expiresAt) {
          return NextResponse.json({ 
            success: false, 
            error: '토큰이 만료되었습니다.' 
          }, { status: 401 });
        }
        
        matchedPage = page;
        tokenInfo = foundToken;
        break;
      }
    }

    if (!matchedPage || !tokenInfo) {
      return NextResponse.json({ 
        success: false, 
        error: '유효하지 않은 토큰입니다.' 
      }, { status: 404 });
    }

    // HTML 콘텐츠가 있는지 확인
    if (!matchedPage.html_content) {
      return NextResponse.json({ 
        success: false, 
        error: 'HTML 콘텐츠가 없습니다.' 
      }, { status: 404 });
    }

    // 접근 횟수 증가
    const updatedTokens = matchedPage.marketing_content.access_tokens.map((t: { token: string; access_count?: number }) => 
      t.token === token ? { ...t, access_count: (t.access_count || 0) + 1 } : t
    );

    await supabase
      .from('product_analyses')
      .update({
        marketing_content: {
          ...matchedPage.marketing_content,
          access_tokens: updatedTokens
        }
      })
      .eq('id', matchedPage.id);

    // HTML 콘텐츠 반환
    return NextResponse.json({
      success: true,
      data: {
        html_content: matchedPage.html_content,
        page_info: {
          id: matchedPage.id,
          crop_type: matchedPage.crop_type,
          crop_name: matchedPage.crop_name
        },
        token_info: {
          access_count: (tokenInfo.access_count || 0) + 1,
          expires_at: tokenInfo.expires_at
        }
      }
    });

  } catch (error) {
    console.error('HTML 콘텐츠 조회 API 오류:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '알 수 없는 오류 발생' 
    }, { status: 500 });
  }
}

// OPTIONS: CORS 지원
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
