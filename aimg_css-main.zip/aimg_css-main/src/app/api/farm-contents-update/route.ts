import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';

// POST: 회사 시스템에서 HTML 콘텐츠 수신 (단순 수신용)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { token, description } = body;

    console.log('📥 [회사 API] HTML 수신 성공:', {
      token: token?.substring(0, 20) + '...',
      contentLength: description?.length || 0,
      timestamp: new Date().toISOString()
    });

    // 필수 파라미터 확인
    if (!token || !description) {
      console.error('❌ [회사 API] 필수 파라미터 누락:', { token: !!token, description: !!description });
      return NextResponse.json({
        success: false,
        error: '토큰과 HTML 콘텐츠가 필요합니다.'
      }, { status: 400 });
    }

    // 🎉 성공 응답 (데이터베이스 저장 없이)
    // 실제 회사 시스템에서는 여기서 에디터에 HTML을 표시할 것입니다
    console.log('✅ [회사 API] HTML이 성공적으로 전달되었습니다!');
    console.log('📄 [HTML 미리보기]', description.substring(0, 200) + '...');

    return NextResponse.json({
      success: true,
      message: 'HTML 콘텐츠가 성공적으로 수신되었습니다.',
      description: description, // ← 회사 에디터가 사용할 HTML 콘텐츠
      item_id: `temp-${Date.now()}`, // 임시 ID
      data: {
        token: token,
        content_length: description.length,
        received_at: new Date().toISOString(),
        status: 'received'
      }
    });

  } catch (error) {
    console.error('❌ [회사 API] 서버 오류:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : '알 수 없는 서버 오류가 발생했습니다.'
    }, { status: 500 });
  }
}

// OPTIONS: CORS 지원
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
