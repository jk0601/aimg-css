import { NextRequest, NextResponse } from 'next/server';
import { openai } from '@/lib/openai';
// Supabase Storage 대신 Base64 사용으로 주석 처리
// import { createSupabaseClient } from '@/lib/supabase';

// Vercel 서버리스 함수 타임아웃 설정 (최대 60초)
export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const imageFile = formData.get('image') as File;
    const analysisType = (formData.get('analysisType') as string) || 'general';

    // 이미지 파일 검증
    if (!imageFile) {
      return NextResponse.json(
        { error: '분석할 이미지 파일이 필요합니다.' },
        { status: 400 }
      );
    }

    // 이미지를 Base64로 변환 (Supabase 타임아웃 우회)
    console.log('📷 이미지를 Base64로 변환 중...');
    
    const arrayBuffer = await imageFile.arrayBuffer();
    const base64String = Buffer.from(arrayBuffer).toString('base64');
    const imageUrl = `data:${imageFile.type};base64,${base64String}`;
    
    console.log(`✅ Base64 변환 성공: ${(base64String.length / 1024 / 1024).toFixed(2)}MB`);
    
    const imageSize = imageFile.size;

    // 분석 타입에 따른 프롬프트 설정
    const getAnalysisPrompt = (type: string) => {
      const basePrompt = `[역할(Role)]
당신은 SEO 최적화와 MZ세대 감성 마케팅에 특화된 상세페이지 기획 전문가이자 농업 전문가입니다.
제품의 특성을 분석하여 스토리텔링·레트로 감성·실용 정보를 결합한 트렌디하고 구매 전환율 높은 상세페이지를 제작합니다.

[목표(Objective)]
1. 5:3:2 프레임 적용: 50% 실용 정보, 30% 감성·스토리텔링, 20% 레트로/문화적 요소
2. MZ세대(20~30대)의 가치·취향·소비 패턴 반영
3. 기승전결 구조 또는 결론부터 말하기 방식 적용
4. SEO 최적화 요소 포함

**중요: 반드시 유효한 JSON만 응답하세요. 다른 텍스트는 포함하지 마세요.**

{
  "crop_type": "구체적인 작물명 (예: 바나나, 토마토, 상추, 사과 등)",
  "growth_stage": "성장 단계 (발아기/성장기/개화기/결실기/성숙기)",
  "health_status": "healthy",
  "diseases": [],
  "pests": [],
  "nutritional_deficiency": [],
  "recommendations": ["구체적인 관리 방법"],
  "confidence_score": 85,
  "analysis_summary": "이미지에서 관찰되는 작물의 상태에 대한 상세한 설명",
  "marketing_content": {
    "hero_message": "감성적이고 매력적인 히어로 메시지 (예: 오늘 아침, 갓 수확한 블루베리가 당신 집 문 앞에 도착합니다)",
    "conclusion_first": {
      "freshness": "신선도 핵심 포인트 (예: 새벽에 딴 블루베리 → 오후엔 내 손에)",
      "satisfaction": "만족도 핵심 포인트 (예: 국산이라 가능한 달콤+탱글 조합)",
      "effectiveness": "효과/활용도 핵심 포인트 (예: 홈카페, 건강 간식, 베이킹까지 다 되는 만능템)",
      "benefits": "혜택 핵심 포인트 (예: 500g/1kg 옵션, 첫 구매 무료배송)"
    },
    "story_structure": {
      "beginning": "개인적 경험이나 추억으로 시작하는 스토리 (기) - 1인칭 가능",
      "development": "왜 이 제품을 만들게 되었는지, 산지나 농법의 특징 (승)",
      "climax": "제품의 핵심 특징 3가지를 나열 (전)",
      "conclusion": "인증, 배송, FAQ, 주의사항 등 마무리 정보 (결)"
    },
    "product_features": [
      {"icon": "🔸", "title": "특징 1", "description": "구체적인 설명"},
      {"icon": "🔸", "title": "특징 2", "description": "구체적인 설명"},
      {"icon": "🔸", "title": "특징 3", "description": "구체적인 설명"}
    ],
    "mz_appeal": {
      "sns_point": "SNS에 올리기 좋은 포인트",
      "homecafe_use": "홈카페나 요리에 활용하는 방법",
      "gift_message": "선물용으로 좋은 이유",
      "trendy_keywords": ["MZ세대가 좋아할 키워드 3-4개"]
    },
    "faq": [
      {"q": "보관은 어떻게 하나요?", "a": "구체적인 보관 방법과 기간"},
      {"q": "당도나 맛은 어떤가요?", "a": "해당 작물의 맛 특징"},
      {"q": "언제 받을 수 있나요?", "a": "배송 관련 정보"}
    ],
    "certifications": ["인증 정보나 안전 관련 내용"],
    "shipping_info": "배송 관련 상세 정보",
    "caution": "주의사항이나 고지사항",
    "seo_content": {
      "meta_description": "150-160자 내외의 메타 디스크립션",
      "main_keywords": ["메인 키워드 2-3개"],
      "image_alt_texts": [
        "갓 수확한 [작물명] 클로즈업",
        "[산지명] 농가의 [작물명] 밭",
        "[활용법] 이미지",
        "[작물명] 포장 박스"
      ]
    },
    "regional_story": "산지의 특징이나 지역적 장점 (예: 구례는 하루 일조량이 길고, 섬진강에서 불어오는 바람이...)",
    "seasonal_timing": "계절감이나 수확 시기의 특별함",
    "intro_section": {
      "main_text": "농장 소개와 해당 작물에 대한 애정이 담긴 메시지 (7-8줄, 친근하고 신뢰감 있게)",
      "commitment": "고객에게 전하고 싶은 약속이나 다짐"
    },
    "point_sections": {
      "point_01": {
        "subtitle": "해당 작물의 가장 큰 장점 (작물 특성에 맞게)",
        "title": "핵심 메시지 (신선도나 품질 강조)",
        "description": "상세 설명 (3-4줄, 신선도나 품질 관련)",
        "background_theme": "bright"
      },
      "point_02": {
        "subtitle": "활용도나 맛 관련 장점 (해당 작물의 실제 특성 반영)",
        "title": "매력적인 제목 (작물의 진짜 맛과 특성 기반)",
        "description": "해당 작물의 맛이나 활용법 소개 (3-4줄, 작물별 고유 특성 반영)",
        "usage_examples": [
          {"text": "첫 번째 활용법 (해당 작물에 실제로 어울리는 요리법)"},
          {"text": "두 번째 활용법 (작물 특성을 살린 조리법)"},
          {"text": "세 번째 활용법 (해당 작물만의 독특한 활용법)"}
        ]
      },
      "point_03": {
        "subtitle": "안전성이나 재배 방식 (작물에 맞는 재배법 강조)",
        "title": "신뢰감 있는 제목 (안전성 강조)",
        "description": "재배 방식이나 인증 관련 설명 (3-4줄)",
        "background_theme": "dark"
      },
      "point_04": {
        "subtitle": "포장이나 배송 관련 (해당 작물의 보관 특성 고려)",
        "title": "배송/포장 관련 제목 (신선도 유지 강조)",
        "description": "포장 방식이나 배송 프로세스 설명 (3-4줄)",
        "recommendations": [
          "첫 번째 추천 대상 (해당 작물을 빠르게 드시고 싶으신 분)",
          "두 번째 추천 대상 (우리 가족 안심 농산물을 찾고 계신 분)",
          "세 번째 추천 대상 (자연이 선물한 농산물을 찾으시는 분)",
          "네 번째 추천 대상 (해당 작물로 요리를 만들고 싶으신 분)"
        ]
      }
    }
  }
}

[작성 지침]
1. 이미지를 정확히 식별하여 crop_type을 구체적으로 명시
2. 해당 작물의 실제 특성을 반영한 현실적인 콘텐츠 작성 (중요!)
3. MZ세대 톤앤매너: 친근하고 트렌디하되 과하지 않게
4. 기승전결 구조로 스토리텔링 완성
5. 결론부터 말하기 방식으로 핵심 정보 우선 배치
6. 각 작물별 차별화된 콘텐츠 (당근이면 아삭함과 단맛, 딸기면 새콤달콤함 등 실제 특성만 사용)
7. 부적절한 특성 금지 (당근에 새콤달콤, 양파에 달콤함 등 현실과 맞지 않는 표현 절대 금지)
8. SEO 최적화를 위한 자연스러운 키워드 배치
9. 응답은 반드시 유효한 JSON 형식이어야 함`;

      switch (type) {
        case 'disease':
          return basePrompt + '\n\n특히 질병 진단에 중점을 두어 분석해주세요.';
        case 'pest':
          return basePrompt + '\n\n특히 해충 및 충해 진단에 중점을 두어 분석해주세요.';
        case 'nutrition':
          return basePrompt + '\n\n특히 영양 상태 및 결핍 증상에 중점을 두어 분석해주세요.';
        default:
          return basePrompt + '\n\n전반적인 작물 상태를 종합적으로 분석해주세요.';
      }
    };

    // OpenAI Vision API 호출 (타임아웃 설정)
    const response = await Promise.race([
      openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: getAnalysisPrompt(analysisType)
              },
              {
                type: "image_url",
                image_url: {
                  url: imageUrl,
                  detail: "high"
                }
              }
            ]
          }
        ],
        max_tokens: 4000,
        temperature: 0.3
      }),
      new Promise<never>((_, reject) => 
        setTimeout(() => reject(new Error('OpenAI API 타임아웃 (45초)')), 45000)
      )
    ]);

    const analysisResult = response.choices[0]?.message?.content;

    if (!analysisResult) {
      return NextResponse.json(
        { error: '이미지 분석에 실패했습니다.' },
        { status: 500 }
      );
    }

    // 디버깅: AI 응답 로깅
    console.log('🤖 AI Raw Response:', analysisResult);

    // JSON 파싱 시도
    let parsedResult;
    try {
      // 먼저 전체 응답이 JSON인지 확인
      try {
        parsedResult = JSON.parse(analysisResult.trim());
        console.log('✅ Direct JSON Parse Success:', parsedResult);
      } catch {
        // 전체가 JSON이 아니면 JSON 부분만 추출
        const jsonMatch = analysisResult.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          console.log('📋 JSON Match Found:', jsonMatch[0]);
          parsedResult = JSON.parse(jsonMatch[0]);
          console.log('✅ Extracted JSON Parse Success:', parsedResult);
        } else {
          throw new Error('No JSON found in response');
        }
      }

      // 필수 필드 검증 및 기본값 설정
      parsedResult = {
        crop_type: parsedResult.crop_type || 'Unknown',
        growth_stage: parsedResult.growth_stage || 'Unknown',
        health_status: parsedResult.health_status || 'unknown',
        diseases: Array.isArray(parsedResult.diseases) ? parsedResult.diseases : [],
        pests: Array.isArray(parsedResult.pests) ? parsedResult.pests : [],
        nutritional_deficiency: Array.isArray(parsedResult.nutritional_deficiency) ? parsedResult.nutritional_deficiency : [],
        recommendations: Array.isArray(parsedResult.recommendations) ? parsedResult.recommendations : ["전문가와 상담하여 정확한 진단을 받으시기 바랍니다."],
        confidence_score: typeof parsedResult.confidence_score === 'number' ? parsedResult.confidence_score : 75,
        analysis_summary: parsedResult.analysis_summary || '이미지 분석이 완료되었습니다.',
        // 마케팅 콘텐츠 필드 추가
        marketing_content: parsedResult.marketing_content || {}
      };

    } catch (parseError) {
      console.error('❌ JSON parsing error:', parseError);
      console.log('📝 Original content:', analysisResult);
      
      // 완전한 fallback 구조
      parsedResult = {
        crop_type: 'Unknown',
        growth_stage: 'Unknown', 
        health_status: 'unknown',
        diseases: [],
        pests: [],
        nutritional_deficiency: [],
        recommendations: ["AI 분석에 실패했습니다. 전문가와 상담해주세요."],
        confidence_score: 0,
        analysis_summary: analysisResult.substring(0, 200) + '...',
        marketing_content: {}
      };
    }

    // 분석 결과 저장 기능 제거 (Base64 방식으로 변경)
    console.log('✅ 분석 완료 - 데이터베이스 저장 없이 결과 반환');

    return NextResponse.json({
      success: true,
      data: {
        analysis: parsedResult,
        analysisId: `temp_${Date.now()}`, // 임시 ID 생성
        imageUrl: imageUrl,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Analysis API error:', error);
    
    // 상세한 에러 처리
    if (error instanceof Error) {
      if (error.message.includes('API key')) {
        return NextResponse.json(
          { error: 'OpenAI API 키가 설정되지 않았습니다.' },
          { status: 500 }
        );
      }
      
      if (error.message.includes('타임아웃')) {
        return NextResponse.json(
          { error: '이미지 분석 시간이 초과되었습니다. 다시 시도해주세요.' },
          { status: 504 }
        );
      }
      
      if (error.message.includes('rate limit')) {
        return NextResponse.json(
          { error: 'API 사용량 한도를 초과했습니다. 잠시 후 다시 시도해주세요.' },
          { status: 429 }
        );
      }
      
      return NextResponse.json(
        { error: `이미지 분석 중 오류가 발생했습니다: ${error.message}` },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { error: '이미지 분석 중 알 수 없는 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}
