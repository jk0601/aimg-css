'use client'

import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Navigation } from '@/components/custom/Navigation'

export default function Home() {
  const router = useRouter()
  const searchParams = useSearchParams()
  
  // 토큰을 유지하면서 analyze 페이지로 이동하는 함수
  const handleStartClick = () => {
    const token = searchParams.get('token')
    if (token) {
      router.push(`/analyze?token=${token}`)
    } else {
      router.push('/analyze')
    }
  }
  const features = [
    {
      icon: '🤖',
      title: 'AI 농산물 인식',
      description: 'AI 기반으로 농산물 이미지를 정확하게 분석하고 분류합니다.',
      badge: 'AI 기반'
    },
    {
      icon: '📄',
      title: '쿠팡 스타일 상세페이지',
      description: '검증된 쿠팡의 상품 상세페이지 형식으로 자동 생성합니다.',
      badge: '자동 생성'
    },
    {
      icon: '⚡',
      title: '빠른 처리',
      description: '이미지 업로드부터 상세페이지 생성까지 몇 초 만에 완료됩니다.',
      badge: '고속 처리'
    },
    {
      icon: '💰',
      title: '가격 제안',
      description: '시장 가격 분석을 통해 적정 가격대를 제안합니다.',
      badge: '가격 분석'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <Navigation />
      
      {/* 히어로 섹션 */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <Badge variant="secondary" className="text-sm px-4 py-2">
              🌱 농업 디지털 전환 솔루션
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
              농산물 이미지로
              <br />
              <span className="text-green-600">상세페이지 자동 생성</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              AI 기반 농산물 인식으로 쿠팡 스타일의 전문적인 상품 상세페이지를 
              몇 초 만에 자동으로 생성하세요.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg"
              onClick={handleStartClick}
            >
              🚀 지금 시작하기
            </Button>
            <Link href="#features">
              <Button variant="outline" size="lg" className="px-8 py-3 text-lg">
                📖 기능 살펴보기
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 기능 소개 섹션 */}
      <section id="features" className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            왜 농업 AI Agent인가요?
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            농업인의 온라인 판매 진입 장벽을 낮추고, 전문적인 상품 페이지를 쉽게 만들 수 있도록 도와드립니다.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="text-4xl mb-2">{feature.icon}</div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
                <Badge variant="secondary" className="w-fit mx-auto">
                  {feature.badge}
                </Badge>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* 사용 방법 섹션 */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              간단한 3단계로 완성
            </h2>
            <p className="text-lg text-gray-600">
              복잡한 설정 없이 바로 사용할 수 있습니다.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                title: '이미지 업로드',
                description: '농산물 사진을 드래그하거나 클릭해서 업로드하세요.',
                icon: '📸'
              },
              {
                step: '2',
                title: 'AI 분석',
                description: 'AI가 농산물을 자동으로 인식하고 분석합니다.',
                icon: '🔍'
              },
              {
                step: '3',
                title: '상세페이지 생성',
                description: '쿠팡 스타일의 전문적인 상품 상세페이지가 완성됩니다.',
                icon: '✨'
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">{item.icon}</span>
                </div>
                <div className="mb-2">
                  <Badge className="bg-green-600 text-white mb-2">
                    Step {item.step}
                  </Badge>
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA 섹션 */}
      <section className="bg-green-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            지금 바로 시작해보세요!
          </h2>
          <p className="text-xl mb-8 opacity-90">
            무료로 농산물 이미지를 분석하고 전문적인 상세페이지를 생성해보세요.
          </p>
          <Button 
            size="lg" 
            variant="secondary" 
            className="px-8 py-3 text-lg"
            onClick={handleStartClick}
          >
            🌱 무료로 시작하기
          </Button>
        </div>
      </section>

      {/* 푸터 */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <span className="text-2xl">🌱</span>
            <span className="text-lg font-semibold">농업 AI Agent</span>
          </div>
          <p className="text-gray-400 mb-4">
            농업인의 디지털 전환을 위한 AI 솔루션
          </p>
          <div className="text-sm text-gray-500">
            © 2024 RunMoA. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
