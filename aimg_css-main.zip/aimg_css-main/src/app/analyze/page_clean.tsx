﻿'use client'

import { useState, useEffect } from 'react'
import { Navigation } from '@/components/custom/Navigation'
import { ImageUploader } from '@/components/custom/ImageUploader'
import { AnalysisProgress } from '@/components/custom/AnalysisProgress'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAnalysisStore } from '@/store/analysisStore'
import { sanitizeFileName } from '@/lib/utils'
import Image from 'next/image'


// ?대?吏瑜?base64濡?蹂?섑븯???⑥닔
const imageToBase64 = async (imageUrl: string): Promise<string> => {
  try {
    const response = await fetch(imageUrl)
    const blob = await response.blob()
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result as string)
      reader.onerror = reject
      reader.readAsDataURL(blob)
    })
  } catch (error) {
    console.error('?대?吏 蹂???ㅽ뙣:', error)
    return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuydtOuvuOyngCDsl4bsnYw8L3RleHQ+PC9zdmc+'
  }
}

// ?쒗뵆由?HTML ?앹꽦 ?⑥닔 (鍮꾨룞湲곕줈 蹂寃?
const generateTemplateHTML = async (currentAnalysis: any, currentImageUrl: string) => {
  // ?대?吏瑜?base64濡?蹂??  let base64Image = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuydtOuvuOyngCDsl4bsnYw8L3RleHQ+PC9zdmc+'
  
  if (currentImageUrl) {
    try {
      base64Image = await imageToBase64(currentImageUrl)
      console.log('???대?吏 base64 蹂???깃났')
    } catch (error) {
      console.error('???대?吏 蹂???ㅽ뙣:', error)
    }
  }
  
  console.log('?뼹截??ъ슜???대?吏:', base64Image.substring(0, 50) + '...')
  console.log('?뱩 ?대?吏 ?꾩껜 湲몄씠:', base64Image.length)
  console.log('?뵇 ?대?吏 ????뺤씤:', base64Image.substring(0, 30))
  
  // CSS ?앹꽦 ?뚯뒪??  const testCss = `background-image: url('` + base64Image.substring(0, 100) + `...');`
  console.log('?렓 ?앹꽦??CSS ?섑뵆:', testCss)
  
  const cropType = currentAnalysis?.analysis?.crop_type || '?띿궛臾?
  const satisfaction = currentAnalysis?.analysis?.marketing_content?.conclusion_first?.satisfaction || '?ъ숴?섍퀬 ?좎꽑??留쏆씠 ?쇳뭹'
  const climax = currentAnalysis?.analysis?.marketing_content?.story_structure?.climax || '?좎꽑?⑥쓣 洹몃?濡??꾨떖?대뱶由쎈땲??
  const development = currentAnalysis?.analysis?.marketing_content?.story_structure?.development || '?곕━ ?띿옣? ?뉖튆?????쒕뒗 吏??뿉???먯뿰?ㅻ읇寃??먮? ?띿궛臾쇱쓣 ?щ같?⑸땲??
  const snsPoint = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.sns_point || '?몄뒪? ?ㅽ넗由ъ뿉??諛섏쓳 ??컻 ?덉젙'
  const homecafeUse = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.homecafe_use || '?붽굅?몃낵, ?ㅻТ?? ?먮윭?쒓퉴吏 ?꾨꼍'
  const giftMessage = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.gift_message || '嫄닿컯 梨숆린??留덉쓬源뚯? ?꾨떖?섎뒗 ?좊Ъ'
  
  // ?꾩쟾??寃⑸━???쒗뵆由?HTML
  return `
    <div class="fruits-template-isolated">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700;900&display=swap" rel="stylesheet">
      
      <style>
        /* ?꾩쟾??寃⑸━???ㅽ???- ?ㅼ쭅 .fruits-template-isolated ?대??먯꽌留??곸슜 */
        .fruits-template-isolated {
          all: initial !important;
          display: block !important;
          font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif !important;
          line-height: 1.6 !important;
          color: #272727 !important;
          background-color: #f5f5f5 !important;
          padding: 20px 16px !important;
          margin: 0 !important;
          box-sizing: border-box !important;
          width: 100% !important;
          position: relative !important;
          z-index: 1 !important;
        }
        
        .fruits-template-isolated * {
          margin: 0 !important;
          padding: 0 !important;
          border: 0 !important;
          outline: 0 !important;
          vertical-align: baseline !important;
          box-sizing: border-box !important;
          /* 以묒슂???띿꽦?ㅼ? ?좎? */
          display: revert !important;
          background: revert !important;
          /* background-image???몃씪???ㅽ??쇱씠 ?곗꽑?섎룄濡?unset ?ъ슜 */
          background-image: unset !important;
          background-size: revert !important;
          background-position: revert !important;
          filter: inherit !important;
          transform: inherit !important;
          transition: inherit !important;
          position: revert !important;
          width: revert !important;
          height: revert !important;
          color: revert !important;
          font-family: revert !important;
          font-size: revert !important;
          font-weight: revert !important;
          line-height: revert !important;
          text-align: revert !important;
        }
      
        .fruits-template-isolated .template-container {
          font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif !important;
          line-height: 1.6 !important;
          color: #272727 !important;
          background-color: #f5f5f5 !important;
          padding: 20px 16px !important;
          margin: 0 !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .content-wrapper {
          max-width: 900px !important;
          margin: 0 auto !important;
          background-color: white !important;
          border-radius: 15px !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1) !important;
          overflow: hidden !important;
        }
        
        .fruits-template-isolated .header {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 10px !important;
          padding: 80px 20px 50px !important;
          background-color: #272727 !important;
          color: white !important;
          font-size: 36px !important;
          font-weight: bold !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .header h1 {
          margin: 0 !important;
          padding: 0 !important;
          font-size: inherit !important;
          font-weight: inherit !important;
          color: inherit !important;
        }
        
        .fruits-template-isolated .hero-section {
          min-height: 600px !important;
          background-color: white !important;
          position: relative !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .hero-background {
          width: 100% !important;
          height: 400px !important;
          position: absolute !important;
          top: 200px !important;
          left: 0 !important;
          /* background ???몃씪???ㅽ??쇰줈 ?ㅼ젙 */
        }
        
        .fruits-template-isolated .hero-content {
          position: absolute !important;
          top: 50px !important;
          left: 0 !important;
          z-index: 2 !important;
          right: 0 !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .hero-subtitle {
          font-size: 32px !important;
          font-weight: bold !important;
          color: #696868 !important;
          margin-bottom: 20px !important;
          margin-top: 0 !important;
          padding: 0 !important;
        }
        
        .fruits-template-isolated .hero-title {
          font-size: 60px !important;
          font-weight: 900 !important;
          color: #272727 !important;
          position: relative !important;
          display: inline-block !important;
          padding: 0 20px !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .hero-title::after {
          content: '' !important;
          position: absolute !important;
          bottom: 8px !important;
          left: 0 !important;
          right: 0 !important;
          height: 30px !important;
          background-color: #fcecea !important;
          z-index: -1 !important;
        }
        
        .fruits-template-isolated .temp-content {
          padding: 40px !important;
          text-align: center !important;
          background: white !important;
        }
        
        .fruits-template-isolated .temp-content h3 {
          font-size: 24px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin: 0 0 20px 0 !important;
          padding: 0 !important;
        }
        
        .fruits-template-isolated .temp-content p {
          font-size: 16px !important;
          color: #666 !important;
          margin: 0 !important;
          padding: 0 !important;
          line-height: 1.6 !important;
        }
        
        /* 硫붿씤 而⑦뀒?대꼫 */
        .fruits-template-isolated .main-container {
          background-color: #f5f5f5 !important;
          min-height: 100vh !important;
          padding: 20px 16px !important;
        }
        
        .fruits-template-isolated .content-wrapper {
          max-width: 900px !important;
          margin: 0 auto !important;
          background-color: white !important;
          border-radius: 15px !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1) !important;
          overflow: hidden !important;
        }
        
        /* ?ㅻ뜑 ?ъ젙??*/
        .fruits-template-isolated .header {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 10px !important;
          padding: 80px 20px 50px !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          margin: 0 auto !important;
          width: fit-content !important;
          background-color: #272727 !important;
          z-index: 10 !important;
        }
        
        /* ?덉뼱濡??뱀뀡 ?ъ젙??*/
        .fruits-template-isolated .hero-section {
          min-height: 1400px !important;
          background-color: white !important;
          position: relative !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .hero-background {
          width: 100% !important;
          height: 860px !important;
          position: absolute !important;
          top: 540px !important;
          left: 0 !important;
          /* background ???몃씪???ㅽ??쇰줈 ?ㅼ젙 */
        }
        
        .fruits-template-isolated .hero-content {
          width: 100% !important;
          height: 170px !important;
          position: absolute !important;
          z-index: 2 !important;
          top: 264px !important;
          left: 0 !important;
          right: 0 !important;
        }
        
        .fruits-template-isolated .hero-text-container {
          display: flex !important;
          flex-direction: column !important;
          gap: 25px !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          margin: 0 auto !important;
          width: fit-content !important;
          align-items: center !important;
        }
        
        .fruits-template-isolated .hero-subtitle {
          width: fit-content !important;
          margin-top: -1px !important;
          font-weight: bold !important;
          color: #696868 !important;
          font-size: 40px !important;
          text-align: center !important;
          letter-spacing: -0.8px !important;
          line-height: normal !important;
          white-space: nowrap !important;
        }
        
        .fruits-template-isolated .hero-title-container {
          position: relative !important;
        }
        
        .fruits-template-isolated .hero-title {
          font-weight: 900 !important;
          color: #272727 !important;
          font-size: 80px !important;
          text-align: center !important;
          letter-spacing: -1.6px !important;
          line-height: normal !important;
          white-space: nowrap !important;
          position: relative !important;
          z-index: 2 !important;
        }
        
        .fruits-template-isolated .hero-title-background {
          position: absolute !important;
          width: 100% !important;
          height: 50px !important;
          left: 0 !important;
          bottom: 8px !important;
          background-color: #fcecea !important;
          z-index: 1 !important;
        }
        
        /* ?뱀쭠 ?뱀뀡 */
        .fruits-template-isolated .features-section {
          background-color: white !important;
          padding: 80px 40px !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .features-container {
          max-width: 800px !important;
          margin: 0 auto !important;
        }
        
        .fruits-template-isolated .features-grid {
          display: flex !important;
          align-items: center !important;
          justify-content: space-between !important;
          gap: 40px !important;
        }
        
        .fruits-template-isolated .feature-item {
          flex: 1 !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .feature-content {
          display: flex !important;
          flex-direction: column !important;
          align-items: center !important;
          gap: 20px !important;
        }
        
        .fruits-template-isolated .feature-icon {
          width: 80px !important;
          height: 80px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .fruits-template-isolated .feature-icon img {
          width: 100% !important;
          height: 100% !important;
          object-fit: contain !important;
        }
        
        .fruits-template-isolated .feature-text {
          text-align: center !important;
        }
        
        .fruits-template-isolated .feature-title {
          font-size: 24px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin-bottom: 10px !important;
        }
        
        .fruits-template-isolated .feature-description {
          font-size: 16px !important;
          color: #666 !important;
          line-height: 1.6 !important;
        }
        
        .fruits-template-isolated .feature-divider {
          width: 2px !important;
          height: 120px !important;
          background-color: #e0e0e0 !important;
          flex-shrink: 0 !important;
        }
        
        /* 由щ럭 ?뱀뀡 */
        .fruits-template-isolated .reviews-section {
          /* background ???몃씪???ㅽ??쇰줈 ?ㅼ젙 */
          padding: 80px 40px !important;
          position: relative !important;
          min-height: 800px !important;
        }
        
        
        .fruits-template-isolated .reviews-background {
          max-width: 800px !important;
          margin: 0 auto !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .reviews-header {
          text-align: center !important;
          margin-bottom: 60px !important;
        }
        
        .fruits-template-isolated .reviews-subtitle {
          font-size: 24px !important;
          color: #ffffff !important;
          margin-bottom: 10px !important;
        }
        
        .fruits-template-isolated .reviews-title {
          font-size: 48px !important;
          font-weight: 900 !important;
          color: #ffffff !important;
        }
        
        .fruits-template-isolated .reviews-container {
          display: flex !important;
          flex-direction: column !important;
          gap: 30px !important;
        }
        
        .fruits-template-isolated .review-card {
          background: white !important;
          border-radius: 15px !important;
          padding: 20px !important;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
          overflow: hidden !important;
          margin-bottom: 20px !important;
        }
        
        .fruits-template-isolated .review-content {
          display: flex !important;
          gap: 15px !important;
          align-items: flex-start !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .review-avatar {
          width: 60px !important;
          height: 60px !important;
          border-radius: 50% !important;
          flex-shrink: 0 !important;
          overflow: hidden !important;
          border: 2px solid #f0f0f0 !important;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
        }
        
        .fruits-template-isolated .review-avatar img {
          width: 100% !important;
          height: 100% !important;
          object-fit: cover !important;
          display: block !important;
          border-radius: 50% !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .review-avatar:hover img {
          transform: scale(1.1) !important;
        }
        
        /* ?꾪꽣 ?④낵 媛뺤젣 ?곸슜 */
        .fruits-template-isolated img[style*="filter"] {
          filter: inherit !important;
        }
        
        .fruits-template-isolated div[style*="filter"] {
          filter: inherit !important;
        }
        
        /* 媛?由щ럭 移대뱶蹂??꾪꽣 ?④낵 */
        .fruits-template-isolated .review-card:nth-child(1) .review-avatar img {
          filter: hue-rotate(120deg) saturate(1.4) brightness(1.1) contrast(1.2) !important;
        }
        
        .fruits-template-isolated .review-card:nth-child(2) .review-avatar img {
          filter: hue-rotate(240deg) saturate(1.2) brightness(1.2) sepia(0.3) !important;
        }
        
        .fruits-template-isolated .review-card:nth-child(3) .review-avatar img {
          filter: grayscale(0.4) brightness(1.3) contrast(1.1) blur(0.5px) !important;
        }
        
        .fruits-template-isolated .review-text {
          flex: 1 !important;
          min-width: 0 !important;
          overflow: hidden !important;
        }
        
        .fruits-template-isolated .review-stars {
          display: flex !important;
          gap: 3px !important;
          margin-bottom: 8px !important;
        }
        
        .fruits-template-isolated .star-icon {
          width: 14px !important;
          height: 14px !important;
          fill: #ffd700 !important;
          stroke: #ffd700 !important;
          flex-shrink: 0 !important;
        }
        
        .fruits-template-isolated .review-title {
          font-size: 16px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin: 0 0 6px 0 !important;
          line-height: 1.4 !important;
          word-wrap: break-word !important;
        }
        
        .fruits-template-isolated .review-description {
          font-size: 13px !important;
          color: #666 !important;
          line-height: 1.5 !important;
          margin: 0 !important;
          word-wrap: break-word !important;
        }
        
        /* ?뚭컻 ?뱀뀡 */
        .fruits-template-isolated .intro-section {
          background-color: white !important;
          padding: 80px 40px !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .intro-content {
          max-width: 800px !important;
          margin: 0 auto !important;
          display: flex !important;
          align-items: center !important;
          gap: 60px !important;
        }
        
        .fruits-template-isolated .intro-text {
          flex: 1 !important;
          font-size: 18px !important;
          color: #272727 !important;
          line-height: 1.8 !important;
          margin: 0 !important;
          padding: 0 !important;
        }
        
        .fruits-template-isolated .intro-image {
          flex: 1 !important;
          height: 400px !important;
          /* background ???몃씪???ㅽ??쇰줈 ?ㅼ젙 */
          background-size: cover !important;
          background-position: center !important;
          border-radius: 15px !important;
          box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1) !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .intro-image:hover {
          transform: scale(1.03) !important;
          box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15) !important;
        }
        
        /* 諛섏쓳???붿옄??*/
        @media (max-width: 768px) {
          .fruits-template-isolated .intro-content {
            flex-direction: column !important;
            gap: 30px !important;
          }
          
          .fruits-template-isolated .intro-text {
            text-align: center !important;
            font-size: 16px !important;
          }
          
          .fruits-template-isolated .intro-image {
            height: 300px !important;
            width: 100% !important;
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            transform: none !important;
            filter: blur(1px) brightness(1.1) !important;
            background-color: red !important;
            min-height: 300px !important;
          }
        }
        
        /* POINT ?뱀뀡??*/
        .fruits-template-isolated .point-section {
          position: relative !important;
          min-height: 600px !important;
        }
        
        /* POINT 01 - 諛앹? 諛곌꼍 ?대?吏 */
        .fruits-template-isolated .point-01 {
          background-color: white !important;
          position: relative !important;
          overflow: hidden !important;
          min-height: 600px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .fruits-template-isolated .point-01::before {
          content: '' !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          background: rgba(255,255,255,0.85) !important;
          z-index: 1 !important;
        }

        .fruits-template-isolated .point-01 .point-background {
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          z-index: 0 !important;
          /* background-image ???몃씪???ㅽ??쇰줈 ?ㅼ젙 */
          background-size: cover !important;
          background-position: center !important;
          background-repeat: no-repeat !important;
          /* filter: brightness(2) contrast(0.3) saturate(0.2) opacity(0.3) !important; */
        }
        
        /* 怨듯넻 POINT 肄섑뀗痢??ㅽ???*/
        .fruits-template-isolated .point-content {
          position: relative !important;
          z-index: 999 !important;
          text-align: center !important;
          color: #000000 !important;
          max-width: 600px !important;
          padding: 40px !important;
          font-weight: 600 !important;
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
        }
        
        .fruits-template-isolated .point-01 .point-number {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-01 .point-subtitle {
          color: #666 !important;
        }
        
        .fruits-template-isolated .point-01 .point-title {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-01 .point-description {
          color: #666 !important;
        }
        
        /* POINT 03 - ?대몢??諛곌꼍 ?대?吏 */
        .fruits-template-isolated .point-03 {
          background-color: #272727 !important;
          position: relative !important;
          overflow: hidden !important;
          min-height: 600px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .fruits-template-isolated .point-03::before {
          content: '' !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          background: rgba(255,255,255,0.85) !important;
          z-index: 1 !important;
        }
        
        .fruits-template-isolated .point-03 .point-background {
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          z-index: 0 !important;
          /* background-image ???몃씪???ㅽ??쇰줈 ?ㅼ젙 */
          background-size: cover !important;
          background-position: center !important;
          background-repeat: no-repeat !important;
          /* filter: brightness(2) contrast(0.3) saturate(0.2) opacity(0.3) !important; */
        }
        
        /* POINT 03 肄섑뀗痢좊뒗 怨듯넻 洹쒖튃 ?ъ슜 (以묐났 ?쒓굅) */
        
        /* 怨듯넻 POINT ?ㅽ???*/
        .fruits-template-isolated .point-header {
          margin-bottom: 30px !important;
        }
        
        /* ?띿뒪???붿냼??媛뺤젣 ?쒖떆 */
        .fruits-template-isolated .point-number,
        .fruits-template-isolated .point-subtitle,
        .fruits-template-isolated .point-title,
        .fruits-template-isolated .point-description {
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
          color: #000000 !important;
          z-index: 999 !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .point-number {
          font-size: 24px !important;
          font-weight: bold !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .point-text-container {
          margin-bottom: 30px !important;
        }
        
        .fruits-template-isolated .point-subtitle {
          font-size: 20px !important;
          margin: 0 0 10px 0 !important;
        }
        
        .fruits-template-isolated .point-title {
          font-size: 48px !important;
          font-weight: 900 !important;
          margin: 0 !important;
          line-height: 1.2 !important;
        }
        
        .fruits-template-isolated .point-description {
          font-size: 18px !important;
          line-height: 1.6 !important;
          margin: 0 !important;
        }
        
        /* POINT 02 - ?몃줈 ?뺣젹 ?덉씠?꾩썐 */
        .fruits-template-isolated .point-02 {
          background-color: white !important;
          padding: 80px 40px !important;
        }
        
        .fruits-template-isolated .point-02-header {
          max-width: 800px !important;
          margin: 0 auto 60px auto !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .point-02 .point-number {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-02 .point-subtitle {
          color: #666 !important;
        }
        
        .fruits-template-isolated .point-02 .point-title {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-02 .point-description {
          color: #666 !important;
        }
        
        .fruits-template-isolated .dessert-items {
          max-width: 600px !important;
          margin: 0 auto !important;
          display: flex !important;
          flex-direction: column !important;
          gap: 25px !important;
        }
        
        .fruits-template-isolated .dessert-item {
          display: flex !important;
          align-items: center !important;
          gap: 20px !important;
          padding: 15px !important;
          background: rgba(255, 255, 255, 0.03) !important;
          border-radius: 20px !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(even) {
          flex-direction: row-reverse !important;
        }
        
        .fruits-template-isolated .dessert-item:hover {
          background: rgba(255, 255, 255, 0.08) !important;
          transform: scale(1.02) !important;
        }
        
        .fruits-template-isolated .dessert-image {
          width: 120px !important;
          height: 120px !important;
          border-radius: 50% !important;
          overflow: hidden !important;
          flex-shrink: 0 !important;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15) !important;
        }
        
        .fruits-template-isolated .dessert-image img {
          width: 100% !important;
          height: 100% !important;
          object-fit: cover !important;
          display: block !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .dessert-image:hover img {
          transform: scale(1.1) !important;
        }
        
        /* POINT 02 ?붿????대?吏蹂??꾪꽣 */
        .fruits-template-isolated .dessert-item:nth-child(1) .dessert-image img {
          filter: brightness(1.2) saturate(1.3) contrast(1.1) !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(2) .dessert-image img {
          filter: hue-rotate(45deg) brightness(1.2) saturate(1.3) contrast(1.1) !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(3) .dessert-image img {
          filter: hue-rotate(90deg) brightness(1.2) saturate(1.3) contrast(1.1) !important;
        }
        
        .fruits-template-isolated .dessert-text {
          flex: 1 !important;
          font-size: 16px !important;
          color: #272727 !important;
          font-weight: 600 !important;
          line-height: 1.4 !important;
          word-break: keep-all !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(odd) .dessert-text {
          text-align: left !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(even) .dessert-text {
          text-align: right !important;
        }
        
        @media (max-width: 768px) {
          .fruits-template-isolated .dessert-item {
            flex-direction: column !important;
          }
          
          .fruits-template-isolated .dessert-item:nth-child(even) {
            flex-direction: column !important;
          }
          
          .fruits-template-isolated .dessert-item:nth-child(odd) .dessert-text,
          .fruits-template-isolated .dessert-item:nth-child(even) .dessert-text {
            text-align: center !important;
          }
          
          .fruits-template-isolated .dessert-image {
            width: 100px !important;
            height: 100px !important;
          }
          
          .fruits-template-isolated .dessert-text {
            font-size: 14px !important;
          }
        }
        
        /* POINT 04 - 蹂듯빀 ?뱀뀡 */
        .fruits-template-isolated .point-04-section {
          background-color: #f8f8f8 !important;
          padding: 80px 40px !important;
        }
        
        .fruits-template-isolated .point-04-content {
          max-width: 800px !important;
          margin: 0 auto 60px auto !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .point-04-header-border {
          border: 2px solid #272727 !important;
          display: inline-block !important;
          padding: 10px 20px !important;
          margin-bottom: 30px !important;
        }
        
        .fruits-template-isolated .point-04-number {
          font-size: 24px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .point-04-subtitle {
          font-size: 20px !important;
          color: #666 !important;
          margin: 0 0 10px 0 !important;
        }
        
        .fruits-template-isolated .point-04-title {
          font-size: 48px !important;
          font-weight: 900 !important;
          color: #272727 !important;
          margin: 0 0 20px 0 !important;
        }
        
        .fruits-template-isolated .point-04-description {
          font-size: 18px !important;
          color: #666 !important;
          line-height: 1.6 !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .detail-images {
          display: flex !important;
          justify-content: center !important;
          align-items: center !important;
          gap: 20px !important;
          margin: 60px 0 !important;
        }
        
        .fruits-template-isolated .detail-image {
          width: 200px !important;
          height: 200px !important;
          object-fit: cover !important;
          border-radius: 10px !important;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
          transition: all 0.3s ease !important;
        }
        
        /* 媛??곸꽭 ?대?吏蹂??꾪꽣 ?④낵
        .fruits-template-isolated .detail-image:nth-child(1) {
          filter: sepia(0.5) contrast(1.2) brightness(1.1) !important;
          transform: scale(1.02) !important;
        }
        
        .fruits-template-isolated .detail-image:nth-child(2) {
          filter: grayscale(0.3) brightness(1.2) blur(0.5px) !important;
          transform: rotate(-1deg) !important;
        }
        
        .fruits-template-isolated .detail-image:nth-child(3) {
          filter: hue-rotate(25deg) saturate(1.4) contrast(1.1) !important;
          transform: rotate(1deg) scale(1.01) !important;
        }
        
        .fruits-template-isolated .detail-image:hover {
          transform: scale(1.05) rotate(0deg) !important;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2) !important;
        }
         */

        .fruits-template-isolated .recommendation-section {
          background-color: #272727 !important;
          border-radius: 15px !important;
          padding: 40px !important;
          max-width: 800px !important;
          margin: 0 auto !important;
        }
        
        .fruits-template-isolated .recommendation-header {
          text-align: center !important;
          margin-bottom: 30px !important;
        }
        
        .fruits-template-isolated .recommendation-title {
          font-size: 28px !important;
          font-weight: bold !important;
          color: white !important;
          margin: 0 0 10px 0 !important;
        }
        
        .fruits-template-isolated .recommendation-subtitle {
          font-size: 16px !important;
          color: #ccc !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .recommendation-list {
          display: flex !important;
          flex-direction: column !important;
          gap: 15px !important;
        }
        
        .fruits-template-isolated .recommendation-item {
          display: flex !important;
          align-items: center !important;
          gap: 15px !important;
        }
        
        .fruits-template-isolated .recommendation-check {
          width: 24px !important;
          height: 24px !important;
          background-color: #4CAF50 !important;
          border-radius: 50% !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          flex-shrink: 0 !important;
        }
        
        .fruits-template-isolated .recommendation-text {
          color: white !important;
          font-size: 16px !important;
          line-height: 1.5 !important;
        }
    </style>
    
      <div class="main-container">
        <div class="content-wrapper">
          
          <!-- ?ㅻ뜑 -->
          <header class="header">
            <h1>${cropType}?섎씪</h1>
          </header>

          <!-- ?덉뼱濡??뱀뀡 -->
          <section class="hero-section">
            <div class="hero-background" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important; z-index: 1 !important;"></div>
            <div class="hero-content">
              <div class="hero-text-container">
                <p class="hero-subtitle">111泥?젙 ?먯뿰?먯꽌 ?щ같????留쏆엳??/p>
                <div class="hero-title-container">
                  <h2 class="hero-title">${cropType}?섎씪 ?쒖쿋 ${cropType}</h2>
                  <div class="hero-title-background"></div>
                </div>
              </div>
            </div>
          </section>

          <!-- ?뱀쭠 ?뱀뀡 -->
          <section class="features-section">
            <div class="features-container">
              <div class="features-grid">
                <div class="feature-item">
                  <div class="feature-content">
                    <div class="feature-icon">
                      <img src="/images/icon_smile.png" alt="蹂댁옣??留?>
                    </div>
                    <div class="feature-text">
                      <h3 class="feature-title">蹂댁옣??留?/h3>
                      <p class="feature-description">${climax}</p>
                    </div>
                  </div>
                </div>
                
                <div class="feature-divider"></div>
                
                <div class="feature-item">
                  <div class="feature-content">
                    <div class="feature-icon">
                      <img src="/images/icon_delivery.png" alt="鍮좊Ⅸ 諛곗넚">
                    </div>
                    <div class="feature-text">
                      <h3 class="feature-title">鍮좊Ⅸ 諛곗넚</h3>
                      <p class="feature-description">${satisfaction}</p>
                    </div>
                  </div>
                </div>
                
                <div class="feature-divider"></div>
                
                <div class="feature-item">
                  <div class="feature-content">
                    <div class="feature-icon">
                      <img src="/images/icon_relief.png" alt="?덉떖 ?щ같">
                    </div>
                    <div class="feature-text">
                      <h3 class="feature-title">?덉떖 ?щ같</h3>
                      <p class="feature-description">${development}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <!-- 由щ럭 ?뱀뀡 -->
          <section class="reviews-section" style="background: linear-gradient(rgba(0, 0, 0, 0.85), rgba(0, 0, 0, 0.85)), url('` + base64Image + `') center center / cover !important;">
            <div class="reviews-background">
              <header class="reviews-header">
                <h2 class="reviews-subtitle">援щℓ 怨좉컼?섎뱾??/h2>
                <h1 class="reviews-title">?앹깮??由щ럭</h1>
              </header>
              
              <div class="reviews-container">
                <article class="review-card">
                  <div class="review-content">
                         <div class="review-avatar">
                           <img src="${base64Image}" alt="由щ럭??1">
                         </div>
                    <div class="review-text">
                      <div class="review-stars">
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                      </div>
                      <h3 class="review-title">SNS ?щ━湲???醫뗭? 鍮꾩＜??/h3>
                      <p class="review-description">${snsPoint}</p>
                    </div>
                  </div>
                </article>
                
                <article class="review-card">
                  <div class="review-content">
                         <div class="review-avatar">
                           <img src="${base64Image}" alt="由щ럭??2">
                         </div>
                    <div class="review-text">
                      <div class="review-stars">
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                      </div>
                      <h3 class="review-title">?덉뭅???먮굦 ?????닿굅 ?섎굹硫???/h3>
                      <p class="review-description">${homecafeUse}</p>
                    </div>
                  </div>
                </article>
                
                <article class="review-card">
                  <div class="review-content">
                         <div class="review-avatar">
                           <img src="${base64Image}" alt="由щ럭??3">
                         </div>
                    <div class="review-text">
                      <div class="review-stars">
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                      </div>
                      <h3 class="review-title">遺紐⑤떂猿??좊Ъ?섍린??醫뗭븘??/h3>
                      <p class="review-description">${giftMessage}</p>
                    </div>
                  </div>
                </article>
              </div>
            </div>
          </section>

          <!-- ?뚭컻 ?뱀뀡 -->
          <section class="intro-section">
            <div class="intro-content">
              <p class="intro-text">
                ${currentAnalysis?.analysis?.marketing_content?.intro_section?.main_text || 
                  `???${cropType}?섎씪??br>泥?젙 吏??뿉???뺤꽦?ㅻ읇寃??щ같??br>?좎꽑??${cropType}???꾩꽑??br>誘욧퀬 ?쒖떎 ???덈룄濡?br>理쒖꽑???ㅽ븯怨??덉뒿?덈떎.<br><br>?덉숴?ъ숴 留쏆엳??${cropType}??br>?댁젣 ?덉떖?섍퀬 ?쒖뀛蹂댁꽭??`
                }
              </p>
              <div class="intro-image" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important; filter: blur(1px) brightness(1.1) scale(1.05) !important; transform: scale(1.05) !important;"></div>
            </div>
          </section>

          <!-- POINT 01 -->
          <section class="point-section point-01">
            <div class="point-background" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important;"></div>
            <div class="point-content">
                <header class="point-header">
                  <h2 class="point-number">POINT 01</h2>
                </header>
                <div class="point-text-container">
                  <p class="point-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_01?.subtitle || `?붿슧 ?좎꽑??${cropType}`}</p>
                  <h1 class="point-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_01?.title || '?뱀씪 ?섑솗! ?뱀씪 諛곗넚!'}</h1>
                </div>
                <p class="point-description">
                  ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_01?.description || 
                    `${cropType}?섎씪?먯꽌??怨좉컼?섍퍡??br>?좎꽑??${cropType}??留뚮굹蹂댁떎 ???덈룄濡?br>?뱀씪 ?섑솗??${cropType}??諛곗넚???쒕━怨??덉뒿?덈떎.`
                  }
                </p>
              </div>
            </div>
          </section>

          <!-- POINT 02 -->
          <section class="point-section point-02">
            <div class="point-02-header">
              <header class="point-header">
                <h2 class="point-number">POINT 02</h2>
              </header>
              <div class="point-02-text-container">
                <p class="point-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.subtitle || '媛곸쥌 ?붿??몄쓽 留??낃렇?덉씠??'}</p>
                <h1 class="point-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.title || `?덉숴?ъ숴 留쏆엳??${cropType}`}</h1>
              </div>
              <p class="point-description">
                ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.description || 
                  `${cropType}?섎씪??${cropType}? ?밸룄媛 援됱옣???믨퀬<br>?덉숴?ъ숴??留쏆씠 ?쇳뭹?닿린 ?뚮Ц??br>?붿??몃옉 ?섏뼱?몃┰?덈떎`
                }
              </p>
            </div>
            
            <div class="dessert-items">
              ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.usage_examples?.map((example: any, index: number) => `
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="${cropType} ?쒖슜踰?${index + 1}">
                  </div>
                  <div class="dessert-text">
                    ${example.text || `?쒖슜踰?${index + 1}`}
                  </div>
                </div>
              `).join('') || `
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="?붿???1">
                  </div>
                  <div class="dessert-text">
                    ?붿????꾩뿉 ?곗퐫濡?br>
                    ?덇낵 ?낆쓣 利먭쾪寃?                  </div>
                </div>
                
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="?붿???2">
                  </div>
                  <div class="dessert-text">
                    ?ъ숴??${cropType}?쇱쓣<br>
                    留뚮뱾??鍮듦낵 ?④퍡
                  </div>
                </div>
                
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="?붿???3">
                  </div>
                  <div class="dessert-text">
                    ?瑜댄듃 ?꾩뿉 ?뱀뼱<br>
                    ${cropType} ?瑜댄듃濡?                  </div>
                </div>
              `}
            </div>
          </section>

          <!-- POINT 03 -->
          <section class="point-section point-03">
            <div class="point-background" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important;"></div>
            <div class="point-content">
                <header class="point-header">
                  <h2 class="point-number">POINT 03</h2>
                </header>
                <div class="point-text-container">
                  <p class="point-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_03?.subtitle || '?좉린???щ같濡??덉떖?섍퀬 ?좊깲!'}</p>
                  <h1 class="point-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_03?.title || '?곕━ ?꾩씠 ?덉쟾 癒밴굅由?}</h1>
                </div>
                <p class="point-description">
                  ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_03?.description || 
                    `${cropType}?섎씪??${cropType}? 臾대냽?쎌쑝濡??щ같?섏뿬<br>?꾩씠?ㅻ룄 ?덉떖?섍퀬 癒뱀쓣 ???덉쑝硫?br>GAP ?몄쬆??諛쏆븯?듬땲??`
                  }
                </p>
              </div>
            </div>
          </section>

          <!-- POINT 04 -->
          <section class="point-04-section">
            <div class="point-04-content">
              <div class="point-04-header">
                <div class="point-04-header-border">
                  <h2 class="point-04-number">POINT 04</h2>
                </div>
                <div class="point-04-text-container">
                  <p class="point-04-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.subtitle || `臾대Ⅸ 怨??놁씠 ?좎꽑??${cropType}`}</p>
                  <h1 class="point-04-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.title || '瑗쇨세???ъ옣 & 鍮좊Ⅸ 諛곗넚'}</h1>
                  <p class="point-04-description">
                    ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.description || 
                      `${cropType}?섎씪?먯꽌???꾩씠?ㅽ뙥怨?戮곷퐗?대? ?숇큺?섏뿬<br>${cropType}??臾대Ⅴ吏 ?딅룄濡?瑗쇨세?섍쾶 ?ъ옣?섎ŉ<br>?뱀씪 諛곗넚???듯빐 鍮좊Ⅴ寃?蹂대궡?쒕┰?덈떎.`
                    }
                  </p>
                </div>
              </div>
            </div>
            
            <div class="detail-images">
              <img src="${base64Image}" alt="?ъ옣 ?곸꽭 1" class="detail-image">
              <img src="./images/icon_delivery.png" alt="鍮좊Ⅸ 諛곗넚">
              <img src="${base64Image}" alt="?ъ옣 ?곸꽭 3" class="detail-image">
            </div>
            
            <div class="recommendation-section">
              <div class="recommendation-container">
                <div class="recommendation-header">
                  <h2 class="recommendation-title">${cropType}?섎씪 ?쒖쿋${cropType}</h2>
                  <p class="recommendation-subtitle">?대윴 遺꾨뱾猿??뱁엳 異붿쿇?댁슂!</p>
                </div>
                <div class="recommendation-list">
                         ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.recommendations?.map((recommendation: string) => `
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">${recommendation}</span>
                    </div>
                  `).join('') || `
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">?쒖쿋 ${cropType}??鍮좊Ⅴ寃??쒖떆怨??띠쑝??遺?/span>
                    </div>
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">?곕━ 媛議??덉떖 怨쇱씪??李얘퀬 怨꾩떊 遺?/span>
                    </div>
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">?먯뿰???좊Ъ??怨쇱씪??李얠쑝?쒕뒗 遺?/span>
                    </div>
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">${cropType} ?묒슜 ?붿??몃? 留뚮뱾怨??띠쑝??遺?/span>
                    </div>
                  `}
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  `
}

// ?숆린 踰꾩쟾 ?쒗뵆由?HTML ?앹꽦 ?⑥닔 (fallback??
const generateSyncTemplateHTML = (currentAnalysis: any, currentImageUrl: string) => {
  // 湲곕낯 ?대?吏 ?ъ슜
  const imageUrl = currentImageUrl || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuydtOuvuOyngCDsl4bsnYw8L3RleHQ+PC9zdmc+'
  
  const cropType = currentAnalysis?.analysis?.crop_type || '?띿궛臾?
  const satisfaction = currentAnalysis?.analysis?.marketing_content?.conclusion_first?.satisfaction || '?ъ숴?섍퀬 ?좎꽑??留쏆씠 ?쇳뭹'
  const climax = currentAnalysis?.analysis?.marketing_content?.story_structure?.climax || '?좎꽑?⑥쓣 洹몃?濡??꾨떖?대뱶由쎈땲??
  const development = currentAnalysis?.analysis?.marketing_content?.story_structure?.development || '?곕━ ?띿옣? ?뉖튆?????쒕뒗 吏??뿉???먯뿰?ㅻ읇寃??먮? ?띿궛臾쇱쓣 ?щ같?⑸땲??
  const snsPoint = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.sns_point || '?몄뒪? ?ㅽ넗由ъ뿉??諛섏쓳 ??컻 ?덉젙'
  const homecafeUse = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.homecafe_use || '?붽굅?몃낵, ?ㅻТ?? ?먮윭?쒓퉴吏 ?꾨꼍'
  const giftMessage = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.gift_message || '嫄닿컯 梨숆린??留덉쓬源뚯? ?꾨떖?섎뒗 ?좊Ъ'
  
  // ?숆린 踰꾩쟾?먯꽌???몃씪???ㅽ????ъ슜
  return `
    <div class="fruits-template-isolated">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700;900&display=swap" rel="stylesheet">
      
      <style>
        /* 湲곕낯 ?ㅽ??쇰쭔 ?ы븿 (諛곌꼍 ?대?吏 ?쒖쇅) */
        .fruits-template-isolated {
          all: initial !important;
          display: block !important;
          font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif !important;
          line-height: 1.6 !important;
          color: #272727 !important;
          background-color: #f5f5f5 !important;
          padding: 20px 16px !important;
          margin: 0 !important;
          box-sizing: border-box !important;
          width: 100% !important;
          position: relative !important;
          z-index: 1 !important;
        }
        /* ... ?섎㉧吏 ?ㅽ??쇰뱾 ... */
      </style>
      
      <div class="main-container">
        <div class="content-wrapper">
          <header class="header">
            <h1>${cropType}?섎씪</h1>
          </header>
          <!-- 媛꾨떒??肄섑뀗痢좊쭔 ?ы븿 -->
          <div class="simple-content">
            <h2>遺꾩꽍 寃곌낵</h2>
            <p>${satisfaction}</p>
          </div>
        </div>
      </div>
    </div>
  `
}

export default function AnalyzePage() {
  const { uploadProgress, setUploadProgress, setCurrentAnalysis, currentAnalysis, clearCurrentAnalysis, setCurrentImageUrl, currentImageUrl } = useAnalysisStore()
  
  // ?쒗뵆由?HTML ?곹깭
  const [templateHTML, setTemplateHTML] = useState('')
  
  // 遺꾩꽍 寃곌낵媛 蹂寃쎈맆 ?뚮쭏???쒗뵆由??앹꽦
  useEffect(() => {
    const generateTemplate = async () => {
      if (currentAnalysis && currentImageUrl) {
        try {
          const html = await generateTemplateHTML(currentAnalysis, currentImageUrl)
          setTemplateHTML(html)
        } catch (error) {
          console.error('?쒗뵆由??앹꽦 ?ㅽ뙣:', error)
          // ?숆린 踰꾩쟾?쇰줈 fallback
          const syncHTML = generateSyncTemplateHTML(currentAnalysis, currentImageUrl)
          setTemplateHTML(syncHTML)
        }
      }
    }
    
    generateTemplate()
  }, [currentAnalysis, currentImageUrl])
  
  // ?곸꽭 ?뺣낫 紐⑤떖 ?곹깭
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [detailInfo, setDetailInfo] = useState({
    shipmentDate: '',
    stockQuantity: '',
    salesUnit: '',
    price: ''
  })
  const [isSaving, setIsSaving] = useState(false)
  const [showSavedPages, setShowSavedPages] = useState(false)
  const [savedPages, setSavedPages] = useState<Array<{
    id: string;
    crop_name: string;
    crop_type?: string;
    created_at: string;
    html_content?: string;
    marketing_summary?: string;
  }>>([])
  const [savedPagesCount, setSavedPagesCount] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isLoadingPages, setIsLoadingPages] = useState(false)
  const itemsPerPage = 5

  // ?뚯궗 API濡?HTML 肄섑뀗痢??꾩넚?섎뒗 ?⑥닔 (遺紐?李??듭떊 諛⑹떇)
  const sendToCompanyAPI = async (htmlContent: string): Promise<{ success: boolean; message: string; data?: Record<string, unknown> }> => {
    try {
      // URL?먯꽌 ?좏겙 異붿텧
      const urlParams = new URLSearchParams(window.location.search);
      const urlToken = urlParams.get('token');
      
      // HTML 肄섑뀗痢좎뿉??body ?댁슜留?異붿텧
      let cleanHtmlContent = htmlContent;
      const bodyMatch = cleanHtmlContent.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
      if (bodyMatch) {
        cleanHtmlContent = bodyMatch[1].trim();
      }
      
      // ?뚯궗 API ?꾩넚 (?좏겙???덈뒗 寃쎌슦?먮쭔)
      if (!urlToken) {
        console.warn('?좑툘 URL???좏겙???놁뼱???뚯궗 API ?꾩넚??嫄대꼫?곷땲??');
        return { success: false, message: 'URL???좏겙???놁뒿?덈떎.' };
      }

      // ?뚯궗 肄쒕갚 API濡?HTML 肄섑뀗痢??꾩넚
      const callbackPayload = {
        token: urlToken,
        description: cleanHtmlContent
      };
      
      // 媛쒕컻 ?쒕쾭? 蹂??쒕쾭 紐⑤몢 ?쒕룄
      const callbackUrls = [
        'https://academy.runmoa.com/api/farm-contents-update',
        'http://dev01.schoolmoa.net/api/farm-contents-update'
      ];
      
      let callbackSuccess = false;
      let callbackError = '';
      
      for (const url of callbackUrls) {
        try {
          console.log(`[API ?몄텧 ?쒖옉] URL: ${url}`);
          console.log(`[?붿껌 ?곗씠?? Token: ${urlToken?.substring(0, 20)}..., Content Length: ${cleanHtmlContent.length}`);
          
          const callbackResponse = await fetch(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(callbackPayload)
          });
          
          const responseStatus = callbackResponse.status;
          console.log(`?뱿 [?묐떟 ?곹깭] ${url} ??HTTP ${responseStatus}`);
          
          if (callbackResponse.ok) {
            const callbackResult = await callbackResponse.json();
            console.log(`??[API ?깃났] ${url}:`, callbackResult);
            
            if (callbackResult.success === true) {
              callbackSuccess = true;
              const successMessage = `?뚯궗 API ?꾩넚 ?깃났! ?쒕쾭: ${url.includes('academy') ? '蹂몄꽌踰? : '媛쒕컻?쒕쾭'}, ?꾩씠??ID: ${callbackResult.item_id}`;
              console.log(`?럦 ${successMessage}, ?좏겙: ${urlToken.substring(0, 20)}...`);
              return { success: true, message: successMessage, data: callbackResult };
            } else {
              console.error(`??[API ?쇰━ ?ㅻ쪟] ${url}:`, callbackResult);
              callbackError = callbackResult.error || callbackResult.message || 'Unknown error';
            }
          } else {
            // HTTP ?ㅻ쪟 ?곹깭蹂??곸꽭 泥섎━
            let errorMessage = '';
            try {
              const errorResult = await callbackResponse.json();
              errorMessage = errorResult.error || `HTTP ${responseStatus} ?ㅻ쪟`;
              console.log(`?뱥 [?ㅻ쪟 ?묐떟 蹂몃Ц] ${url}:`, errorResult);
            } catch {
              const errorText = await callbackResponse.text();
              errorMessage = errorText;
              console.log(`?뱥 [?ㅻ쪟 ?묐떟 ?띿뒪?? ${url}: ${errorText}`);
            }
            
            switch (responseStatus) {
              case 400:
                console.error(`??[400 Bad Request] ${url}: ?꾨씫??留ㅺ컻蹂??- ${errorMessage}`);
                callbackError = `留ㅺ컻蹂???ㅻ쪟: ${errorMessage}`;
                break;
              case 401:
                console.error(`??[401 Unauthorized] ${url}: ?섎せ???좏겙 - ${errorMessage}`);
                callbackError = `?몄쬆 ?ㅻ쪟: ${errorMessage}`;
                break;
              case 403:
                console.error(`??[403 Forbidden] ${url}: ?ъ씠??ID 遺덉씪移?- ${errorMessage}`);
                callbackError = `沅뚰븳 ?ㅻ쪟: ${errorMessage}`;
                break;
              case 419:
                console.error(`??[419 CSRF] ${url}: CSRF ?좏겙 留뚮즺 - ${errorMessage}`);
                callbackError = `CSRF ?좏겙 ?ㅻ쪟: ?뚯궗?먯꽌 API 寃쎈줈瑜?CSRF ?덉쇅 泥섎━?댁＜?몄슂`;
                break;
              case 500:
                console.error(`??[500 Internal Error] ${url}: ?쒕쾭 ?대? ?ㅻ쪟 - ${errorMessage}`);
                callbackError = `?쒕쾭 ?ㅻ쪟: ${errorMessage}`;
                break;
              default:
                console.error(`??[HTTP ${responseStatus}] ${url}: ${errorMessage}`);
                callbackError = `HTTP ${responseStatus} ?ㅻ쪟: ${errorMessage}`;
            }
          }
        } catch (err) {
          console.error(`??[?ㅽ듃?뚰겕 ?ㅻ쪟] ${url}:`, err);
          callbackError = err instanceof Error ? err.message : '?ㅽ듃?뚰겕 ?ㅻ쪟';
        }
      }
      
      if (!callbackSuccess) {
        console.warn(`?좑툘 [理쒖쥌 寃곌낵] 紐⑤뱺 ?뚯궗 API ?꾩넚 ?ㅽ뙣: ${callbackError}`);
        return { success: false, message: callbackError };
      }
      
      // ?ш린源뚯? ?ㅻ㈃ 紐⑤뱺 ?쒕쾭?먯꽌 ?ㅽ뙣
      console.error(`??[移섎챸???ㅻ쪟] ?덉긽移?紐삵븳 ?곹솴: 紐⑤뱺 ?쒕쾭?먯꽌 ?꾩넚 ?ㅽ뙣`);
      return { success: false, message: '紐⑤뱺 ?쒕쾭?먯꽌 ?꾩넚 ?ㅽ뙣' };
      
    } catch (error) {
      console.error('?뚯궗 API ?꾩넚 以??ㅻ쪟:', error);
      return { success: false, message: error instanceof Error ? error.message : '?????녿뒗 ?ㅻ쪟' };
    }
  };

  // ??λ맂 ?곸꽭?섏씠吏 媛쒖닔 遺덈윭?ㅺ린 (?섏씠吏 濡쒕뱶 ??
  const loadSavedPagesCount = async () => {
    try {
      const response = await fetch('/api/detail-pages?limit=1');
      const result = await response.json();
      
      if (result.success && result.total) {
        setSavedPagesCount(result.total);
      }
    } catch (error) {
      console.error('??λ맂 ?섏씠吏 媛쒖닔 遺덈윭?ㅺ린 ?ㅽ뙣:', error);
    }
  }

  // ??λ맂 ?곸꽭?섏씠吏 紐⑸줉 遺덈윭?ㅺ린 (?섏씠吏?ㅼ씠???곸슜)
  const loadSavedPages = async (page: number = 1) => {
    try {
      setIsLoadingPages(true);
      // page媛 ?좏슚???レ옄?몄? ?뺤씤
      const validPage = Math.max(1, Math.floor(page) || 1);
      const offset = (validPage - 1) * itemsPerPage;
      
      console.log('Loading pages:', { page: validPage, offset, itemsPerPage }); // ?붾쾭源낆슜
      
      const response = await fetch(`/api/detail-pages?limit=${itemsPerPage}&offset=${offset}`);
      const result = await response.json();
      
      if (result.success) {
        setSavedPages(result.data || []);
        setSavedPagesCount(result.total || result.data?.length || 0);
        setCurrentPage(validPage);
        setTotalPages(Math.ceil((result.total || 0) / itemsPerPage));
        setShowSavedPages(true);
      }
    } catch (error) {
      console.error('??λ맂 ?섏씠吏 遺덈윭?ㅺ린 ?ㅽ뙣:', error);
    } finally {
      setIsLoadingPages(false);
    }
  }

  // ?섏씠吏 蹂寃??몃뱾??  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages && page !== currentPage) {
      loadSavedPages(page);
    }
  }

  // 媛쒕퀎 ?곸꽭?섏씠吏 ??젣
  const deletePage = async (pageId: string, pageName: string, hardDelete: boolean = false) => {
    const deleteTypeText = hardDelete ? '?꾩쟾 ??젣' : '?쇰컲 ??젣';
    const warningText = hardDelete 
      ? `"${pageName}" ?곸꽭?섏씠吏瑜??꾩쟾????젣?섏떆寃좎뒿?덇퉴?\n\n?좑툘 遺꾩꽍 寃곌낵源뚯? 紐⑤몢 ??젣?섎ŉ, ???묒뾽? ?섎룎由????놁뒿?덈떎.`
      : `"${pageName}" ?곸꽭?섏씠吏瑜???젣?섏떆寃좎뒿?덇퉴?\n\n遺꾩꽍 寃곌낵??蹂댁〈?섎ŉ, ?곸꽭?섏씠吏留???젣?⑸땲??`;
    
    if (!confirm(warningText)) {
      return;
    }
    
    // 鍮꾨?踰덊샇 ?뺤씤
    const password = prompt(
      `?뵍 ??젣 鍮꾨?踰덊샇瑜??낅젰?섏꽭??\n\n` +
      `??젣 諛⑹떇: ${deleteTypeText}\n` +
      `??? "${pageName}"\n\n` +
      `?좑툘 ???묒뾽? ?섎룎由????놁뒿?덈떎.`
    );
    
    if (password !== 'airunmoa') {
      if (password !== null) { // 痍⑥냼媛 ?꾨땶 寃쎌슦?먮쭔 ?ㅻ쪟 硫붿떆吏
        alert('??鍮꾨?踰덊샇媛 ?щ컮瑜댁? ?딆뒿?덈떎.');
      }
      return;
    }

    try {
      setIsLoadingPages(true); // 濡쒕뵫 ?곹깭 ?쒖떆
      
      const deleteUrl = hardDelete 
        ? `/api/detail-pages/${pageId}?type=hard`
        : `/api/detail-pages/${pageId}`;
      
      console.log('??젣 ?붿껌:', { pageId, deleteUrl, hardDelete });
      
      const response = await fetch(deleteUrl, {
        method: 'DELETE'
      });
      const result = await response.json();
      
      console.log('??젣 ?묐떟:', result);

      if (result.success) {
        // 利됱떆 紐⑸줉?먯꽌 ?대떦 ??ぉ ?쒓굅 (UI ?낅뜲?댄듃)
        const updatedPages = savedPages.filter(page => page.id !== pageId);
        setSavedPages(updatedPages);
        
        // ?덈줈??珥?媛쒖닔 怨꾩궛
        const newTotal = savedPagesCount - 1;
        setSavedPagesCount(newTotal);
        
        // ?꾩옱 ?섏씠吏????ぉ???놁쑝硫??댁쟾 ?섏씠吏濡??대룞
        if (updatedPages.length === 0 && currentPage > 1) {
          const targetPage = currentPage - 1;
          setCurrentPage(targetPage);
          loadSavedPages(targetPage);
        } else {
          // ?꾩옱 ?섏씠吏 ?덈줈怨좎묠
          loadSavedPages(currentPage);
        }
        
        // ?ㅼ젣 媛쒖닔 ?ㅼ떆 ?뺤씤 (諛깃렇?쇱슫?쒖뿉??
        loadSavedPagesCount();
        
        alert('?곸꽭?섏씠吏媛 ??젣?섏뿀?듬땲??');
      } else {
        alert('??젣???ㅽ뙣?덉뒿?덈떎: ' + result.error);
      }
    } catch (error) {
      console.error('??젣 ?ㅻ쪟:', error);
      alert('??젣 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.');
    } finally {
      setIsLoadingPages(false);
    }
  }

  // ?꾩껜 ??젣 (?쇰컲 ??젣)
  const deleteAllPages = async (hardDelete: boolean = false) => {
    const deleteTypeText = hardDelete ? '?꾩쟾 ??젣' : '?쇰컲 ??젣';
    const warningText = hardDelete
      ? `紐⑤뱺 ??λ맂 ?곸꽭?섏씠吏瑜??꾩쟾????젣?섏떆寃좎뒿?덇퉴?\n\n珥?${savedPagesCount}媛쒖쓽 ?섏씠吏媛 ??젣?⑸땲??\n?좑툘 遺꾩꽍 寃곌낵源뚯? 紐⑤몢 ??젣?섎ŉ, ???묒뾽? ?섎룎由????놁뒿?덈떎.`
      : `紐⑤뱺 ??λ맂 ?곸꽭?섏씠吏瑜???젣?섏떆寃좎뒿?덇퉴?\n\n珥?${savedPagesCount}媛쒖쓽 ?섏씠吏媛 ??젣?⑸땲??\n遺꾩꽍 寃곌낵??蹂댁〈?섎ŉ, ?곸꽭?섏씠吏留???젣?⑸땲??`;
    
    if (!confirm(warningText)) {
      return;
    }
    
    // 鍮꾨?踰덊샇 ?뺤씤
    const password = prompt(
      `?뵍 ?꾩껜 ??젣 鍮꾨?踰덊샇瑜??낅젰?섏꽭??\n\n` +
      `??젣 諛⑹떇: ${deleteTypeText}\n` +
      `??? 紐⑤뱺 ?곸꽭?섏씠吏 (${savedPagesCount}媛?\n\n` +
      `?좑툘 ???묒뾽? ?섎룎由????놁뒿?덈떎.`
    );
    
    if (password !== 'airunmoa') {
      if (password !== null) { // 痍⑥냼媛 ?꾨땶 寃쎌슦?먮쭔 ?ㅻ쪟 硫붿떆吏
        alert('??鍮꾨?踰덊샇媛 ?щ컮瑜댁? ?딆뒿?덈떎.');
      }
      return;
    }

    try {
      setIsLoadingPages(true); // 濡쒕뵫 ?곹깭 ?쒖떆
      
      const deletePromises = savedPages.map(page => {
        const deleteUrl = hardDelete 
          ? `/api/detail-pages/${page.id}?type=hard`
          : `/api/detail-pages/${page.id}`;
        return fetch(deleteUrl, { method: 'DELETE' });
      });
      
      await Promise.all(deletePromises);
      
      // ?곹깭 利됱떆 珥덇린??      setSavedPages([]);
      setSavedPagesCount(0);
      setCurrentPage(1);
      setTotalPages(1);
      
      // ?ㅼ젣 媛쒖닔 ?ㅼ떆 ?뺤씤 (諛깃렇?쇱슫?쒖뿉??
      await loadSavedPagesCount();
      
      // 紐⑤떖 ?リ린
      setShowSavedPages(false);
      
      alert('紐⑤뱺 ?곸꽭?섏씠吏媛 ??젣?섏뿀?듬땲??');
    } catch (error) {
      console.error('?꾩껜 ??젣 ?ㅻ쪟:', error);
      alert('??젣 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.');
    } finally {
      setIsLoadingPages(false);
    }
  }

  // ?섏씠吏 濡쒕뱶 ????λ맂 ?섏씠吏 媛쒖닔 遺덈윭?ㅺ린 諛?遺紐?李쎌뿉 以鍮??좏샇 ?꾩넚
  useEffect(() => {
    loadSavedPagesCount();
    
    // 遺紐?李쎌뿉 以鍮??꾨즺 ?좏샇 蹂대궡湲?    if (window.opener && !window.opener.closed) {
      try {
        window.opener.postMessage({
          type: 'AI_WINDOW_READY',
          timestamp: new Date().toISOString()
        }, '*');
        
        console.log('??遺紐?李쎌뿉 以鍮??꾨즺 ?좏샇瑜?蹂대깉?듬땲??');
      } catch (error) {
        console.error('遺紐?李?以鍮??좏샇 ?꾩넚 ?ㅻ쪟:', error);
      }
    }
  }, [])

  const handleImageUpload = async (file: File) => {
    try {
      // 1?④퀎: ?대?吏 ?낅줈???쒖옉
      setUploadProgress({
        progress: 5,
        status: 'uploading',
        message: '?뚯씪 寃利?以?..'
      })

      // ?뚯씪 寃利??④퀎
      await new Promise(resolve => setTimeout(resolve, 500))
      setUploadProgress({
        progress: 15,
        status: 'uploading',
        message: '?대?吏 理쒖쟻??以?..'
      })

      const formData = new FormData()
      formData.append('image', file)
      formData.append('filename', sanitizeFileName(file.name))

      // ?쒕쾭 ?낅줈???④퀎
      setUploadProgress({
        progress: 25,
        status: 'uploading',
        message: '?쒕쾭 ?낅줈??以?..'
      })

      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      if (!uploadResponse.ok) {
        throw new Error('?대?吏 ?낅줈?쒖뿉 ?ㅽ뙣?덉뒿?덈떎.')
      }

      const uploadResult = await uploadResponse.json()
      
      // ?낅줈?쒕맂 ?대?吏 URL ???      setCurrentImageUrl(uploadResult.publicUrl)
      
      // 2?④퀎: AI 遺꾩꽍 ?쒖옉
      setUploadProgress({
        progress: 35,
        status: 'analyzing',
        message: '?대?吏 ?꾩쿂由?以?..'
      })

      // ?대?吏 ?꾩쿂由??쒕??덉씠??      await new Promise(resolve => setTimeout(resolve, 800))
      setUploadProgress({
        progress: 50,
        status: 'analyzing',
        message: 'AI 紐⑤뜽 遺꾩꽍 以?..'
      })

      // AI 紐⑤뜽 遺꾩꽍 ?쒕??덉씠??      await new Promise(resolve => setTimeout(resolve, 1000))
      setUploadProgress({
        progress: 65,
        status: 'analyzing',
        message: '?묐Ъ ?뱀꽦 ?뚯븙 以?..'
      })

      // ?묐Ъ ?뱀꽦 ?뚯븙 ?쒕??덉씠??      await new Promise(resolve => setTimeout(resolve, 800))
      setUploadProgress({
        progress: 80,
        status: 'analyzing',
        message: '留덉???肄섑뀗痢??앹꽦 以?..'
      })

      // 2?④퀎: AI 遺꾩꽍
      const analysisResponse = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          imageUrl: uploadResult.publicUrl,
          imageFilename: uploadResult.filename,
          imageSize: file.size
        })
      })

      if (!analysisResponse.ok) {
        throw new Error('AI 遺꾩꽍???ㅽ뙣?덉뒿?덈떎.')
      }

      const analysisResult = await analysisResponse.json()

      // 3?④퀎: ?곸꽭?섏씠吏 ?앹꽦
      setUploadProgress({
        progress: 85,
        status: 'generating',
        message: '?ㅽ넗由ы뀛留?援ъ꽦 以?..'
      })

      // ?ㅽ넗由ы뀛留?援ъ꽦 ?쒕??덉씠??      await new Promise(resolve => setTimeout(resolve, 600))
      setUploadProgress({
        progress: 92,
        status: 'generating',
        message: 'SEO 理쒖쟻??以?..'
      })

      // SEO 理쒖쟻???쒕??덉씠??      await new Promise(resolve => setTimeout(resolve, 500))
      setUploadProgress({
        progress: 98,
        status: 'generating',
        message: '理쒖쥌 寃??以?..'
      })

      // 理쒖쥌 寃???쒕??덉씠??      await new Promise(resolve => setTimeout(resolve, 400))
      setUploadProgress({
        progress: 100,
        status: 'completed',
        message: '遺꾩꽍???꾨즺?섏뿀?듬땲??'
      })

      // 遺꾩꽍 寃곌낵瑜??ㅽ넗?댁뿉 ???      setCurrentAnalysis(analysisResult)

      // 寃곌낵 ?섏씠吏濡??대룞 (?꾩떆濡?遺꾩꽍 ?꾨즺 硫붿떆吏留??쒖떆)
      setTimeout(() => {
        // TODO: 寃곌낵 ?섏씠吏 援ы쁽 ???쒖꽦??        // router.push(`/results/${analysisResult.analysisId}`)
        console.log('遺꾩꽍 ?꾨즺:', analysisResult)
      }, 1000)

    } catch (error) {
      console.error('遺꾩꽍 ?ㅻ쪟:', error)
      setUploadProgress({
        progress: 0,
        status: 'error',
        message: error instanceof Error ? error.message : '遺꾩꽍 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.'
      })
    }
  }

  const isProcessing = uploadProgress.status === 'uploading' || 
                      uploadProgress.status === 'analyzing' || 
                      uploadProgress.status === 'generating'

  // HTML ?앹꽦, ???諛??ㅼ슫濡쒕뱶 ?⑥닔
  const generateAndDownloadHTML = async () => {
    if (!currentAnalysis?.analysis) return

    setIsSaving(true);
    
    try {
      // ?꾩옱 ?붾㈃???쒖떆?섎뒗 templateHTML???ъ슜
      let finalTemplateHTML = templateHTML;
      
      // templateHTML???놁쑝硫??덈줈 ?앹꽦
      if (!finalTemplateHTML) {
        console.log('?봽 ?쒗뵆由?HTML ?앹꽦 以?..');
        finalTemplateHTML = await generateTemplateHTML(currentAnalysis, currentImageUrl || '');
      }
      
      const htmlContent = `
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${currentAnalysis.analysis.crop_type || '?띿궛臾?}?섎씪 - 泥?젙 ?먯뿰?먯꽌 ?щ같???쒖쿋 ${currentAnalysis.analysis.crop_type || '?띿궛臾?}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700;900&display=swap" rel="stylesheet">
</head>
<body style="margin: 0; padding: 0; font-family: 'Noto Sans KR', sans-serif;">
    ${finalTemplateHTML}
</body>
</html>`;

      console.log('?뱞 ?앹꽦??HTML 湲몄씠:', htmlContent.length);
      
      // 1. Supabase???곸꽭?섏씠吏 ???      console.log('?뵇 ????쒕룄:', {
        analysisId: currentAnalysis.analysisId,
        cropType: currentAnalysis.analysis.crop_type
      });
      
      const saveResponse = await fetch('/api/detail-pages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          analysis_id: currentAnalysis.analysisId,
          crop_type: currentAnalysis.analysis.crop_type || '?띿궛臾?,
          crop_name: `${currentAnalysis.analysis.crop_type || '?띿궛臾?} (${new Date().toLocaleDateString('ko-KR')})`,
          detail_info: detailInfo,
          html_content: htmlContent,
          marketing_summary: currentAnalysis.analysis.marketing_content?.hero_message || 
                           `${currentAnalysis.analysis.crop_type || '?띿궛臾?} ?곸꽭?섏씠吏`,
          key_features: currentAnalysis.analysis.marketing_content?.product_features?.map(f => f.title) || [],
          target_keywords: currentAnalysis.analysis.marketing_content?.seo_content?.main_keywords || []
        })
      });

      console.log('?뱾 ????붿껌 ?곗씠??', {
        analysis_id: currentAnalysis.analysisId,
        crop_type: currentAnalysis.analysis.crop_type,
        detail_info: detailInfo
      });
      
      console.log('?뱿 ????묐떟 ?곹깭:', saveResponse.status, saveResponse.statusText);
      
      const saveResult = await saveResponse.json();
      console.log('?뱿 ????묐떟 ?곗씠??', saveResult);
      
      if (!saveResponse.ok) {
        console.error('??????ㅽ뙣:', saveResult);
        alert(`????ㅽ뙣: ${saveResult.error || '?????녿뒗 ?ㅻ쪟'}`);
      } else {
        console.log('???곸꽭?섏씠吏媛 ?깃났?곸쑝濡???λ릺?덉뒿?덈떎!', saveResult.data);
        
        // 2. ?ㅼ슫濡쒕뱶 移댁슫??利앷?
        if (saveResult.data?.id) {
          const downloadResponse = await fetch(`/api/detail-pages/${saveResult.data.id}/download`, {
            method: 'POST'
          });
          console.log('?뱤 ?ㅼ슫濡쒕뱶 移댁슫???낅뜲?댄듃:', downloadResponse.status);
        }
        
        // 3. ?뚯궗 API濡??먮룞 ?꾩넚
        await sendToCompanyAPI(htmlContent);
        
        alert('???곸꽭?섏씠吏媛 ?깃났?곸쑝濡???λ릺?덉뒿?덈떎!');
      }
      
      // 4. HTML ?뚯씪 ?ㅼ슫濡쒕뱶
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const cropName = (currentAnalysis.analysis.crop_type || '?띿궛臾?).replace(/\s+/g, '_');
      const dateStr = new Date().toISOString().split('T')[0];
      link.download = `${cropName}_?곸꽭?섏씠吏_${dateStr}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
    } catch (error) {
      console.error('?????以??ㅻ쪟 諛쒖깮:', error);
      alert('???以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎. ?ㅼ떆 ?쒕룄?댁＜?몄슂.');
    } finally {
      setIsSaving(false);
      setShowDetailModal(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <Navigation />
      
      {/* ?뚮줈???≪뀡 踰꾪듉 - ??λ맂 ?곸꽭?섏씠吏 蹂닿린 */}
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50">
        <div className="relative group">
                                     <Button
             onClick={() => {
               setCurrentPage(1); // ?섏씠吏瑜?1濡?由ъ뀑
               loadSavedPages(1);
             }}
             className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center relative active:scale-95"
             title="??λ맂 ?곸꽭?섏씠吏 蹂닿린"
           >
            <span className="text-lg md:text-xl">?뱥</span>
            
            {/* 諭껋? - ??λ맂 ?섏씠吏 媛쒖닔 */}
            {savedPagesCount > 0 && (
              <div className="absolute -top-1 -right-1 md:-top-2 md:-right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 md:w-6 md:h-6 flex items-center justify-center font-bold shadow-md">
                {savedPagesCount > 99 ? '99+' : savedPagesCount}
              </div>
            )}
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-400 to-blue-500 rounded-full mb-4 shadow-lg">
            <span className="text-3xl">?뵇</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4">
            AI ?띿궛臾?遺꾩꽍
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            ?대?吏 ?낅줈?쒕쭔?쇰줈 ?띿궛臾쇱쓽 ?덉쭏, ?뱀꽦, 留덉????ъ씤?몃? AI媛 ?먮룞?쇰줈 遺꾩꽍?대뱶由쎈땲??          </p>
        </div>

        {/* ?대?吏 ?낅줈??諛?遺꾩꽍 寃곌낵 ?곸뿭 */}
        {!currentAnalysis.analysis ? (
          <ImageUpload 
            onUploadComplete={handleUploadComplete}
            uploadProgress={uploadProgress}
            isProcessing={isProcessing}
          />
        ) : (
          <div className="space-y-8">
            {/* 遺꾩꽍 寃곌낵 ?쒖떆 */}
            {currentImageUrl && (
              <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4 text-gray-800 flex items-center justify-center">
                  <span className="mr-2">?벜</span>
                  遺꾩꽍???대?吏
                </h3>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <Image 
                    src={currentImageUrl} 
                    alt="遺꾩꽍???띿궛臾??대?吏" 
                    width={500}
                    height={400}
                    className="w-full max-w-lg mx-auto rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
                    style={{ maxHeight: '400px', objectFit: 'contain' }}
                  />
                  <p className="text-sm text-gray-600 text-center mt-3 font-medium">
                    ???대?吏瑜?AI媛 遺꾩꽍??寃곌낵?낅땲??                  </p>
                </div>
              </div>
            )}

            {/* ?곸꽭 ?뺣낫 異붽? & ?뚯씪 ???踰꾪듉 */}
            <div className="flex justify-center">
              <Button 
                onClick={() => setShowDetailModal(true)}
                className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3"
                size="lg"
                disabled={currentAnalysis.analysis?.crop_type === 'N/A'}
              >
                ?뱷 ?곸꽭 ?뺣낫 異붽? & ?뚯씪 ???              </Button>
            </div>

            {/* fruits_type ?쒗뵆由?湲곕컲 ?곸꽭 ?섏씠吏 */}
            <div className="w-full mt-6">
              <div 
                dangerouslySetInnerHTML={{
                  __html: templateHTML || '?쒗뵆由우쓣 ?앹꽦?섎뒗 以?..'
                }}
              />
            </div>

            {/* ??遺꾩꽍 踰꾪듉 */}
            <div className="pt-4 border-t">
              <Button 
                onClick={() => {
                  clearCurrentAnalysis()
                  window.location.reload()
                }}
                variant="outline"
                className="w-full text-lg py-3 border-2 border-gray-300 hover:border-green-500 hover:text-green-600 transition-colors duration-200"
                size="lg"
              >
                ?벝 ???대?吏 遺꾩꽍?섍린
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif;
            line-height: 1.6;
            color: #272727;
        }

        /* 而⑦뀒?대꼫 */
        .main-container {
            background-color: #f5f5f5;
            min-height: 100vh;
            padding: 20px 16px;
        }

        @media (min-width: 768px) {
