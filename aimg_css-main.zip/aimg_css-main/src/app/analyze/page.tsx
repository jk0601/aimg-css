﻿'use client'

import { useState, useEffect } from 'react'
import { Navigation } from '@/components/custom/Navigation'
import { ImageUploader } from '@/components/custom/ImageUploader'
import { AnalysisProgress } from '@/components/custom/AnalysisProgress'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAnalysisStore } from '@/store/analysisStore'
import { sanitizeFileName } from '@/lib/utils'
import Image from 'next/image'


// 이미지를 base64로 변환하는 함수
const imageToBase64 = async (imageUrl: string): Promise<string> => {
  try {
    const response = await fetch(imageUrl)
    const blob = await response.blob()
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result as string)
      reader.onerror = reject
      reader.readAsDataURL(blob)
    })
  } catch (error) {
    console.error('이미지 변환 실패:', error)
    return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuydtOuvuOyngCDsl4bsnYw8L3RleHQ+PC9zdmc+'
  }
}

// 템플릿 HTML 생성 함수 (비동기로 변경)
const generateTemplateHTML = async (currentAnalysis: any, currentImageUrl: string) => {
  // 이미지를 base64로 변환
  let base64Image = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuydtOuvuOyngCDsl4bsnYw8L3RleHQ+PC9zdmc+'
  
  // 아이콘들을 base64로 변환 (fallback SVG 포함)
  const iconSmile = await imageToBase64('/images/icon_smile.png').catch(() => 
    'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSI0MCIgY3k9IjQwIiByPSIzNSIgZmlsbD0iI0ZGRkZGRiIgc3Ryb2tlPSIjNDJBNUY1IiBzdHJva2Utd2lkdGg9IjIiLz48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSIzIiBmaWxsPSIjNDJBNUY1Ii8+PGNpcmNsZSBjeD0iNTAiIGN5PSIzMCIgcj0iMyIgZmlsbD0iIzQyQTVGNSIvPjxwYXRoIGQ9Ik0yNSA1MFE0MCA2MCA1NSA1MCIgc3Ryb2tlPSIjNDJBNUY1IiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiLz48L3N2Zz4='
  )
  const iconDelivery = await imageToBase64('/images/icon_delivery.png').catch(() => 
    'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB4PSIxMCIgeT0iMzAiIHdpZHRoPSI0MCIgaGVpZ2h0PSIyMCIgZmlsbD0iI0ZGRkZGRiIgc3Ryb2tlPSIjNDJBNUY1IiBzdHJva2Utd2lkdGg9IjIiLz48cmVjdCB4PSI1MCIgeT0iMzUiIHdpZHRoPSIxNSIgaGVpZ2h0PSIxNSIgZmlsbD0iI0ZGRkZGRiIgc3Ryb2tlPSIjNDJBNUY1IiBzdHJva2Utd2lkdGg9IjIiLz48Y2lyY2xlIGN4PSIyMCIgY3k9IjU1IiByPSI1IiBmaWxsPSIjNDJBNUY1Ii8+PGNpcmNsZSBjeD0iNTUiIGN5PSI1NSIgcj0iNSIgZmlsbD0iIzQyQTVGNSIvPjwvc3ZnPg=='
  )
  const iconRelief = await imageToBase64('/images/icon_relief.png').catch(() => 
    'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNDAgMTBMMzUgMjVIMjBMMzIgMzVMMjcgNTBMNDAgNDBMNTMgNTBMNDggMzVMNjAgMjVINDVMNDAgMTBaIiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiM0MkE1RjUiIHN0cm9rZS13aWR0aD0iMiIvPjwvc3ZnPg=='
  )
  
  if (currentImageUrl) {
    try {
      base64Image = await imageToBase64(currentImageUrl)
      console.log('✅ 이미지 base64 변환 성공')
    } catch (error) {
      console.error('❌ 이미지 변환 실패:', error)
    }
  }
  
  console.log('🖼️ 사용할 이미지:', base64Image.substring(0, 50) + '...')
  console.log('📏 이미지 전체 길이:', base64Image.length)
  console.log('🔍 이미지 타입 확인:', base64Image.substring(0, 30))
  
  // CSS 생성 테스트
  const testCss = `background-image: url('` + base64Image.substring(0, 100) + `...');`
  console.log('🎨 생성될 CSS 샘플:', testCss)
  
  const cropType = currentAnalysis?.analysis?.crop_type || '농산물'
  const satisfaction = currentAnalysis?.analysis?.marketing_content?.conclusion_first?.satisfaction || '달콤하고 신선한 맛이 일품'
  const climax = currentAnalysis?.analysis?.marketing_content?.story_structure?.climax || '신선함을 그대로 전달해드립니다'
  const development = currentAnalysis?.analysis?.marketing_content?.story_structure?.development || '우리 농장은 햇빛이 잘 드는 지역에서 자연스럽게 자란 농산물을 재배합니다'
  const snsPoint = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.sns_point || '인스타 스토리에서 반응 폭발 예정'
  const homecafeUse = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.homecafe_use || '요거트볼, 스무디, 샐러드까지 완벽'
  const giftMessage = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.gift_message || '건강 챙기는 마음까지 전달되는 선물'
  
  // 완전히 격리된 템플릿 HTML
  return `
    <div class="fruits-template-isolated">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700;900&display=swap" rel="stylesheet">
      
      <style>
        /* 완전히 격리된 스타일 - 오직 .fruits-template-isolated 내부에서만 적용 */
        .fruits-template-isolated {
          all: initial !important;
          display: block !important;
          font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif !important;
          line-height: 1.6 !important;
          color: #272727 !important;
          background-color: #f5f5f5 !important;
          padding: 20px 16px !important;
          margin: 0 !important;
          box-sizing: border-box !important;
          width: 100% !important;
          position: relative !important;
          z-index: 1 !important;
        }
        
        .fruits-template-isolated * {
          margin: 0 !important;
          padding: 0 !important;
          border: 0 !important;
          outline: 0 !important;
          vertical-align: baseline !important;
          box-sizing: border-box !important;
          /* 중요한 속성들은 유지 */
          display: revert !important;
          background: revert !important;
          /* background-image는 인라인 스타일이 우선되도록 unset 사용 */
          background-image: unset !important;
          background-size: revert !important;
          background-position: revert !important;
          filter: inherit !important;
          transform: inherit !important;
          transition: inherit !important;
          position: revert !important;
          width: revert !important;
          height: revert !important;
          color: revert !important;
          font-family: revert !important;
          font-size: revert !important;
          font-weight: revert !important;
          line-height: revert !important;
          text-align: revert !important;
        }
      
        .fruits-template-isolated .template-container {
          font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif !important;
          line-height: 1.6 !important;
          color: #272727 !important;
          background-color: #f5f5f5 !important;
          padding: 20px 16px !important;
          margin: 0 !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .content-wrapper {
          max-width: 900px !important;
          margin: 0 auto !important;
          background-color: white !important;
          border-radius: 15px !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1) !important;
          overflow: hidden !important;
        }
        
        .fruits-template-isolated .header {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 10px !important;
          padding: 80px 20px 50px !important;
          background-color: #272727 !important;
          color: white !important;
          font-size: 36px !important;
          font-weight: bold !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .header h1 {
          margin: 0 !important;
          padding: 0 !important;
          font-size: inherit !important;
          font-weight: inherit !important;
          color: inherit !important;
        }
        
        .fruits-template-isolated .hero-section {
          min-height: 600px !important;
          background-color: white !important;
          position: relative !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .hero-background {
          width: 100% !important;
          height: 400px !important;
          position: absolute !important;
          top: 200px !important;
          left: 0 !important;
          /* background 는 인라인 스타일로 설정 */
        }
        
        .fruits-template-isolated .hero-content {
          position: absolute !important;
          top: 50px !important;
          left: 0 !important;
          z-index: 2 !important;
          right: 0 !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .hero-subtitle {
          font-size: 32px !important;
          font-weight: bold !important;
          color: #696868 !important;
          margin-bottom: 20px !important;
          margin-top: 0 !important;
          padding: 0 !important;
        }
        
        .fruits-template-isolated .hero-title {
          font-size: 60px !important;
          font-weight: 900 !important;
          color: #272727 !important;
          position: relative !important;
          display: inline-block !important;
          padding: 0 20px !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .hero-title::after {
          content: '' !important;
          position: absolute !important;
          bottom: 8px !important;
          left: 0 !important;
          right: 0 !important;
          height: 30px !important;
          background-color: #fcecea !important;
          z-index: -1 !important;
        }
        
        .fruits-template-isolated .temp-content {
          padding: 40px !important;
          text-align: center !important;
          background: white !important;
        }
        
        .fruits-template-isolated .temp-content h3 {
          font-size: 24px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin: 0 0 20px 0 !important;
          padding: 0 !important;
        }
        
        .fruits-template-isolated .temp-content p {
          font-size: 16px !important;
          color: #666 !important;
          margin: 0 !important;
          padding: 0 !important;
          line-height: 1.6 !important;
        }
        
        /* 메인 컨테이너 */
        .fruits-template-isolated .main-container {
          background-color: #f5f5f5 !important;
          min-height: 100vh !important;
          padding: 20px 16px !important;
        }
        
        .fruits-template-isolated .content-wrapper {
          max-width: 900px !important;
          margin: 0 auto !important;
          background-color: white !important;
          border-radius: 15px !important;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1) !important;
          overflow: hidden !important;
        }
        
        /* 헤더 재정의 */
        .fruits-template-isolated .header {
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          gap: 10px !important;
          padding: 80px 20px 50px !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          margin: 0 auto !important;
          width: fit-content !important;
          background-color: #272727 !important;
          z-index: 10 !important;
        }
        
        /* 히어로 섹션 재정의 */
        .fruits-template-isolated .hero-section {
          min-height: 1400px !important;
          background-color: white !important;
          position: relative !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .hero-background {
          width: 100% !important;
          height: 860px !important;
          position: absolute !important;
          top: 540px !important;
          left: 0 !important;
          /* background 는 인라인 스타일로 설정 */
        }
        
        .fruits-template-isolated .hero-content {
          width: 100% !important;
          height: 170px !important;
          position: absolute !important;
          z-index: 2 !important;
          top: 264px !important;
          left: 0 !important;
          right: 0 !important;
        }
        
        .fruits-template-isolated .hero-text-container {
          display: flex !important;
          flex-direction: column !important;
          gap: 25px !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          margin: 0 auto !important;
          width: fit-content !important;
          align-items: center !important;
        }
        
        .fruits-template-isolated .hero-subtitle {
          width: fit-content !important;
          margin-top: -1px !important;
          font-weight: bold !important;
          color: #696868 !important;
          font-size: 40px !important;
          text-align: center !important;
          letter-spacing: -0.8px !important;
          line-height: normal !important;
          white-space: nowrap !important;
        }
        
        .fruits-template-isolated .hero-title-container {
          position: relative !important;
        }
        
        .fruits-template-isolated .hero-title {
          font-weight: 900 !important;
          color: #272727 !important;
          font-size: 80px !important;
          text-align: center !important;
          letter-spacing: -1.6px !important;
          line-height: normal !important;
          white-space: nowrap !important;
          position: relative !important;
          z-index: 2 !important;
        }
        
        .fruits-template-isolated .hero-title-background {
          position: absolute !important;
          width: 100% !important;
          height: 50px !important;
          left: 0 !important;
          bottom: 8px !important;
          background-color: #fcecea !important;
          z-index: 1 !important;
        }
        
        /* 특징 섹션 */
        .fruits-template-isolated .features-section {
          background-color: white !important;
          padding: 80px 40px !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .features-container {
          max-width: 800px !important;
          margin: 0 auto !important;
        }
        
        .fruits-template-isolated .features-grid {
          display: flex !important;
          align-items: center !important;
          justify-content: space-between !important;
          gap: 40px !important;
        }
        
        .fruits-template-isolated .feature-item {
          flex: 1 !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .feature-content {
          display: flex !important;
          flex-direction: column !important;
          align-items: center !important;
          gap: 20px !important;
        }
        
        .fruits-template-isolated .feature-icon {
          width: 80px !important;
          height: 80px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .fruits-template-isolated .feature-icon img {
          width: 100% !important;
          height: 100% !important;
          object-fit: contain !important;
        }
        
        .fruits-template-isolated .feature-text {
          text-align: center !important;
        }
        
        .fruits-template-isolated .feature-title {
          font-size: 24px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin-bottom: 10px !important;
        }
        
        .fruits-template-isolated .feature-description {
          font-size: 16px !important;
          color: #666 !important;
          line-height: 1.6 !important;
        }
        
        .fruits-template-isolated .feature-divider {
          width: 2px !important;
          height: 120px !important;
          background-color: #e0e0e0 !important;
          flex-shrink: 0 !important;
        }
        
        /* 리뷰 섹션 */
        .fruits-template-isolated .reviews-section {
          /* background 는 인라인 스타일로 설정 */
          padding: 80px 40px !important;
          position: relative !important;
          min-height: 800px !important;
        }
        
        
        .fruits-template-isolated .reviews-background {
          max-width: 800px !important;
          margin: 0 auto !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .reviews-header {
          text-align: center !important;
          margin-bottom: 60px !important;
        }
        
        .fruits-template-isolated .reviews-subtitle {
          font-size: 24px !important;
          color: #ffffff !important;
          margin-bottom: 10px !important;
        }
        
        .fruits-template-isolated .reviews-title {
          font-size: 48px !important;
          font-weight: 900 !important;
          color: #ffffff !important;
        }
        
        .fruits-template-isolated .reviews-container {
          display: flex !important;
          flex-direction: column !important;
          gap: 30px !important;
        }
        
        .fruits-template-isolated .review-card {
          background: white !important;
          border-radius: 15px !important;
          padding: 20px !important;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
          overflow: hidden !important;
          margin-bottom: 20px !important;
        }
        
        .fruits-template-isolated .review-content {
          display: flex !important;
          gap: 15px !important;
          align-items: flex-start !important;
          width: 100% !important;
        }
        
        .fruits-template-isolated .review-avatar {
          width: 60px !important;
          height: 60px !important;
          border-radius: 50% !important;
          flex-shrink: 0 !important;
          overflow: hidden !important;
          border: 2px solid #f0f0f0 !important;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
        }
        
        .fruits-template-isolated .review-avatar img {
          width: 100% !important;
          height: 100% !important;
          object-fit: cover !important;
          display: block !important;
          border-radius: 50% !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .review-avatar:hover img {
          transform: scale(1.1) !important;
        }
        
        /* 필터 효과 강제 적용 */
        .fruits-template-isolated img[style*="filter"] {
          filter: inherit !important;
        }
        
        .fruits-template-isolated div[style*="filter"] {
          filter: inherit !important;
        }
        
        /* 각 리뷰 카드별 필터 효과 */
        .fruits-template-isolated .review-card:nth-child(1) .review-avatar img {
          filter: hue-rotate(120deg) saturate(1.4) brightness(1.1) contrast(1.2) !important;
        }
        
        .fruits-template-isolated .review-card:nth-child(2) .review-avatar img {
          filter: hue-rotate(240deg) saturate(1.2) brightness(1.2) sepia(0.3) !important;
        }
        
        .fruits-template-isolated .review-card:nth-child(3) .review-avatar img {
          filter: grayscale(0.4) brightness(1.3) contrast(1.1) blur(0.5px) !important;
        }
        
        .fruits-template-isolated .review-text {
          flex: 1 !important;
          min-width: 0 !important;
          overflow: hidden !important;
        }
        
        .fruits-template-isolated .review-stars {
          display: flex !important;
          gap: 3px !important;
          margin-bottom: 8px !important;
        }
        
        .fruits-template-isolated .star-icon {
          width: 14px !important;
          height: 14px !important;
          fill: #ffd700 !important;
          stroke: #ffd700 !important;
          flex-shrink: 0 !important;
        }
        
        .fruits-template-isolated .review-title {
          font-size: 16px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin: 0 0 6px 0 !important;
          line-height: 1.4 !important;
          word-wrap: break-word !important;
        }
        
        .fruits-template-isolated .review-description {
          font-size: 13px !important;
          color: #666 !important;
          line-height: 1.5 !important;
          margin: 0 !important;
          word-wrap: break-word !important;
        }
        
        /* 소개 섹션 */
        .fruits-template-isolated .intro-section {
          background-color: white !important;
          padding: 80px 40px !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .intro-content {
          max-width: 800px !important;
          margin: 0 auto !important;
          display: flex !important;
          align-items: center !important;
          gap: 60px !important;
        }
        
        .fruits-template-isolated .intro-text {
          flex: 1 !important;
          font-size: 18px !important;
          color: #272727 !important;
          line-height: 1.8 !important;
          margin: 0 !important;
          padding: 0 !important;
        }
        
        .fruits-template-isolated .intro-image {
          flex: 1 !important;
          height: 400px !important;
          /* background 는 인라인 스타일로 설정 */
          background-size: cover !important;
          background-position: center !important;
          border-radius: 15px !important;
          box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1) !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .intro-image:hover {
          transform: scale(1.03) !important;
          box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15) !important;
        }
        
        /* 반응형 디자인 */
        @media (max-width: 768px) {
          .fruits-template-isolated .intro-content {
            flex-direction: column !important;
            gap: 30px !important;
          }
          
          .fruits-template-isolated .intro-text {
            text-align: center !important;
            font-size: 16px !important;
          }
          
          .fruits-template-isolated .intro-image {
            height: 300px !important;
            width: 100% !important;
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            transform: none !important;
            filter: blur(1px) brightness(1.1) !important;
            background-color: red !important;
            min-height: 300px !important;
          }
        }
        
        /* POINT 섹션들 */
        .fruits-template-isolated .point-section {
          position: relative !important;
          min-height: 600px !important;
        }
        
        /* POINT 01 - 밝은 배경 이미지 */
        .fruits-template-isolated .point-01 {
          background-color: white !important;
          position: relative !important;
          overflow: hidden !important;
          min-height: 600px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .fruits-template-isolated .point-01::before {
          content: '' !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          background: rgba(255,255,255,0.85) !important;
          z-index: 1 !important;
        }

        .fruits-template-isolated .point-01 .point-background {
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          z-index: 0 !important;
          /* background-image 는 인라인 스타일로 설정 */
          background-size: cover !important;
          background-position: center !important;
          background-repeat: no-repeat !important;
          /* filter: brightness(2) contrast(0.3) saturate(0.2) opacity(0.3) !important; */
        }
        
        /* 공통 POINT 콘텐츠 스타일 */
        .fruits-template-isolated .point-content {
          position: relative !important;
          z-index: 999 !important;
          text-align: center !important;
          color: #000000 !important;
          max-width: 600px !important;
          padding: 40px !important;
          font-weight: 600 !important;
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
        }
        
        .fruits-template-isolated .point-01 .point-number {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-01 .point-subtitle {
          color: #666 !important;
        }
        
        .fruits-template-isolated .point-01 .point-title {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-01 .point-description {
          color: #666 !important;
        }
        
        /* POINT 03 - 어두운 배경 이미지 */
        .fruits-template-isolated .point-03 {
          background-color: #272727 !important;
          position: relative !important;
          overflow: hidden !important;
          min-height: 600px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
        }
        
        .fruits-template-isolated .point-03::before {
          content: '' !important;
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          background: rgba(255,255,255,0.85) !important;
          z-index: 1 !important;
        }
        
        .fruits-template-isolated .point-03 .point-background {
          position: absolute !important;
          top: 0 !important;
          left: 0 !important;
          right: 0 !important;
          bottom: 0 !important;
          z-index: 0 !important;
          /* background-image 는 인라인 스타일로 설정 */
          background-size: cover !important;
          background-position: center !important;
          background-repeat: no-repeat !important;
          /* filter: brightness(2) contrast(0.3) saturate(0.2) opacity(0.3) !important; */
        }
        
        /* POINT 03 콘텐츠는 공통 규칙 사용 (중복 제거) */
        
        /* 공통 POINT 스타일 */
        .fruits-template-isolated .point-header {
          margin-bottom: 30px !important;
        }
        
        /* 텍스트 요소들 강제 표시 */
        .fruits-template-isolated .point-number,
        .fruits-template-isolated .point-subtitle,
        .fruits-template-isolated .point-title,
        .fruits-template-isolated .point-description {
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
          color: #000000 !important;
          z-index: 999 !important;
          position: relative !important;
        }
        
        .fruits-template-isolated .point-number {
          font-size: 24px !important;
          font-weight: bold !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .point-text-container {
          margin-bottom: 30px !important;
        }
        
        .fruits-template-isolated .point-subtitle {
          font-size: 20px !important;
          margin: 0 0 10px 0 !important;
        }
        
        .fruits-template-isolated .point-title {
          font-size: 48px !important;
          font-weight: 900 !important;
          margin: 0 !important;
          line-height: 1.2 !important;
        }
        
        .fruits-template-isolated .point-description {
          font-size: 18px !important;
          line-height: 1.6 !important;
          margin: 0 !important;
        }
        
        /* POINT 02 - 세로 정렬 레이아웃 */
        .fruits-template-isolated .point-02 {
          background-color: white !important;
          padding: 80px 40px !important;
        }
        
        .fruits-template-isolated .point-02-header {
          max-width: 800px !important;
          margin: 0 auto 60px auto !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .point-02 .point-number {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-02 .point-subtitle {
          color: #666 !important;
        }
        
        .fruits-template-isolated .point-02 .point-title {
          color: #272727 !important;
        }
        
        .fruits-template-isolated .point-02 .point-description {
          color: #666 !important;
        }
        
        .fruits-template-isolated .dessert-items {
          max-width: 600px !important;
          margin: 0 auto !important;
          display: flex !important;
          flex-direction: column !important;
          gap: 25px !important;
        }
        
        .fruits-template-isolated .dessert-item {
          display: flex !important;
          align-items: center !important;
          gap: 20px !important;
          padding: 15px !important;
          background: rgba(255, 255, 255, 0.03) !important;
          border-radius: 20px !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(even) {
          flex-direction: row-reverse !important;
        }
        
        .fruits-template-isolated .dessert-item:hover {
          background: rgba(255, 255, 255, 0.08) !important;
          transform: scale(1.02) !important;
        }
        
        .fruits-template-isolated .dessert-image {
          width: 120px !important;
          height: 120px !important;
          border-radius: 50% !important;
          overflow: hidden !important;
          flex-shrink: 0 !important;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15) !important;
        }
        
        .fruits-template-isolated .dessert-image img {
          width: 100% !important;
          height: 100% !important;
          object-fit: cover !important;
          display: block !important;
          transition: all 0.3s ease !important;
        }
        
        .fruits-template-isolated .dessert-image:hover img {
          transform: scale(1.1) !important;
        }
        
        /* POINT 02 디저트 이미지별 필터 */
        .fruits-template-isolated .dessert-item:nth-child(1) .dessert-image img {
          filter: brightness(1.2) saturate(1.3) contrast(1.1) !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(2) .dessert-image img {
          filter: hue-rotate(45deg) brightness(1.2) saturate(1.3) contrast(1.1) !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(3) .dessert-image img {
          filter: hue-rotate(90deg) brightness(1.2) saturate(1.3) contrast(1.1) !important;
        }
        
        .fruits-template-isolated .dessert-text {
          flex: 1 !important;
          font-size: 16px !important;
          color: #272727 !important;
          font-weight: 600 !important;
          line-height: 1.4 !important;
          word-break: keep-all !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(odd) .dessert-text {
          text-align: left !important;
        }
        
        .fruits-template-isolated .dessert-item:nth-child(even) .dessert-text {
          text-align: right !important;
        }
        
        @media (max-width: 768px) {
          .fruits-template-isolated .dessert-item {
            flex-direction: column !important;
          }
          
          .fruits-template-isolated .dessert-item:nth-child(even) {
            flex-direction: column !important;
          }
          
          .fruits-template-isolated .dessert-item:nth-child(odd) .dessert-text,
          .fruits-template-isolated .dessert-item:nth-child(even) .dessert-text {
            text-align: center !important;
          }
          
          .fruits-template-isolated .dessert-image {
            width: 100px !important;
            height: 100px !important;
          }
          
          .fruits-template-isolated .dessert-text {
            font-size: 14px !important;
          }
        }
        
        /* POINT 04 - 복합 섹션 */
        .fruits-template-isolated .point-04-section {
          background-color: #f8f8f8 !important;
          padding: 80px 40px !important;
        }
        
        .fruits-template-isolated .point-04-content {
          max-width: 800px !important;
          margin: 0 auto 60px auto !important;
          text-align: center !important;
        }
        
        .fruits-template-isolated .point-04-header-border {
          border: 2px solid #272727 !important;
          display: inline-block !important;
          padding: 10px 20px !important;
          margin-bottom: 30px !important;
        }
        
        .fruits-template-isolated .point-04-number {
          font-size: 24px !important;
          font-weight: bold !important;
          color: #272727 !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .point-04-subtitle {
          font-size: 20px !important;
          color: #666 !important;
          margin: 0 0 10px 0 !important;
        }
        
        .fruits-template-isolated .point-04-title {
          font-size: 48px !important;
          font-weight: 900 !important;
          color: #272727 !important;
          margin: 0 0 20px 0 !important;
        }
        
        .fruits-template-isolated .point-04-description {
          font-size: 18px !important;
          color: #666 !important;
          line-height: 1.6 !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .detail-images {
          display: flex !important;
          justify-content: center !important;
          align-items: center !important;
          gap: 20px !important;
          margin: 60px 0 !important;
        }
        
        .fruits-template-isolated .detail-image {
          width: 200px !important;
          height: 200px !important;
          object-fit: cover !important;
          border-radius: 10px !important;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1) !important;
          transition: all 0.3s ease !important;
        }
        
        /* 각 상세 이미지별 필터 효과
        .fruits-template-isolated .detail-image:nth-child(1) {
          filter: sepia(0.5) contrast(1.2) brightness(1.1) !important;
          transform: scale(1.02) !important;
        }
        
        .fruits-template-isolated .detail-image:nth-child(2) {
          filter: grayscale(0.3) brightness(1.2) blur(0.5px) !important;
          transform: rotate(-1deg) !important;
        }
        
        .fruits-template-isolated .detail-image:nth-child(3) {
          filter: hue-rotate(25deg) saturate(1.4) contrast(1.1) !important;
          transform: rotate(1deg) scale(1.01) !important;
        }
        
        .fruits-template-isolated .detail-image:hover {
          transform: scale(1.05) rotate(0deg) !important;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2) !important;
        }
         */

        .fruits-template-isolated .recommendation-section {
          background-color: #272727 !important;
          border-radius: 15px !important;
          padding: 40px !important;
          max-width: 800px !important;
          margin: 0 auto !important;
        }
        
        .fruits-template-isolated .recommendation-header {
          text-align: center !important;
          margin-bottom: 30px !important;
        }
        
        .fruits-template-isolated .recommendation-title {
          font-size: 28px !important;
          font-weight: bold !important;
          color: white !important;
          margin: 0 0 10px 0 !important;
        }
        
        .fruits-template-isolated .recommendation-subtitle {
          font-size: 16px !important;
          color: #ccc !important;
          margin: 0 !important;
        }
        
        .fruits-template-isolated .recommendation-list {
          display: flex !important;
          flex-direction: column !important;
          gap: 15px !important;
        }
        
        .fruits-template-isolated .recommendation-item {
          display: flex !important;
          align-items: center !important;
          gap: 15px !important;
        }
        
        .fruits-template-isolated .recommendation-check {
          width: 24px !important;
          height: 24px !important;
          background-color: #4CAF50 !important;
          border-radius: 50% !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          flex-shrink: 0 !important;
        }
        
        .fruits-template-isolated .recommendation-text {
          color: white !important;
          font-size: 16px !important;
          line-height: 1.5 !important;
        }
    </style>
    
      <div class="main-container">
        <div class="content-wrapper">
          
          <!-- 헤더 -->
          <header class="header">
            <h1>${cropType}나라</h1>
          </header>

          <!-- 히어로 섹션 -->
          <section class="hero-section">
            <div class="hero-background" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important; z-index: 1 !important;"></div>
            <div class="hero-content">
              <div class="hero-text-container">
                <p class="hero-subtitle">청정 자연에서 재배해 더 맛있는</p>
                <div class="hero-title-container">
                  <h2 class="hero-title">${cropType}나라 제철 ${cropType}</h2>
                  <div class="hero-title-background"></div>
                </div>
              </div>
            </div>
          </section>

          <!-- 특징 섹션 -->
          <section class="features-section">
            <div class="features-container">
              <div class="features-grid">
                <div class="feature-item">
                  <div class="feature-content">
                    <div class="feature-icon">
                      <img src="${iconSmile}" alt="보장된 맛">
                    </div>
                    <div class="feature-text">
                      <h3 class="feature-title">보장된 맛</h3>
                      <p class="feature-description">${climax}</p>
                    </div>
                  </div>
                </div>
                
                <div class="feature-divider"></div>
                
                <div class="feature-item">
                  <div class="feature-content">
                    <div class="feature-icon">
                      <img src="${iconDelivery}" alt="빠른 배송">
                    </div>
                    <div class="feature-text">
                      <h3 class="feature-title">빠른 배송</h3>
                      <p class="feature-description">${satisfaction}</p>
                    </div>
                  </div>
                </div>
                
                <div class="feature-divider"></div>
                
                <div class="feature-item">
                  <div class="feature-content">
                    <div class="feature-icon">
                      <img src="${iconRelief}" alt="안심 재배">
                    </div>
                    <div class="feature-text">
                      <h3 class="feature-title">안심 재배</h3>
                      <p class="feature-description">${development}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <!-- 리뷰 섹션 -->
          <section class="reviews-section" style="background: linear-gradient(rgba(0, 0, 0, 0.85), rgba(0, 0, 0, 0.85)), url('` + base64Image + `') center center / cover !important;">
            <div class="reviews-background">
              <header class="reviews-header">
                <h2 class="reviews-subtitle">구매 고객님들의</h2>
                <h1 class="reviews-title">생생한 리뷰</h1>
              </header>
              
              <div class="reviews-container">
                <article class="review-card">
                  <div class="review-content">
                         <div class="review-avatar">
                           <img src="${base64Image}" alt="리뷰어 1">
                         </div>
                    <div class="review-text">
                      <div class="review-stars">
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                      </div>
                      <h3 class="review-title">SNS 올리기 딱 좋은 비주얼</h3>
                      <p class="review-description">${snsPoint}</p>
                    </div>
                  </div>
                </article>
                
                <article class="review-card">
                  <div class="review-content">
                         <div class="review-avatar">
                           <img src="${base64Image}" alt="리뷰어 2">
                         </div>
                    <div class="review-text">
                      <div class="review-stars">
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                      </div>
                      <h3 class="review-title">홈카페 느낌 낼 때 이거 하나면 끝</h3>
                      <p class="review-description">${homecafeUse}</p>
                    </div>
                  </div>
                </article>
                
                <article class="review-card">
                  <div class="review-content">
                         <div class="review-avatar">
                           <img src="${base64Image}" alt="리뷰어 3">
                         </div>
                    <div class="review-text">
                      <div class="review-stars">
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                        <svg class="star-icon" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                      </div>
                      <h3 class="review-title">부모님께 선물하기도 좋아요</h3>
                      <p class="review-description">${giftMessage}</p>
                    </div>
                  </div>
                </article>
              </div>
            </div>
          </section>

          <!-- 소개 섹션 -->
          <section class="intro-section">
            <div class="intro-content">
              <p class="intro-text">
                ${currentAnalysis?.analysis?.marketing_content?.intro_section?.main_text || 
                  `저희 ${cropType}나라는<br>청정 지역에서 정성스럽게 재배한<br>신선한 ${cropType}을 엄선해<br>믿고 드실 수 있도록<br>최선을 다하고 있습니다.<br><br>새콤달콤 맛있는 ${cropType}을<br>이제 안심하고 드셔보세요.`
                }
              </p>
              <div class="intro-image" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important; filter: blur(1px) brightness(1.1) scale(1.05) !important; transform: scale(1.05) !important;"></div>
            </div>
          </section>

          <!-- POINT 01 -->
          <section class="point-section point-01">
            <div class="point-background" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important;"></div>
            <div class="point-content">
                <header class="point-header">
                  <h2 class="point-number">POINT 01</h2>
                </header>
                <div class="point-text-container">
                  <p class="point-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_01?.subtitle || `더욱 신선한 ${cropType}`}</p>
                  <h1 class="point-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_01?.title || '당일 수확! 당일 배송!'}</h1>
                </div>
                <p class="point-description">
                  ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_01?.description || 
                    `${cropType}나라에서는 고객님께서<br>신선한 ${cropType}을 만나보실 수 있도록<br>당일 수확한 ${cropType}을 배송해 드리고 있습니다.`
                  }
                </p>
              </div>
            </div>
          </section>

          <!-- POINT 02 -->
          <section class="point-section point-02">
            <div class="point-02-header">
              <header class="point-header">
                <h2 class="point-number">POINT 02</h2>
              </header>
              <div class="point-02-text-container">
                <p class="point-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.subtitle || '각종 디저트의 맛 업그레이드!'}</p>
                <h1 class="point-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.title || `새콤달콤 맛있는 ${cropType}`}</h1>
              </div>
              <p class="point-description">
                ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.description || 
                  `${cropType}나라의 ${cropType}은 당도가 굉장히 높고<br>새콤달콤한 맛이 일품이기 때문에<br>디저트랑 잘어울립니다`
                }
              </p>
            </div>
            
            <div class="dessert-items">
              ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_02?.usage_examples?.map((example: any, index: number) => `
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="${cropType} 활용법 ${index + 1}">
                  </div>
                  <div class="dessert-text">
                    ${example.text || `활용법 ${index + 1}`}
                  </div>
                </div>
              `).join('') || `
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="디저트 1">
                  </div>
                  <div class="dessert-text">
                    디저트 위에 데코로<br>
                    눈과 입을 즐겁게
                  </div>
                </div>
                
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="디저트 2">
                  </div>
                  <div class="dessert-text">
                    달콤한 ${cropType}잼을<br>
                    만들어 빵과 함께
                  </div>
                </div>
                
                <div class="dessert-item">
                  <div class="dessert-image">
                           <img src="${base64Image}" alt="디저트 3">
                  </div>
                  <div class="dessert-text">
                    타르트 위에 얹어<br>
                    ${cropType} 타르트로
                  </div>
                </div>
              `}
            </div>
          </section>

          <!-- POINT 03 -->
          <section class="point-section point-03">
            <div class="point-background" style="background-image: url('` + base64Image + `') !important; background-size: cover !important; background-position: center !important;"></div>
            <div class="point-content">
                <header class="point-header">
                  <h2 class="point-number">POINT 03</h2>
                </header>
                <div class="point-text-container">
                  <p class="point-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_03?.subtitle || '유기농 재배로 안심하고 냠냠!'}</p>
                  <h1 class="point-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_03?.title || '우리 아이 안전 먹거리'}</h1>
                </div>
                <p class="point-description">
                  ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_03?.description || 
                    `${cropType}나라의 ${cropType}은 무농약으로 재배하여<br>아이들도 안심하고 먹을 수 있으며<br>GAP 인증을 받았습니다.`
                  }
                </p>
              </div>
            </div>
          </section>

          <!-- POINT 04 -->
          <section class="point-04-section">
            <div class="point-04-content">
              <div class="point-04-header">
                <div class="point-04-header-border">
                  <h2 class="point-04-number">POINT 04</h2>
                </div>
                <div class="point-04-text-container">
                  <p class="point-04-subtitle">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.subtitle || `무른 곳 없이 신선한 ${cropType}`}</p>
                  <h1 class="point-04-title">${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.title || '꼼꼼한 포장 & 빠른 배송'}</h1>
                  <p class="point-04-description">
                    ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.description || 
                      `${cropType}나라에서는 아이스팩과 뽁뽁이를 동봉하여<br>${cropType}이 무르지 않도록 꼼꼼하게 포장하며<br>당일 배송을 통해 빠르게 보내드립니다.`
                    }
                  </p>
                </div>
              </div>
            </div>
            
            <div class="detail-images">
              <img src="${base64Image}" alt="포장 상세 1" class="detail-image">
              <img src="${iconDelivery}" alt="빠른 배송">
              <img src="${base64Image}" alt="포장 상세 3" class="detail-image">
            </div>
            
            <div class="recommendation-section">
              <div class="recommendation-container">
                <div class="recommendation-header">
                  <h2 class="recommendation-title">${cropType}나라 제철${cropType}</h2>
                  <p class="recommendation-subtitle">이런 분들께 특히 추천해요!</p>
                </div>
                <div class="recommendation-list">
                         ${currentAnalysis?.analysis?.marketing_content?.point_sections?.point_04?.recommendations?.map((recommendation: string) => `
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">${recommendation}</span>
                    </div>
                  `).join('') || `
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">제철 ${cropType}을 빠르게 드시고 싶으신 분</span>
                    </div>
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">우리 가족 안심 과일을 찾고 계신 분</span>
                    </div>
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">자연이 선물한 과일을 찾으시는 분</span>
                    </div>
                    <div class="recommendation-item">
                      <div class="recommendation-check">
                        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                          <path d="M1 6L6 11L15 1" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                      </div>
                      <span class="recommendation-text">${cropType} 응용 디저트를 만들고 싶으신 분</span>
                    </div>
                  `}
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  `
}

// 동기 버전 템플릿 HTML 생성 함수 (fallback용)
const generateSyncTemplateHTML = (currentAnalysis: any, currentImageUrl: string) => {
  // 기본 이미지 사용
  const imageUrl = currentImageUrl || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OTk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPuydtOuvuOyngCDsl4bsnYw8L3RleHQ+PC9zdmc+'
  
  const cropType = currentAnalysis?.analysis?.crop_type || '농산물'
  const satisfaction = currentAnalysis?.analysis?.marketing_content?.conclusion_first?.satisfaction || '달콤하고 신선한 맛이 일품'
  const climax = currentAnalysis?.analysis?.marketing_content?.story_structure?.climax || '신선함을 그대로 전달해드립니다'
  const development = currentAnalysis?.analysis?.marketing_content?.story_structure?.development || '우리 농장은 햇빛이 잘 드는 지역에서 자연스럽게 자란 농산물을 재배합니다'
  const snsPoint = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.sns_point || '인스타 스토리에서 반응 폭발 예정'
  const homecafeUse = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.homecafe_use || '요거트볼, 스무디, 샐러드까지 완벽'
  const giftMessage = currentAnalysis?.analysis?.marketing_content?.mz_appeal?.gift_message || '건강 챙기는 마음까지 전달되는 선물'
  
  // 동기 버전에서는 인라인 스타일 사용
  return `
    <div class="fruits-template-isolated">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700;900&display=swap" rel="stylesheet">
      
      <style>
        /* 기본 스타일만 포함 (배경 이미지 제외) */
        .fruits-template-isolated {
          all: initial !important;
          display: block !important;
          font-family: 'Noto Sans KR', 'Malgun Gothic', sans-serif !important;
          line-height: 1.6 !important;
          color: #272727 !important;
          background-color: #f5f5f5 !important;
          padding: 20px 16px !important;
          margin: 0 !important;
          box-sizing: border-box !important;
          width: 100% !important;
          position: relative !important;
          z-index: 1 !important;
        }
        /* ... 나머지 스타일들 ... */
      </style>
      
      <div class="main-container">
        <div class="content-wrapper">
          <header class="header">
            <h1>${cropType}나라</h1>
          </header>
          <!-- 간단한 콘텐츠만 포함 -->
          <div class="simple-content">
            <h2>분석 결과</h2>
            <p>${satisfaction}</p>
          </div>
        </div>
      </div>
    </div>
  `
}

export default function AnalyzePage() {
  const { uploadProgress, setUploadProgress, setCurrentAnalysis, currentAnalysis, clearCurrentAnalysis, setCurrentImageUrl, currentImageUrl } = useAnalysisStore()
  
  // 템플릿 HTML 상태
  const [templateHTML, setTemplateHTML] = useState('')
  
  // 분석 결과가 변경될 때마다 템플릿 생성
  useEffect(() => {
    const generateTemplate = async () => {
      if (currentAnalysis && currentImageUrl) {
        try {
          const html = await generateTemplateHTML(currentAnalysis, currentImageUrl)
          setTemplateHTML(html)
        } catch (error) {
          console.error('템플릿 생성 실패:', error)
          // 동기 버전으로 fallback
          const syncHTML = generateSyncTemplateHTML(currentAnalysis, currentImageUrl)
          setTemplateHTML(syncHTML)
        }
      }
    }
    
    generateTemplate()
  }, [currentAnalysis, currentImageUrl])
  
  // 상세 정보 모달 상태
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [detailInfo, setDetailInfo] = useState({
    shipmentDate: '',
    stockQuantity: '',
    salesUnit: '',
    price: ''
  })
  const [isSaving, setIsSaving] = useState(false)
  const [showSavedPages, setShowSavedPages] = useState(false)
  const [savedPages, setSavedPages] = useState<Array<{
    id: string;
    crop_name: string;
    crop_type?: string;
    created_at: string;
    html_content?: string;
    marketing_summary?: string;
  }>>([])
  const [savedPagesCount, setSavedPagesCount] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isLoadingPages, setIsLoadingPages] = useState(false)
  const itemsPerPage = 5

  // 처리 중 상태
  const isProcessing = uploadProgress.status === 'uploading' || 
                      uploadProgress.status === 'analyzing' || 
                      uploadProgress.status === 'generating'

  // 회사 API로 HTML 콘텐츠 전송하는 함수 (부모 창 통신 방식)
  const sendToCompanyAPI = async (htmlContent: string): Promise<{ success: boolean; message: string; data?: Record<string, unknown> }> => {
    try {
      // URL에서 토큰 추출 (localStorage 백업 포함)
      const urlParams = new URLSearchParams(window.location.search);
      let urlToken = urlParams.get('token');
      
      // 토큰이 URL에 없으면 localStorage에서 확인
      if (!urlToken) {
        urlToken = localStorage.getItem('company_token');
        console.log('🔄 [토큰 복구] localStorage에서 토큰 복구:', urlToken);
      } else {
        // 토큰이 있으면 localStorage에 저장
        localStorage.setItem('company_token', urlToken);
        console.log('💾 [토큰 저장] localStorage에 토큰 저장:', urlToken);
      }
      
      console.log('🔍 [디버깅] 현재 URL:', window.location.href);
      console.log('🔍 [디버깅] URL 파라미터:', window.location.search);
      console.log('🔍 [디버깅] 최종 토큰:', urlToken);
      
      // HTML 콘텐츠에서 body 내용만 추출
      let cleanHtmlContent = htmlContent;
      const bodyMatch = cleanHtmlContent.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
      if (bodyMatch) {
        cleanHtmlContent = bodyMatch[1].trim();
      }
      
      // 회사 API 전송 (토큰이 있는 경우에만)
      if (!urlToken) {
        console.warn('⚠️ URL에 토큰이 없어서 회사 API 전송을 건너뜁니다.');
        return { success: false, message: 'URL에 토큰이 없습니다.' };
      }

      // 회사 콜백 API로 HTML 콘텐츠 전송
      const callbackPayload = {
        token: urlToken,
        description: cleanHtmlContent
      };
      
      // 개발 서버와 본 서버 모두 시도
      const callbackUrls = [
        'http://localhost:3000/api/farm-contents-update',  // 우리 자체 API 사용image.png
        'https://academy.runmoa.com/api/farm-contents-update',
        'http://dev01.schoolmoa.net/api/farm-contents-update'
      ];
      
      let callbackSuccess = false;
      let callbackError = '';
      
      for (const url of callbackUrls) {
        try {
          console.log(`[API 호출 시작] URL: ${url}`);
          console.log(`[요청 데이터] Token: ${urlToken?.substring(0, 20)}..., Content Length: ${cleanHtmlContent.length}`);
          
          const callbackResponse = await fetch(url, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(callbackPayload)
          });
          
          const responseStatus = callbackResponse.status;
          console.log(`📥 [응답 상태] ${url} → HTTP ${responseStatus}`);
          
          if (callbackResponse.ok) {
            const callbackResult = await callbackResponse.json();
            console.log(`✅ [API 성공] ${url}:`, callbackResult);
            
            if (callbackResult.success === true) {
              callbackSuccess = true;
              const successMessage = `회사 API 전송 성공! 서버: ${url.includes('academy') ? '본서버' : '개발서버'}, 아이템 ID: ${callbackResult.item_id}`;
              console.log(`🎉 ${successMessage}, 토큰: ${urlToken.substring(0, 20)}...`);
              
              // 🚀 부모 창으로 HTML 전송
              if (window.opener && !window.opener.closed && callbackResult.description) {
                try {
                  window.opener.postMessage({
                    type: 'HTML_CONTENT_READY',
                    htmlContent: callbackResult.description,
                    itemId: callbackResult.item_id,
                    timestamp: new Date().toISOString()
                  }, '*');
                  console.log('📤 부모 창으로 HTML 전송 완료!');
                } catch (error) {
                  console.error('❌ 부모 창 HTML 전송 오류:', error);
                }
              }
              
              return { success: true, message: successMessage, data: callbackResult };
            } else {
              console.error(`❌ [API 논리 오류] ${url}:`, callbackResult);
              callbackError = callbackResult.error || callbackResult.message || 'Unknown error';
            }
          } else {
            // HTTP 오류 상태별 상세 처리
            let errorMessage = '';
            try {
              const errorResult = await callbackResponse.json();
              errorMessage = errorResult.error || `HTTP ${responseStatus} 오류`;
              console.log(`📋 [오류 응답 본문] ${url}:`, errorResult);
            } catch {
              const errorText = await callbackResponse.text();
              errorMessage = errorText;
              console.log(`📋 [오류 응답 텍스트] ${url}: ${errorText}`);
            }
            
            switch (responseStatus) {
              case 400:
                console.error(`❌ [400 Bad Request] ${url}: 누락된 매개변수 - ${errorMessage}`);
                callbackError = `매개변수 오류: ${errorMessage}`;
                break;
              case 401:
                console.error(`❌ [401 Unauthorized] ${url}: 잘못된 토큰 - ${errorMessage}`);
                callbackError = `인증 오류: ${errorMessage}`;
                break;
              case 403:
                console.error(`❌ [403 Forbidden] ${url}: 사이트 ID 불일치 - ${errorMessage}`);
                callbackError = `권한 오류: ${errorMessage}`;
                break;
              case 419:
                console.error(`❌ [419 CSRF] ${url}: CSRF 토큰 만료 - ${errorMessage}`);
                callbackError = `CSRF 토큰 오류: 회사에서 API 경로를 CSRF 예외 처리해주세요`;
                break;
              case 500:
                console.error(`❌ [500 Internal Error] ${url}: 서버 내부 오류 - ${errorMessage}`);
                callbackError = `서버 오류: ${errorMessage}`;
                break;
              default:
                console.error(`❌ [HTTP ${responseStatus}] ${url}: ${errorMessage}`);
                callbackError = `HTTP ${responseStatus} 오류: ${errorMessage}`;
            }
          }
        } catch (err) {
          console.error(`❌ [네트워크 오류] ${url}:`, err);
          callbackError = err instanceof Error ? err.message : '네트워크 오류';
        }
      }
      
      if (!callbackSuccess) {
        console.warn(`⚠️ [최종 결과] 모든 회사 API 전송 실패: ${callbackError}`);
        return { success: false, message: callbackError };
      }
      
      // 여기까지 오면 모든 서버에서 실패
      console.error(`❌ [치명적 오류] 예상치 못한 상황: 모든 서버에서 전송 실패`);
      return { success: false, message: '모든 서버에서 전송 실패' };
      
    } catch (error) {
      console.error('회사 API 전송 중 오류:', error);
      return { success: false, message: error instanceof Error ? error.message : '알 수 없는 오류' };
    }
  };

  // 저장된 상세페이지 개수 불러오기 (더미 함수 - DB 저장 기능 제거)
  const loadSavedPagesCount = async () => {
    // 데이터베이스 저장 기능을 제거했으므로 더 이상 API 호출하지 않음
    console.log('📊 저장된 페이지 개수 확인 건너뜀 (DB 저장 기능 비활성화)');
    setSavedPagesCount(0);
  }

  // 저장된 상세페이지 목록 불러오기 (더미 함수 - DB 저장 기능 제거)
  const loadSavedPages = async (page: number = 1) => {
    console.log('📊 저장된 페이지 목록 불러오기 건너뜀 (DB 저장 기능 비활성화)');
    setIsLoadingPages(false);
    setSavedPages([]);
    setSavedPagesCount(0);
    setCurrentPage(1);
    setTotalPages(1);
    // 모달은 열지 않음 (저장된 페이지가 없으므로)
  }

  // 페이지 변경 핸들러
  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages && page !== currentPage) {
      loadSavedPages(page);
    }
  }

  // 개별 상세페이지 삭제 (더미 함수 - DB 저장 기능 제거)
  const deletePage = async (pageId: string, pageName: string, hardDelete: boolean = false) => {
    console.log('🗑️ 페이지 삭제 건너뜀 (DB 저장 기능 비활성화):', { pageId, pageName, hardDelete });
    alert('💡 데이터베이스 저장 기능이 비활성화되어 삭제할 페이지가 없습니다.');
  }

  // 전체 삭제 (더미 함수 - DB 저장 기능 제거)
  const deleteAllPages = async (hardDelete: boolean = false) => {
    console.log('🗑️ 전체 페이지 삭제 건너뜀 (DB 저장 기능 비활성화):', { hardDelete });
    alert('💡 데이터베이스 저장 기능이 비활성화되어 삭제할 페이지가 없습니다.');
  }

  // 페이지 로드 시 저장된 페이지 개수 불러오기 및 부모 창에 준비 신호 전송
  useEffect(() => {
    loadSavedPagesCount();
    
    // URL에서 토큰 확인하고 localStorage에 저장
    const urlParams = new URLSearchParams(window.location.search);
    const urlToken = urlParams.get('token');
    if (urlToken) {
      localStorage.setItem('company_token', urlToken);
      console.log('💾 [페이지 로드] 토큰 저장:', urlToken);
    }
    
    // 부모 창에 준비 완료 신호 보내기
    if (window.opener && !window.opener.closed) {
      try {
        window.opener.postMessage({
          type: 'AI_WINDOW_READY',
          timestamp: new Date().toISOString()
        }, '*');
        
        console.log('✅ 부모 창에 준비 완료 신호를 보냈습니다.');
      } catch (error) {
        console.error('부모 창 준비 신호 전송 오류:', error);
      }
    }
  }, [])

  const handleImageUpload = async (file: File) => {
    try {
      // 1단계: 이미지 업로드 시작
      setUploadProgress({
        progress: 5,
        status: 'uploading',
        message: '파일 검증 중...'
      })

      // 파일 검증 단계
      await new Promise(resolve => setTimeout(resolve, 500))
      setUploadProgress({
        progress: 15,
        status: 'uploading',
        message: '이미지 최적화 중...'
      })

      const formData = new FormData()
      formData.append('image', file)
      formData.append('filename', sanitizeFileName(file.name))

      // 서버 업로드 단계
      setUploadProgress({
        progress: 25,
        status: 'uploading',
        message: '서버 업로드 중...'
      })

      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      if (!uploadResponse.ok) {
        throw new Error('이미지 업로드에 실패했습니다.')
      }

      const uploadResult = await uploadResponse.json()
      
      // 업로드된 이미지 URL 저장
      setCurrentImageUrl(uploadResult.publicUrl)
      
      // 2단계: AI 분석 시작
      setUploadProgress({
        progress: 35,
        status: 'analyzing',
        message: '이미지 전처리 중...'
      })

      // 이미지 전처리 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 800))
      setUploadProgress({
        progress: 50,
        status: 'analyzing',
        message: 'AI 모델 분석 중...'
      })

      // AI 모델 분석 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 1000))
      setUploadProgress({
        progress: 65,
        status: 'analyzing',
        message: '작물 특성 파악 중...'
      })

      // 작물 특성 파악 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 800))
      setUploadProgress({
        progress: 80,
        status: 'analyzing',
        message: '마케팅 콘텐츠 생성 중...'
      })

      // 2단계: AI 분석
      const analysisResponse = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          imageUrl: uploadResult.publicUrl,
          imageFilename: uploadResult.filename,
          imageSize: file.size
        })
      })

      if (!analysisResponse.ok) {
        throw new Error('AI 분석에 실패했습니다.')
      }

      const analysisResult = await analysisResponse.json()

      // 3단계: 상세페이지 생성
      setUploadProgress({
        progress: 85,
        status: 'generating',
        message: '스토리텔링 구성 중...'
      })

      // 스토리텔링 구성 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 600))
      setUploadProgress({
        progress: 92,
        status: 'generating',
        message: 'SEO 최적화 중...'
      })

      // SEO 최적화 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 500))
      setUploadProgress({
        progress: 98,
        status: 'generating',
        message: '최종 검토 중...'
      })

      // 최종 검토 시뮬레이션
      await new Promise(resolve => setTimeout(resolve, 400))
      setUploadProgress({
        progress: 100,
        status: 'completed',
        message: '분석이 완료되었습니다!'
      })

      // 분석 결과를 스토어에 저장
      setCurrentAnalysis(analysisResult)

      // 결과 페이지로 이동 (임시로 분석 완료 메시지만 표시)
      setTimeout(() => {
        // TODO: 결과 페이지 구현 후 활성화
        // router.push(`/results/${analysisResult.analysisId}`)
        console.log('분석 완료:', analysisResult)
      }, 1000)

    } catch (error) {
      console.error('분석 오류:', error)
      setUploadProgress({
        progress: 0,
        status: 'error',
        message: error instanceof Error ? error.message : '분석 중 오류가 발생했습니다.'
      })
    }
  }

  // HTML 생성, 저장 및 다운로드 함수
  const generateAndDownloadHTML = async () => {
    if (!currentAnalysis?.analysis) return

    setIsSaving(true);
    
    try {
      // 현재 화면에 표시되는 templateHTML을 사용
      let finalTemplateHTML = templateHTML;
      
      // templateHTML이 없으면 새로 생성
      if (!finalTemplateHTML) {
        console.log('🔄 템플릿 HTML 생성 중...');
        finalTemplateHTML = await generateTemplateHTML(currentAnalysis, currentImageUrl || '');
      }

    const htmlContent = `
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${currentAnalysis.analysis.crop_type || '농산물'}나라 - 청정 자연에서 재배한 제철 ${currentAnalysis.analysis.crop_type || '농산물'}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700;900&display=swap" rel="stylesheet">
</head>
<body style="margin: 0; padding: 0; font-family: 'Noto Sans KR', sans-serif;">
    ${finalTemplateHTML}
</body>
</html>`;

      console.log('📄 생성된 HTML 길이:', htmlContent.length);
    
      // 1. 회사 API로 HTML 전송 (데이터베이스 저장 없이)
      console.log('🚀 회사 API로 HTML 전송 중...');
      await sendToCompanyAPI(htmlContent);
      
      console.log('✅ HTML 생성 및 전송 완료!');
      
      // 2. HTML 파일 다운로드
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const cropName = (currentAnalysis.analysis.crop_type || '농산물').replace(/\s+/g, '_');
      const dateStr = new Date().toISOString().split('T')[0];
      link.download = `${cropName}_상세페이지_${dateStr}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      // 성공 메시지 표시
      alert('✅ HTML 파일이 성공적으로 다운로드되었습니다!');
      
    } catch (error) {
      console.error('❌ 저장 중 오류 발생:', error);
      alert('저장 중 오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setIsSaving(false);
      setShowDetailModal(false);
    }
  }


  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <Navigation />
      
      {/* 플로팅 액션 버튼 - 저장된 상세페이지 보기 */}
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50">
        <div className="relative group">
                                     <Button
             onClick={() => {
              setCurrentPage(1);
               loadSavedPages(1);
             }}
             className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center relative active:scale-95"
             title="저장된 상세페이지 보기"
           >
            <span className="text-lg md:text-xl">📋</span>
            
            {/* 뱃지 - 저장된 페이지 개수 */}
            {savedPagesCount > 0 && (
              <div className="absolute -top-1 -right-1 md:-top-2 md:-right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 md:w-6 md:h-6 flex items-center justify-center font-bold shadow-md">
                {savedPagesCount > 99 ? '99+' : savedPagesCount}
              </div>
            )}
          </Button>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-400 to-blue-500 rounded-full mb-4 shadow-lg">
            <span className="text-3xl">🔍</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4">
            AI 농산물 분석
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            이미지 업로드만으로 농산물의 품질, 특성, 마케팅 포인트를 AI가 자동으로 분석해드립니다
          </p>
        </div>

        {/* 이미지 업로드 및 분석 결과 영역 */}
        {!currentAnalysis?.analysis ? (
          <div className="space-y-6">
            <ImageUploader 
            onUpload={async (file: File) => {
              try {
                // 1단계: 파일 업로드
                setUploadProgress({ status: 'uploading', progress: 10, message: '이미지 업로드 중...' })
                
                const formData = new FormData()
                formData.append('image', file)
                
                // 2단계: 서버 전송 (타임아웃 설정)
                setUploadProgress({ status: 'uploading', progress: 30, message: '서버로 이미지 전송 중...' })

                const controller = new AbortController()
                const timeoutId = setTimeout(() => controller.abort(), 60000) // 60초 타임아웃

                const response = await fetch('/api/analyze', {
                  method: 'POST',
                  body: formData,
                  signal: controller.signal
                })

                clearTimeout(timeoutId)
                
                if (!response.ok) {
                  const errorText = await response.text()
                  console.error('❌ 업로드 실패 상세:', {
                    status: response.status,
                    statusText: response.statusText,
                    errorText
                  })
                  throw new Error(`업로드 실패 (${response.status}): ${errorText}`)
                }
                
                // 3단계: AI 분석 시작
                setUploadProgress({ status: 'analyzing', progress: 50, message: 'AI가 농산물을 분석하고 있습니다...' })
                // Simulate AI analysis time
                await new Promise(resolve => setTimeout(resolve, 2000)); // 2초 대기
                
                const result = await response.json()
                console.log('📊 API 응답 결과:', result)
                
                if (!result.success) {
                  console.error('❌ 분석 API 실패:', result.error)
                  throw new Error(result.error || '분석 실패')
                }
                
                // 4단계: 마케팅 콘텐츠 생성
                setUploadProgress({ status: 'generating', progress: 80, message: '마케팅 콘텐츠 생성 중...' })
                await new Promise(resolve => setTimeout(resolve, 1000)); // 1초 대기

                setCurrentAnalysis(result.data)
                setCurrentImageUrl(result.data.imageUrl)

                // 5단계: 완료
                setUploadProgress({ status: 'completed', progress: 100, message: '✅ 분석 완료!' })
              } catch (error) {
                console.error('업로드 오류:', error)
                
                let errorMessage = '❌ 분석 중 오류가 발생했습니다.'
                
                if (error instanceof Error) {
                  if (error.name === 'AbortError') {
                    errorMessage = '⏱️ 업로드 시간이 초과되었습니다. 이미지 크기를 줄이거나 다시 시도해주세요.'
                  } else if (error.message.includes('Timeout')) {
                    errorMessage = '⏱️ 서버 응답 시간이 초과되었습니다. 잠시 후 다시 시도해주세요.'
                  } else {
                    errorMessage = error.message
                  }
                }
                
                setUploadProgress({
                  status: 'error',
                  progress: 0,
                  message: errorMessage
                })
              }
            }}
          />
          
          {/* 분석 진행 상태 표시 */}
          {isProcessing && (
            <div className="mt-6">
              <AnalysisProgress />
            </div>
          )}
          </div>
        ) : (
          <div className="space-y-8">
            {/* 분석 결과 표시 */}
                  {currentImageUrl && (
                    <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
                      <h3 className="text-xl font-bold mb-4 text-gray-800 flex items-center justify-center">
                        <span className="mr-2">📷</span>
                        분석된 이미지
                      </h3>
                      <div className="bg-white p-4 rounded-lg shadow-sm">
                        <Image 
                          src={currentImageUrl} 
                          alt="분석된 농산물 이미지" 
                          width={500}
                          height={400}
                          className="w-full max-w-lg mx-auto rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200"
                          style={{ maxHeight: '400px', objectFit: 'contain' }}
                        />
                        <p className="text-sm text-gray-600 text-center mt-3 font-medium">
                    위 이미지를 AI가 분석한 결과입니다
                        </p>
                      </div>
                    </div>
                  )}

            {/* 상세 정보 추가 & 파일 저장 버튼 */}
            <div className="flex justify-center">
                      <Button 
                        onClick={() => setShowDetailModal(true)}
                className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3"
                size="lg"
                disabled={currentAnalysis?.analysis?.crop_type === 'N/A'}
                      >
                        📝 상세 정보 추가 & 파일 저장
                      </Button>
                  </div>

            {/* fruits_type 템플릿 기반 상세 페이지 */}
            <div className="w-full mt-6">
              <div 
                dangerouslySetInnerHTML={{
                  __html: templateHTML || '템플릿을 생성하는 중...'
                }}
              />
                          </div>

                  {/* 새 분석 버튼 */}
                  <div className="pt-4 border-t">
                    <Button 
                      onClick={() => {
                        clearCurrentAnalysis()
                        window.location.reload()
                      }}
                variant="outline"
                className="w-full text-lg py-3 border-2 border-gray-300 hover:border-green-500 hover:text-green-600 transition-colors duration-200"
                size="lg"
                    >
                      📸 새 이미지 분석하기
                    </Button>
              </div>
            </div>
          )}
      </div>

      {/* 상세 정보 입력 모달 */}
      {showDetailModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                  <span className="mr-3">📝</span>
                  상세 정보 입력
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDetailModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </Button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      출하 예정일 *
                    </label>
                    <input
                    type="date"
                    value={detailInfo.shipmentDate}
                      onChange={(e) => setDetailInfo(prev => ({ ...prev, shipmentDate: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                  />
                </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      재고 수량 *
                    </label>
                    <input
                      type="text"
                      value={detailInfo.stockQuantity}
                      onChange={(e) => setDetailInfo(prev => ({ ...prev, stockQuantity: e.target.value }))}
                      placeholder="예: 100박스, 50kg"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                </div>

                    <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      판매 단위 *
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={detailInfo.salesUnit.split(' ')[0] || '0'}
                        onChange={(e) => {
                          const quantity = e.target.value;
                          const unit = detailInfo.salesUnit.split(' ')[1] || 'kg';
                          setDetailInfo(prev => ({ ...prev, salesUnit: `${quantity} ${unit}` }));
                        }}
                        placeholder="1"
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        min="1"
                        step="1"
                        required
                      />
                      <select
                        value={detailInfo.salesUnit.split(' ')[1] || 'kg'}
                        onChange={(e) => {
                          const quantity = detailInfo.salesUnit.split(' ')[0] || '1';
                          const unit = e.target.value;
                          setDetailInfo(prev => ({ ...prev, salesUnit: `${quantity} ${unit}` }));
                        }}
                        className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                        required
                      >
                        <option value="개">개</option>
                        <option value="박스">박스</option>
                        <option value="kg">kg</option>
                        <option value="g">g</option>
                        <option value="포">포</option>
                        <option value="단">단</option>
                        <option value="묶음">묶음</option>
                        <option value="팩">팩</option>
                        <option value="봉지">봉지</option>
                        <option value="상자">상자</option>
                        <option value="트레이">트레이</option>
                        <option value="망">망</option>
                      </select>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">수량과 단위를 선택해주세요 (예: 2 kg, 1 박스)</p>
                    </div>
                    
                    <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      가격 *
                    </label>
                    <div className="relative">
                      <input
                          type="number"
                        value={detailInfo.price.replace(/[^0-9]/g, '')}
                        onChange={(e) => {
                          const value = e.target.value;
                          const formattedPrice = value ? `${parseInt(value).toLocaleString()}원` : '';
                          setDetailInfo(prev => ({ ...prev, price: formattedPrice }));
                        }}
                        placeholder="15000"
                        className="w-full px-3 py-2 pr-8 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                          min="0"
                        required
                        />
                      <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 text-sm">원</span>
                      </div>
                    <p className="text-xs text-gray-500 mt-1">숫자만 입력하세요 (예: 15000 → 15,000원)</p>
                    </div>
                  </div>

                <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                      setCurrentPage(1);
                      loadSavedPages(1);
                    setShowDetailModal(false);
                    setCurrentPage(1);
                    loadSavedPages(1);
                  }}
                  className="px-6 py-3 text-lg text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                  disabled={isSaving}
                >
                  📋저장된 상세페이지
                </Button>
                
                <div className="flex space-x-4">
                  <Button
                    variant="outline"
                    onClick={() => setShowDetailModal(false)}
                    className="px-6 py-3 text-lg"
                    disabled={isSaving}
                  >
                    취소
                  </Button>
                  <Button
                    onClick={generateAndDownloadHTML}
                    className="px-6 py-3 text-lg bg-green-600 hover:bg-green-700"
                    disabled={!detailInfo.shipmentDate || !detailInfo.stockQuantity || !detailInfo.salesUnit || !detailInfo.price || isSaving}
                  >
                    {isSaving ? (
                      <>
                        <span className="animate-spin mr-2">⏳</span>
                        저장 중...
                      </>
                    ) : (
                      '💾 저장 & 다운로드'
                    )}
                  </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
                    </div>
                  )}

      {/* 저장된 상세페이지 목록 모달 */}
      {showSavedPages && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-5xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center space-x-4">
                  <h2 className="text-2xl font-bold text-gray-900 flex items-center">
                    <span className="mr-3">📋</span>
                    저장된 상세페이지 목록
                  </h2>
                  <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    총 {savedPagesCount}개
                </div>
                    </div>
                  <Button
                    variant="ghost"
                  size="sm"
                    onClick={() => setShowSavedPages(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </Button>
              </div>

              {isLoadingPages ? (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                  <span className="ml-3 text-gray-600">페이지를 불러오는 중...</span>
                </div>
              ) : savedPages.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">📄</div>
                  <p className="text-gray-500 text-lg">저장된 상세페이지가 없습니다.</p>
                  <p className="text-gray-400 text-sm mt-2">분석 후 상세 정보를 입력하여 페이지를 저장해보세요.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {savedPages.map((page, index) => (
                    <div key={page.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold text-lg text-gray-900">
                            {page.crop_name || page.crop_type || '농산물'}
                          </h3>
                            <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">
                              {page.crop_type || '농산물'}
                            </span>
                          </div>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
                            <div>
                              <span className="font-medium">출하일:</span> {(page as any).detail_info?.shipmentDate || 'N/A'}
                        </div>
                            <div>
                              <span className="font-medium">재고:</span> {(page as any).detail_info?.stockQuantity || 'N/A'}
                            </div>
                            <div>
                              <span className="font-medium">단위:</span> {(page as any).detail_info?.salesUnit || 'N/A'}
                            </div>
                            <div>
                              <span className="font-medium">가격:</span> {(page as any).detail_info?.price || 'N/A'}
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span>생성일: {new Date(page.created_at).toLocaleDateString('ko-KR')}</span>
                            <span>다운로드: {(page as any).download_count || 0}회</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-col space-y-2 ml-4">
                          <Button 
                            size="sm"
                            onClick={async () => {
                              if (!page.html_content) {
                                alert('⚠️ 저장된 HTML 콘텐츠가 없습니다.');
                                return;
                              }
                              
                                const blob = new Blob([page.html_content], { type: 'text/html;charset=utf-8' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement('a');
                                link.href = url;
                              const cropName = (page.crop_name || page.crop_type || '농산물').replace(/\s+/g, '_');
                              const dateStr = new Date(page.created_at).toISOString().split('T')[0];
                              link.download = `${cropName}_상세페이지_${dateStr}.html`;
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                URL.revokeObjectURL(url);
                                
                                // 다운로드 카운트 증가
                                fetch(`/api/detail-pages/${page.id}/download`, { method: 'POST' });
                            }}
                            className="text-xs"
                          >
                            📄 다운로드
                          </Button>
                          
                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={async () => {
                              if (!page.html_content) {
                                alert('⚠️ 저장된 HTML 콘텐츠가 없습니다.');
                                return;
                              }
                              
                              // 공통 함수 사용하고 결과 받기
                              const result = await sendToCompanyAPI(page.html_content);
                              
                              // URL에서 토큰 확인
                              const urlParams = new URLSearchParams(window.location.search);
                              const urlToken = urlParams.get('token');
                              
                              if (result.success) {
                                if (urlToken) {
                                  alert('✅ 회사 시스템으로 전송이 완료되었습니다!');
                              } else {
                                  alert('✅ HTML 콘텐츠가 성공적으로 전송되었습니다!');
                                }
                              } else {
                                if (urlToken) {
                                  alert(`❌ 회사 시스템 전송 실패: ${result.message}`);
                                } else {
                                  alert(`❌ 전송 실패: ${result.message}`);
                                }
                              }
                            }}
                            className="text-xs"
                          >
                            🚀 전송
                          </Button>

                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={() => deletePage(page.id, page.crop_name || page.crop_type || '농산물', false)}
                            className="text-xs text-orange-600 hover:text-orange-700 hover:bg-orange-50 border-orange-200"
                            title="상세페이지만 삭제 (분석 결과는 유지)"
                          >
                            🗑️ 페이지삭제
                          </Button>

                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={() => deletePage(page.id, page.crop_name || page.crop_type || '농산물', true)}
                            className="text-xs text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                            title="완전 삭제: 분석 결과까지 모두 삭제 (복구 불가)"
                          >
                            ❌ 완전삭제
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  </div>
              )}

                  {/* 페이지네이션 */}
                  {totalPages > 1 && (
                <div className="flex justify-center items-center space-x-2 mt-6 pt-6 border-t">
                      <Button
                        variant="outline"
                        size="sm"
                    onClick={() => loadSavedPages(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1 || isLoadingPages}
                        className="px-3 py-1"
                      >
                    이전
                      </Button>
                      
                      <div className="flex space-x-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => {
                      // 현재 페이지 주변만 표시
                          if (
                            page === 1 || 
                            page === totalPages || 
                            (page >= currentPage - 2 && page <= currentPage + 2)
                          ) {
                            return (
                              <Button
                                key={page}
                                variant={page === currentPage ? "default" : "outline"}
                                size="sm"
                            onClick={() => loadSavedPages(page)}
                            disabled={isLoadingPages}
                            className="px-3 py-1 min-w-[2rem]"
                              >
                                {page}
                              </Button>
                            );
                          } else if (
                            page === currentPage - 3 || 
                            page === currentPage + 3
                          ) {
                            return (
                              <span key={page} className="px-2 py-1 text-gray-400">
                                ...
                              </span>
                            );
                          }
                          return null;
                        })}
                      </div>
                      
                      <Button
                        variant="outline"
                        size="sm"
                    onClick={() => loadSavedPages(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages || isLoadingPages}
                        className="px-3 py-1"
                      >
                    다음
                      </Button>
                    </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}